// 函数: sub_4012d0
// 地址: 0x4012d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return _atexit(sub_6d1bb0)
