// 函数: ??$__acrt_lowio_lock_fh_and_call@V<lambda_9f7c74da3c880c1c93b7275d920bab7e>@@@@YAHH$$QAV<lambda_9f7c74da3c880c1c93b7275d920bab7e>@@@Z
// 地址: 0x703e3e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_823d65812123d985753d53e2a8c25d20>,class <lambda_0a97c9e57da7be065955385c79108ff2>&,class <lambda_4d2973f3ad2d226f00468307185dca1b>,int32_t>::operator()<class <lambda_823d65812123d985753d53e2a8c25d20>,class <lambda_0a97c9e57da7be065955385c79108ff2>&,class <lambda_4d2973f3ad2d226f00468307185dca1b> >(
    &var_10, arg2)
