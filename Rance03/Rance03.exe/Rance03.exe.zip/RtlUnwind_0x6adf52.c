// 函数: RtlUnwind
// 地址: 0x6adf52
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
