// 函数: __unwindfunclet$??0ContextBase@details@Concurrency@@QAE@PAVSchedulerBase@12@_N@Z$2
// 地址: 0x71e5bc
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_58aa90(*(arg1 - 0x10) + 0x8c) __tailcall
