// 函数: $LN10
// 地址: 0x10002352
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

sub_1000267c()
return ___scrt_release_startup_lock((*(arg1 - 0x1c)).b)
