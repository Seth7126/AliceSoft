// 函数: ??$count@D@formatting_buffer@__crt_stdio_output@@QBEIXZ
// 地址: 0x7041d6
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (*(arg1 + 0x404) != 0)
    return *(arg1 + 0x400) u>> 1

return 0x200
