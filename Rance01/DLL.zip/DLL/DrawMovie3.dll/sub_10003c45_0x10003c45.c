// 函数: sub_10003c45
// 地址: 0x10003c45
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

for (int32_t i = 0; i u< 0x2d; i += 1)
    if (arg1 == *((i << 3) + &data_10020130))
        return *((i << 3) + &data_10020134)

if (arg1 - 0x13 u> 0x11)
    return (sbb.d(arg1 - 0xbc, arg1 - 0xbc, 0xe u< arg1 - 0xbc) & 0xe) + 8

return 0xd
