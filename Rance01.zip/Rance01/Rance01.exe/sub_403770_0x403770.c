// 函数: sub_403770
// 地址: 0x403770
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return *(arg1 + 0x7c)
