// 函数: __execute_onexit_table
// 地址: 0x10006091
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* var_8 = arg1
void arg_4
var_8 = &arg_4
return __acrt_lowio_lock_fh_and_call<class <lambda_9f7c74da3c880c1c93b7275d920bab7e> >(2, &var_8)
