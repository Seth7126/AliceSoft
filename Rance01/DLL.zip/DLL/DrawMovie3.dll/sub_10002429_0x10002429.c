// 函数: sub_10002429
// 地址: 0x10002429
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_100023a1(arg1, arg2, arg3, 0, arg4)
