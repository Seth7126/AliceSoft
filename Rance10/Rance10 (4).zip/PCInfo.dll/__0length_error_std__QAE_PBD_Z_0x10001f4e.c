// 函数: ??0length_error@std@@QAE@PBD@Z
// 地址: 0x10001f4e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::exception::VTable** var_8 = arg1
struct std::logic_error::std::length_error::VTable** result = arg1
struct std::logic_error::std::length_error::VTable** result_1 = result
std::exception::exception(arg1, arg2)
*result = &std::length_error::`vftable'{for `std::logic_error'}
return result
