// 函数: j_sub_100172db
// 地址: 0x10017088
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_100172db() __tailcall
