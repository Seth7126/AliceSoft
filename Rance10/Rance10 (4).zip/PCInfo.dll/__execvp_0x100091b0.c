// 函数: __execvp
// 地址: 0x100091b0
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __mbsdec_l(arg1, arg2, nullptr)
