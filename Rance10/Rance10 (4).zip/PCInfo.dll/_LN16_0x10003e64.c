// 函数: $LN16
// 地址: 0x10003e64
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* result = sub_10004538()

if (*(result + 0x18) s> 0)
    result = sub_10004538()
    *(result + 0x18) -= 1

return result
