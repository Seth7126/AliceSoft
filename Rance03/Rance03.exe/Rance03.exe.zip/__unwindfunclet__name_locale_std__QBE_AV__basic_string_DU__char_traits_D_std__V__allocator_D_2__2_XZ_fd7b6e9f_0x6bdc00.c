// 函数: __unwindfunclet$?name@locale@std@@QBE?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@2@XZ$0
// 地址: 0x6bdc00
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = *(arg1 - 0x44) & 1

if (result == 0)
    return result

*(arg1 - 0x44) &= 0xfffffffe
return sub_401fb0(arg1 - 0x28) __tailcall
