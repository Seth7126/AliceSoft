// 函数: __execvp
// 地址: 0x6b73a2
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6b7278(arg1, arg2, nullptr)
