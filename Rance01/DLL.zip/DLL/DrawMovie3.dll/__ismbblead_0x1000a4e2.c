// 函数: __ismbblead
// 地址: 0x1000a4e2
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000a48f(nullptr, arg1, 0, 4)
