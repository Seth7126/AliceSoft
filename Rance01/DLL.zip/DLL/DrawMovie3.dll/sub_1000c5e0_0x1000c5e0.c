// 函数: sub_1000c5e0
// 地址: 0x1000c5e0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg2 == 0 || arg1[0x19] == 0)
    return 1

(*(*arg1 + 0x38))(arg2)
(*(*arg1 + 0xac))(arg2)
(*(*arg1 + 0x3c))(arg2)
return 0
