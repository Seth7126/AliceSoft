// 函数: SetComponentSupplier
// 地址: 0x100166d0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 != 0)
    data_100214bc = (*(*arg1 + 8))()
