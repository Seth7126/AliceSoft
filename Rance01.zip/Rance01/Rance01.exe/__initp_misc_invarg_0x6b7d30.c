// 函数: __initp_misc_invarg
// 地址: 0x6b7d30
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_797848 = arg1
return arg1
