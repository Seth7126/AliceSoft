// 函数: ??_G?$collate@G@std@@MAEPAXI@Z
// 地址: 0x6d7ad6
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

sub_6d790d(arg1)

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
