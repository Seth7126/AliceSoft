// 函数: ??$_Copy_impl@PA_WV?$ostreambuf_iterator@GU?$char_traits@G@std@@@std@@@std@@YA?AV?$ostreambuf_iterator@GU?$char_traits@G@std@@@0@PA_W0V10@U?$integral_constant@_N$00@0@@Z
// 地址: 0x6d6950
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

std::_Copy_no_deprecate<wchar_t*,class std::ostreambuf_iterator<wchar_t,struct std::char_traits<wchar_t> > >(
    arg1, arg2, arg3, arg4, arg5)
return arg1
