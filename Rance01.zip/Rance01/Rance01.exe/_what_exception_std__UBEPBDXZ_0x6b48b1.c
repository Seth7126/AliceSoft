// 函数: ?what@exception@std@@UBEPBDXZ
// 地址: 0x6b48b1
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

char const* const result = *(arg1 + 4)

if (result != 0)
    return result

return "Unknown exception"
