// 函数: _vsprintf_s
// 地址: 0x69b508
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __vsprintf_s_l(arg1, arg2, arg3, 0, arg4)
