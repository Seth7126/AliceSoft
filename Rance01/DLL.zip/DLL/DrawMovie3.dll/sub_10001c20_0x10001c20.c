// 函数: sub_10001c20
// 地址: 0x10001c20
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 0xd4
return sub_100010b0() __tailcall
