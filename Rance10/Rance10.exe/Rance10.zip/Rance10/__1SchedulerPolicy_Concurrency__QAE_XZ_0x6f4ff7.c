// 函数: ??1SchedulerPolicy@Concurrency@@QAE@XZ
// 地址: 0x6f4ff7
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return operator new(*arg1)
