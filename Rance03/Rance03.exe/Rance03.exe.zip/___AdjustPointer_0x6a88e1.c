// 函数: ___AdjustPointer
// 地址: 0x6a88e1
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t* esi = arg2[1]
void* result = *arg2 + arg1

if (esi s< 0)
    return result

return result + *(*(esi + arg1) + arg2[2]) + esi
