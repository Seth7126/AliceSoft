// 函数: sub_10009f7a
// 地址: 0x10009f7a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 != 0)
    return *(arg1 + 0x10)

*__errno() = 0x16
sub_100020e4(0, 0, 0, 0, 0)
return 0xffffffff
