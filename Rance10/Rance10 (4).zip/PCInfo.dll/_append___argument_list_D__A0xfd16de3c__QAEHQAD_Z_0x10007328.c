// 函数: ?append@?$argument_list@D@?A0xfd16de3c@@QAEHQAD@Z
// 地址: 0x10007328
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t edi
int32_t var_c = edi
int32_t result =
    xfd16de3c::expand_if_necessary::operator[]::argument_list<char>::expand_if_necessary(arg1)

if (result != 0)
    __free_base(arg2)
    return result

*arg1[1] = arg2
arg1[1] += 4
return 0
