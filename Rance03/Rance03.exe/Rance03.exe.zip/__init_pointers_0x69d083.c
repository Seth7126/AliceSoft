// 函数: __init_pointers
// 地址: 0x69d083
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax = EncodePointer(nullptr)
__initp_misc_purevirt(eax)
__set_pgmptr(eax)
__initp_misc_invarg(eax)
__initp_misc_winsig(eax)
int32_t var_18 = eax
__initp_eh_hooks()
___set_app_type(eax)
return sub_69f817() __tailcall
