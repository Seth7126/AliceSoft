// 函数: ?initialize@?$dual_state_global@PAU__crt_locale_data@@@__crt_state_management@@QAEXQAU__crt_locale_data@@@Z
// 地址: 0x10005291
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t esi = 0
int32_t result = not.d(sbb.d(&arg1[1], &arg1[1], &arg1[1] u< arg1)) & 7 u>> 2

if (result != 0)
    do
        esi += 1
        *arg1 = arg2
        arg1 = &arg1[1]
    while (esi != result)

return result
