// 函数: __unwindfunclet$??1SchedulerBase@details@Concurrency@@UAE@XZ$7
// 地址: 0x7236b9
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_56fdb0(*(arg1 - 0x10) + 0xb4) __tailcall
