// 函数: __unwindfunclet$??0?$propagator_block@V?$single_link_registry@V?$ITarget@I@Concurrency@@@Concurrency@@V?$multi_link_registry@V?$ISource@W4agent_status@Concurrency@@@Concurrency@@@2@V?$ordered_message_processor@I@2@@Concurrency@@QAE@XZ$1
// 地址: 0x6c3e0a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_556bd0(*(arg1 - 0x10) + 0x110) __tailcall
