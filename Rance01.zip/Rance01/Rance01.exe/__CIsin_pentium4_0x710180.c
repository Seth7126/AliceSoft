// 函数: __CIsin_pentium4
// 地址: 0x710180
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_71019e(zx.o(fconvert.d(arg1)))
