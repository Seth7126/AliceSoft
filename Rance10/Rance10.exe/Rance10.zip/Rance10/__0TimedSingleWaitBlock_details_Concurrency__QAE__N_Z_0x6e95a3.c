// 函数: ??0TimedSingleWaitBlock@details@Concurrency@@QAE@_N@Z
// 地址: 0x6e95a3
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

Concurrency::details::WaitBlock::WaitBlock(arg1)
*arg1 = &Concurrency::details::TimedSingleWaitBlock::`vftable'{for `Concurrency::details::SingleWaitBlock'}
arg1[4] = 0
arg1[6].b = arg2
arg1[7] = 0
arg1[8] = 0
arg1[9].b = 0
arg1[4] = arg1
return arg1
