// 函数: ?is_managed_app@@YA_NXZ
// 地址: 0x1000571d
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

HMODULE ecx = GetModuleHandleW(nullptr)
HMODULE result

if (ecx != 0 && ecx->unused.w == 0x5a4d)
    result = ecx * 2
    
    if (result->unused == 0x4550 && result->__offset(0x18).w == 0x10b && result u> 0xe)
        result.b = result != 0
        return result

result.b = 0
return result
