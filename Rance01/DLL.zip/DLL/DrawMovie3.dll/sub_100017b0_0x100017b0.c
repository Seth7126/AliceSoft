// 函数: sub_100017b0
// 地址: 0x100017b0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 u<= 0)
    arg1 = 0
else if (divu.dp.d(0:0xffffffff, arg1) u< 1)
    int32_t var_10 = 0
    struct std::exception::VTable* var_c
    sub_10001e9c(&var_c, &var_10)
    var_c = &std::bad_alloc::`vftable'{for `std::exception'}
    sub_1000272b(&var_c, 0x1001eed8)
    noreturn

return sub_10001dc9(arg1)
