// 函数: ___acrt_iob_func
// 地址: 0x706af8
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return arg1 * 0x38 + &data_7e1430
