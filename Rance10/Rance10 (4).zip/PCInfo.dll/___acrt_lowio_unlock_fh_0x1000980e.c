// 函数: ___acrt_lowio_unlock_fh
// 地址: 0x1000980e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return LeaveCriticalSection((arg1 & 0x3f) * 0x30 + (&data_10017028)[arg1 s>> 6])
