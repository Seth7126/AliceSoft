// 函数: ??0SchedulerCore@details@Concurrency@@QAE@XZ
// 地址: 0x6eb897
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*(arg1 + 0xc) = 0
*(arg1 + 0x10) = 0
return arg1
