// 函数: __seh_filter_dll
// 地址: 0x1000541d
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0xe06d7363)
    return __seh_filter_exe(0xe06d7363, arg2)

return 0
