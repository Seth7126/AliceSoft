// 函数: ??0invalid_scheduler_policy_value@Concurrency@@QAE@XZ
// 地址: 0x6f432a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::details::_Interruption_exception::`vftable'{for `std::exception'}
return arg1
