// 函数: ___crtFlushProcessWriteBuffers
// 地址: 0x6e7a1e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbe90 ^ __security_cookie

if (esi_1 != 0)
    j_sub_4033e0()
    esi_1()
