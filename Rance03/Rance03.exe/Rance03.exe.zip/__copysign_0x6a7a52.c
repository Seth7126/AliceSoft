// 函数: __copysign
// 地址: 0x6a7a52
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t ecx
int32_t var_8 = ecx
int32_t var_c = ecx
var_c.q = fconvert.d(float.t(0))
int32_t var_8_1 = ((arg3 ^ arg2) & 0x7fffffff) ^ arg3
return fconvert.t(arg1.q)
