// 函数: ??0?$WorkStealingQueue@V_UnrealizedChore@details@Concurrency@@V_CriticalNonReentrantLock@23@@details@Concurrency@@QAE@PAV_CriticalNonReentrantLock@12@@Z
// 地址: 0x6fc512
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t* var_8 = arg1
int32_t var_14 = 0x100
arg1[4] = arg2
*arg1 = 0
arg1[1] = 0
arg1[6] = 0
arg1[5].b = 0
arg1[3] = 0
arg1[2] = 0x3f
arg1[7] = sub_6e8787()
int32_t* eax_2 = sub_6e8787()
int32_t* var_8_1 = eax_2

if (eax_2 == 0)
    eax_2 = nullptr
else
    int32_t* ecx_1 = eax_2
    int32_t i_1 = 0x40
    int32_t i
    
    do
        *ecx_1 = 0
        ecx_1 = &ecx_1[2]
        ecx_1[-1] = 0
        i = i_1
        i_1 -= 1
    while (i != 1)

arg1[8] = eax_2
return arg1
