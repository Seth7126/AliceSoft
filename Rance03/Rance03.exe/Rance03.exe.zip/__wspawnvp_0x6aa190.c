// 函数: __wspawnvp
// 地址: 0x6aa190
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_6aa09b(arg1, arg2, arg3, nullptr)
