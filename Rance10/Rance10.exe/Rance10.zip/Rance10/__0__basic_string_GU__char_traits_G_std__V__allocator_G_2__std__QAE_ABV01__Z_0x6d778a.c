// 函数: ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QAE@ABV01@@Z
// 地址: 0x6d778a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int16_t* result = arg1
*(result + 0x10) = 0
*(result + 0x14) = 7
*result = 0
std::basic_string<uint16_t,struct std::char_traits<uint16_t>,class std::allocator<uint16_t> >::assign(
    arg1, arg2, nullptr, 0xffffffff)
return result
