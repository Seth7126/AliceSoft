// 函数: ___crtGetStringTypeA
// 地址: 0x6aaf72
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

void var_14
sub_69beb0(&var_14, arg1)
BOOL result = __crtGetStringTypeA_stat(&var_14, arg2, arg3, arg4, arg5, arg6, arg7)
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
