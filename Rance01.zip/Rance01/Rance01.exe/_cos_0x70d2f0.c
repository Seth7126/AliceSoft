// 函数: _cos
// 地址: 0x70d2f0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (data_798200 != 0)
    int32_t eax_2 = arg1 & 0x7f80
    bool cond:0_1 = eax_2 != 0x1f80
    
    if (eax_2 == 0x1f80)
        int16_t x87status_1
        int16_t temp0_1
        temp0_1, x87status_1 = __fnstcw_memmem16(arg2)
        eax_2.w = temp0_1
        eax_2.w &= 0x7f
        cond:0_1 = eax_2.w != 0x7f
    
    if (not(cond:0_1))
        return sub_70fc18(arg3) __tailcall

void* edx_1 = &arg3
int32_t eax_4
int32_t ecx
int32_t ecx_2
long double st0
st0, eax_4, ecx_2 = __fload_withFB(ecx, edx_1)
return sub_70d388(eax_4, arg2, st0, edx_1, ecx_2) __tailcall
