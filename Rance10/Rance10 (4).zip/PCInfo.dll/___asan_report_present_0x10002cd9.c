// 函数: ___asan_report_present
// 地址: 0x10002cd9
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = data_10017270 != 0
return result
