// 函数: ??0CancellationBeaconStack@ContextBase@details@Concurrency@@QAE@XZ
// 地址: 0x6f31e4
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 0
arg1[1] = 0
arg1[2] = sub_6e8787()
return arg1
