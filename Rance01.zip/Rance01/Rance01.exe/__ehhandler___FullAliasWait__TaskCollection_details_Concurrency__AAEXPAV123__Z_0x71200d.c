// 函数: __ehhandler$?_FullAliasWait@_TaskCollection@details@Concurrency@@AAEXPAV123@@Z
// 地址: 0x71200d
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b4885(*(arg1 - 0x24) ^ (arg1 + 0xc))
return sub_6bb3b5(0x773184) __tailcall
