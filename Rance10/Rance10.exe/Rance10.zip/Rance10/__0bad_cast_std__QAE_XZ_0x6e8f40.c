// 函数: ??0bad_cast@std@@QAE@XZ
// 地址: 0x6e8f40
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
arg1[1] = "bad array new length"
*arg1 = &std::bad_array_new_length::`vftable'{for `std::bad_alloc'}
return arg1
