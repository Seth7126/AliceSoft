// 函数: __GET_RTERRMSG
// 地址: 0x6a54b9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

for (int32_t i = 0; i u< 0x17; i += 1)
    if (arg1 == *((i << 3) + &data_6d5af0))
        return (&data_6d5af4)[i * 2]

return 0
