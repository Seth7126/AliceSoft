// 函数: sub_10001070
// 地址: 0x10001070
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*(arg1 + 4) += 1
return *(arg1 + 4)
