// 函数: sub_1000dd00
// 地址: 0x1000dd00
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 4
return sub_1000c010() __tailcall
