// 函数: __register_onexit_function
// 地址: 0x100060eb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* var_8 = arg1
void* var_c = arg1
void arg_4
var_c = &arg_4
void arg_8
void* var_8_1 = &arg_8
return __acrt_lowio_lock_fh_and_call<class <lambda_61d677f73751bd412abcbcd096bd0cc8> >(2, &var_c)
