// 函数: j_sub_5d1480
// 地址: 0x5d17d0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5d1480() __tailcall
