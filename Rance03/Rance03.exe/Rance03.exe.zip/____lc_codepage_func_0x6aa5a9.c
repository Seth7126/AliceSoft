// 函数: ____lc_codepage_func
// 地址: 0x6aa5a9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t* eax_2 = __getptd()
int32_t* eax = eax_2[0x1b]

if (eax != data_74adfc && (eax_2[0x1c] & data_74aec0) == 0)
    eax = sub_6a5929()

return eax[1]
