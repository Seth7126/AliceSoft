// 函数: sub_10006286
// 地址: 0x10006286
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result
result.b = *(arg1 + 0xc) != 0
return result
