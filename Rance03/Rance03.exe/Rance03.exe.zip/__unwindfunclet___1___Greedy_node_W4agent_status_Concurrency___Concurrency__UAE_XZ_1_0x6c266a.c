// 函数: __unwindfunclet$??1?$_Greedy_node@W4agent_status@Concurrency@@@Concurrency@@UAE@XZ$1
// 地址: 0x6c266a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_441ce0(*(arg1 - 0x10) + 0x154) __tailcall
