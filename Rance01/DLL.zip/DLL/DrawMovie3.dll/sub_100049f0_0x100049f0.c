// 函数: sub_100049f0
// 地址: 0x100049f0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* esi = arg1
char* ebx = arg3

if ((arg4[3].b & 0x40) != 0 && arg4[2] == 0)
    *esi += arg5
    return 

while (arg5 s> 0)
    arg1.b = *ebx
    arg5 -= 1
    arg1, arg2 = sub_10004997(arg1, arg2, arg4, esi)
    ebx = &ebx[1]
    
    if (*esi == 0xffffffff)
        int32_t edx
        arg1, edx = __errno()
        
        if (*arg1 != 0x2a)
            break
        
        arg1.b = 0x3f
        arg1, arg2 = sub_10004997(arg1, edx, arg4, esi)
