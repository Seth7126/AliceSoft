// 函数: __unwind_handler4
// 地址: 0x10004af0
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if ((*(arg1 + 4) & 6) == 0)
    return 1

@__security_check_cookie@4(*(arg2 + 8) ^ arg2)
*(arg2 + 0x18)
__local_unwind4(*(arg2 + 0x14), *(arg2 + 0x10), *(arg2 + 0xc))
*arg3 = arg2
return 3
