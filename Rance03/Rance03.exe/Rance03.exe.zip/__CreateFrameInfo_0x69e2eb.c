// 函数: __CreateFrameInfo
// 地址: 0x69e2eb
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

*arg1 = arg2
arg1[1] = __getptd()[0x26]
__getptd()[0x26] = arg1
return arg1
