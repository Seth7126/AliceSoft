// 函数: ___crtSetThreadpoolTimer
// 地址: 0x6e7b5c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbe78 ^ __security_cookie

if (esi_1 != 0)
    j_sub_4033e0()
    esi_1(arg1, arg2, arg3, arg4)
