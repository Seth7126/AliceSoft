// 函数: __seh_longjmp_unwind@4
// 地址: 0x70c2a6
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*arg1
return __local_unwind2(arg1[6], arg1[7])
