// 函数: ___acrt_initialize_multibyte
// 地址: 0x71b59e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (data_7fcb08 == 0)
    setmbcp_internal(0xfffffffd, 1)
    data_7fcb08 = 1

int32_t result
result.b = 1
return result
