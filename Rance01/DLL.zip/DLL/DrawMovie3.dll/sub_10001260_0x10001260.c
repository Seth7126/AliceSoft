// 函数: sub_10001260
// 地址: 0x10001260
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (*(arg1 + 0x18) u>= 0x10)
    int32_t var_8_1 = *(arg1 + 4)
    sub_10001d52()

*(arg1 + 0x18) = 0xf
*(arg1 + 0x14) = 0
*(arg1 + 4) = 0
return 0
