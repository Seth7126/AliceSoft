// 函数: sub_10003b82
// 地址: 0x10003b82
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* const temp0 = arg2
arg2 = __return_addr
jump(temp0)
