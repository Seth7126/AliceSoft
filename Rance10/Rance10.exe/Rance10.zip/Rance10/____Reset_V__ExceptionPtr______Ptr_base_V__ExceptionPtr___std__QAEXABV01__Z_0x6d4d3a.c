// 函数: ??$_Reset@V__ExceptionPtr@@@?$_Ptr_base@V__ExceptionPtr@@@std@@QAEXABV01@@Z
// 地址: 0x6d4d3a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

void* edx = arg1[1]
int32_t eax_1 = *arg1

if (edx != 0)
    *(edx + 4) += 1

int32_t* ecx
return sub_6d5365(ecx, eax_1, edx)
