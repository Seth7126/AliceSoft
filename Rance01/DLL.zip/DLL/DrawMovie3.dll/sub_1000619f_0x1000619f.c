// 函数: sub_1000619f
// 地址: 0x1000619f
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_100060d4(*(arg1 - 0x14))
return 0
