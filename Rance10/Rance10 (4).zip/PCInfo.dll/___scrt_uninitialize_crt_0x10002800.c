// 函数: ___scrt_uninitialize_crt
// 地址: 0x10002800
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (data_10016ba8 == 0 || arg2 == 0)
    int32_t var_8_1 = arg1
    ___acrt_uninitialize()
    ___vcrt_uninitialize(arg1.b)

int32_t result
result.b = 1
return result
