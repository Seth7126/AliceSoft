// 函数: __NLG_Notify1
// 地址: 0x1000503c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = arg3
data_10016038 = arg3
data_10016034 = arg1
data_1001603c = arg4
int32_t var_c = arg4
int32_t var_10 = arg3
return arg1
