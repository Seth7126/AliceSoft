// 函数: sub_100012d0
// 地址: 0x100012d0
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* ecx

if (*arg1 == 0)
    return sub_100014d0(ecx, arg1, nullptr)

char* edx = arg1
char i

do
    i = *edx
    edx = &edx[1]
while (i != 0)
return sub_100014d0(ecx, arg1, edx - &edx[1])
