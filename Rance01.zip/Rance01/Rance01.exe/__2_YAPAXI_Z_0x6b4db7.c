// 函数: ??2@YAPAXI@Z
// 地址: 0x6b4db7
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t i

do
    int32_t result = sub_6b5c43(arg1)
    
    if (result != 0)
        return result
    
    i = __callnewh(arg1)
while (i != 0)

if ((data_796eb0 & 1) == 0)
    data_796eb0.d |= 1
    int32_t var_18_3 = 1
    char const* const var_8 = "bad allocation"
    sub_6b4894(&data_796ea4, &var_8)
    data_796ea4 = &std::bad_alloc::`vftable'{for `std::exception'}
    _atexit(sub_72973b)

struct std::exception::VTable* var_14
std::exception::exception(&var_14, &data_796ea4)
var_14 = &std::bad_alloc::`vftable'{for `std::exception'}
sub_6b77db(&var_14, 0x771508)
noreturn
