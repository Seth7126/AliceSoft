// 函数: ?data@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QAEPADXZ
// 地址: 0x401070
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t* result = arg1 + 4

if (*(arg1 + 0x18) u< 0x10)
    return result

return *result
