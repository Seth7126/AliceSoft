// 函数: ?unexpected@@YAXXZ
// 地址: 0x69b1c9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax = __getptd()[0x1f]

if (eax != 0)
    eax()

noreturn terminate() __tailcall
