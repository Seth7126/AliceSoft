// 函数: j_sub_5da740
// 地址: 0x5da730
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5da740(arg1) __tailcall
