// 函数: __rtforexpinf
// 地址: 0x10017111
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 != 0)
    return sub_100172d6() __tailcall

return data_100216e0
