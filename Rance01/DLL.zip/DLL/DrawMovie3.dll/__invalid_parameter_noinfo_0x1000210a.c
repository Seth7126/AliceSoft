// 函数: __invalid_parameter_noinfo
// 地址: 0x1000210a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_100020e4(0, 0, 0, 0, 0)
