// 函数: sub_10009dc5
// 地址: 0x10009dc5
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return &data_10020a90
