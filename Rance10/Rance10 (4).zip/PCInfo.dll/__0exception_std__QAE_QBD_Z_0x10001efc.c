// 函数: ??0exception@std@@QAE@QBD@Z
// 地址: 0x10001efc
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::exception::VTable** var_8 = arg1
struct std::exception::VTable** var_c = arg1
var_c = arg2
var_8.b = 1
*arg1 = &std::exception::`vftable'
arg1[1] = 0
arg1[2] = 0
___std_exception_copy(&var_c, &arg1[1])
return arg1
