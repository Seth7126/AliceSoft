// 函数: sub_10002932
// 地址: 0x10002932
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return &data_10016bb8
