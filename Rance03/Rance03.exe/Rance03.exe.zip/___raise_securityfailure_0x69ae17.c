// 函数: ___raise_securityfailure
// 地址: 0x69ae17
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

data_75c8fc = IsDebuggerPresent()
sub_69f700()
___crtUnhandledException(arg1)

if (data_75c8fc == 0)
    sub_69f700()

sub_69fabe(0xc0000409)
noreturn
