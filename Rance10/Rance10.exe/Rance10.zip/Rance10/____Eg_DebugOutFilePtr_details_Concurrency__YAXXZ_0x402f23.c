// 函数: ??__Eg_DebugOutFilePtr@details@Concurrency@@YAXXZ
// 地址: 0x402f23
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

void* result = ___acrt_iob_func(2)
data_7fc2b0 = result
return result
