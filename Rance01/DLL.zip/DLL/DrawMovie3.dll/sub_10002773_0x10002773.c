// 函数: sub_10002773
// 地址: 0x10002773
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1
