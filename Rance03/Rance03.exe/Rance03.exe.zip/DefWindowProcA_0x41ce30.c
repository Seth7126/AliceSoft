// 函数: DefWindowProcA
// 地址: 0x41ce30
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return DefWindowProcA(hWnd, Msg, wParam, lParam) __tailcall
