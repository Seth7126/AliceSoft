// 函数: ___acrt_get_sigabrt_handler
// 地址: 0x1000817c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = arg1
return __acrt_lock_and_call<class <lambda_ec61778202f4f5fc7e7711acc23c3bca> >(3, &var_8:3)
