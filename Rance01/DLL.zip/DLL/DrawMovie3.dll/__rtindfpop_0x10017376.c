// 函数: __rtindfpop
// 地址: 0x10017376
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_10021740

if (*(arg1 - 0x90) s> 0)
    return 

return sub_10017389(arg1) __tailcall
