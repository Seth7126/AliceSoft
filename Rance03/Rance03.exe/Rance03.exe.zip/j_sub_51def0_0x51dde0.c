// 函数: j_sub_51def0
// 地址: 0x51dde0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_51def0(arg1) __tailcall
