// 函数: sub_10004343
// 地址: 0x10004343
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10007437(8)
