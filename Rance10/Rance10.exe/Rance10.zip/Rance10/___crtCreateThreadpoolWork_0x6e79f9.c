// 函数: ___crtCreateThreadpoolWork
// 地址: 0x6e79f9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbed8 ^ __security_cookie
j_sub_4033e0()
return esi_1(arg1, arg2, arg3)
