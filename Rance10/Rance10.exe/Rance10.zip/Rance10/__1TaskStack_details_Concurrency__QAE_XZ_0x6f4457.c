// 函数: ??1TaskStack@details@Concurrency@@QAE@XZ
// 地址: 0x6f4457
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (*(arg1 + 8) != 0)
    _free(*(arg1 + 8))
