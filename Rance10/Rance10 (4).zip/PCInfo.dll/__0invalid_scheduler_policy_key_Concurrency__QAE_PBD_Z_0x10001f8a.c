// 函数: ??0invalid_scheduler_policy_key@Concurrency@@QAE@PBD@Z
// 地址: 0x10001f8a
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::logic_error::std::out_of_range::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::out_of_range::`vftable'{for `std::logic_error'}
return result
