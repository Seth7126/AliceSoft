// 函数: __unwindfunclet$??1SchedulerBase@details@Concurrency@@UAE@XZ$8
// 地址: 0x6be232
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_401fb0(*(arg1 - 0x10) + 0xc8) __tailcall
