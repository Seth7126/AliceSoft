// 函数: sub_10007dc8
// 地址: 0x10007dc8
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10017024 = 0
int32_t result
result.b = 1
return result
