// 函数: __set_pgmptr
// 地址: 0x100038a1
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_10022088 = arg1
return arg1
