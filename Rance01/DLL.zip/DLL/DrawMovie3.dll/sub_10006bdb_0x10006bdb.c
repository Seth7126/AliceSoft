// 函数: sub_10006bdb
// 地址: 0x10006bdb
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::exception::std::bad_exception::VTable** result = arg1
sub_10001f0c(arg1, arg2)
*result = &std::bad_exception::`vftable'{for `std::exception'}
return result
