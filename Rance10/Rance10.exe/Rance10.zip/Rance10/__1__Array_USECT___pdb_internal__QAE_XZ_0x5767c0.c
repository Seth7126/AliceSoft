// 函数: ??1?$Array@USECT@@@pdb_internal@@QAE@XZ
// 地址: 0x5767c0
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result = *arg1

if (result != 0)
    result = _free(result)

return result
