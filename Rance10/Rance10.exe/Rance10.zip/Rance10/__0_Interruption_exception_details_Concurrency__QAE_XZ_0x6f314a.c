// 函数: ??0_Interruption_exception@details@Concurrency@@QAE@XZ
// 地址: 0x6f314a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::nested_scheduler_missing_detach::`vftable'{for `std::exception'}
return arg1
