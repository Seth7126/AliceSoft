// 函数: ??0improper_scheduler_reference@Concurrency@@QAE@XZ
// 地址: 0x6f3195
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::unsupported_os::`vftable'{for `std::exception'}
return arg1
