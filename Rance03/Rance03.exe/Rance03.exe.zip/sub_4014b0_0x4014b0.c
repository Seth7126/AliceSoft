// 函数: sub_4014b0
// 地址: 0x4014b0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f68c, 0x6da24e, nullptr)
return _atexit(sub_6d21a0)
