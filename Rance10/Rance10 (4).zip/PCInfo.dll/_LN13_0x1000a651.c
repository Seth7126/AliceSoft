// 函数: $LN13
// 地址: 0x1000a651
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_lowio_unlock_fh(arg1)
