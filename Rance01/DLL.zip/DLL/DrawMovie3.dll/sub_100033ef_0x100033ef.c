// 函数: sub_100033ef
// 地址: 0x100033ef
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return __unlock(0xc)
