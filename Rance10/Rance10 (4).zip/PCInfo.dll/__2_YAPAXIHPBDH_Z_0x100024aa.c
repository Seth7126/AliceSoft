// 函数: ??2@YAPAXIHPBDH@Z
// 地址: 0x100024aa
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return _free(arg1)
