// 函数: sub_10001be7
// 地址: 0x10001be7
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

sub_10001440(*(arg1 - 0x14), 1, nullptr)
sub_10004084(nullptr, nullptr)
noreturn
