// 函数: __mbsnextc
// 地址: 0x6c3630
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c3504(arg1, nullptr)
