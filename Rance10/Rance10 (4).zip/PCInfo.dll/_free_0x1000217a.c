// 函数: _free
// 地址: 0x1000217a
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return _free(arg1) __tailcall
