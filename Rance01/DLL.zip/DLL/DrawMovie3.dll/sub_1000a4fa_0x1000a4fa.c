// 函数: sub_1000a4fa
// 地址: 0x1000a4fa
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 != 0)
    return 1

return 0
