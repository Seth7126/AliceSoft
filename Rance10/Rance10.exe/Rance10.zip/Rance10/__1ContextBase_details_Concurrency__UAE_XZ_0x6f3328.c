// 函数: ??1ContextBase@details@Concurrency@@UAE@XZ
// 地址: 0x6f3328
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

Concurrency::details::ContextBase::CancellationBeaconStack::~CancellationBeaconStack(&arg1[0x23])
sub_6f3000(&arg1[0x20])
int32_t result = _free(arg1[0x22])
*arg1 = &Concurrency::Context::`vftable'
return result
