// 函数: sub_1000d0c0
// 地址: 0x1000d0c0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*(arg1 + 0x158) = timeGetTime() - *(arg1 + 0x158)
return 0
