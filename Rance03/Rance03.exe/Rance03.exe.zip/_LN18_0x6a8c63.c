// 函数: $LN18
// 地址: 0x6a8c63
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t* result = __getptd()

if (result[0x24] s> 0)
    result = __getptd()
    result[0x24] -= 1

return result
