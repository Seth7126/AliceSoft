// 函数: __rtatan2inf
// 地址: 0x1000b3b0
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10012ff4
arg1:1.b = arg1:1.b
arg1.b = arg1.b
