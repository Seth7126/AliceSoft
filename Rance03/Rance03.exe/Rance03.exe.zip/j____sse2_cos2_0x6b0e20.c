// 函数: j____sse2_cos2
// 地址: 0x6b0e20
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return ___sse2_cos2(arg1) __tailcall
