// 函数: sub_10001fc6
// 地址: 0x10001fc6
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void var_10
std::length_error::length_error(&var_10, arg1)
sub_10004084(&var_10, 0x10014348)
noreturn
