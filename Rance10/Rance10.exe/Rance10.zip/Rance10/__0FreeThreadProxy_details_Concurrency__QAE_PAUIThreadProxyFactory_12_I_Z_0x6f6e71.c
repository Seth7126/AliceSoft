// 函数: ??0FreeThreadProxy@details@Concurrency@@QAE@PAUIThreadProxyFactory@12@I@Z
// 地址: 0x6f6e71
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::IThreadProxy::Concurrency::details::ThreadProxy::VTable** var_8 = arg1
struct Concurrency::details::ThreadProxy::Concurrency::details::FreeThreadProxy::VTable** result =
    arg1
struct Concurrency::details::ThreadProxy::Concurrency::details::FreeThreadProxy::VTable** 
    result_1 = result
Concurrency::details::ThreadProxy::ThreadProxy(arg1, arg2, arg3)
*result = &Concurrency::details::FreeThreadProxy::`vftable'{for `Concurrency::details::ThreadProxy'}
result[0xc] = 0
void* edi_1 = &result[0xd]
*edi_1 = 0
*(edi_1 + 4) = 0
result[0xc] = 0
result[0xd].w = 0
return result
