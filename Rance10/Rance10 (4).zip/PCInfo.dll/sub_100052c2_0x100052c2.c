// 函数: sub_100052c2
// 地址: 0x100052c2
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(
    &data_10016c94, arg1)
