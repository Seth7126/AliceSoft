// 函数: sub_10001c00
// 地址: 0x10001c00
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 0xd4
return sub_1000c030() __tailcall
