// 函数: __unwindfunclet$??0SchedulerBase@details@Concurrency@@QAE@ABVSchedulerPolicy@2@@Z$9
// 地址: 0x6d156d
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_401fb0(*(arg1 - 0x10) + 0x118) __tailcall
