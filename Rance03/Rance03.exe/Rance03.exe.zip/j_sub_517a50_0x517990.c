// 函数: j_sub_517a50
// 地址: 0x517990
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_517a50(arg1) __tailcall
