// 函数: sub_1000250e
// 地址: 0x1000250e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void var_10
std::bad_alloc::bad_alloc(&var_10)
sub_10004084(&var_10, 0x100142d8)
noreturn
