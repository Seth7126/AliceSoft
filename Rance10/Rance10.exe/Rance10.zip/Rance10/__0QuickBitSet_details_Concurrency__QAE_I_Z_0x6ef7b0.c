// 函数: ??0QuickBitSet@details@Concurrency@@QAE@I@Z
// 地址: 0x6ef7b0
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = arg2
uint32_t eax_2 = (arg2 + 0x1f) u>> 5
int32_t ecx
ecx.b = mulu.dp.d(eax_2, 4) u>> 0x20 != 0
int32_t var_c = neg.d(ecx) | (eax_2 * 4)
uint32_t (* eax_4)[0x4] = sub_6e8787()
int32_t ecx_4 = *arg1 + 0x1f
arg1[1] = eax_4
_memset(eax_4, 0, ecx_4 u>> 5 << 2)
return arg1
