// 函数: sub_10001d6d
// 地址: 0x10001d6d
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10001d5d()

if ((arg2 & 1) != 0)
    int32_t var_c_1 = arg1
    sub_10001d52()

return arg1
