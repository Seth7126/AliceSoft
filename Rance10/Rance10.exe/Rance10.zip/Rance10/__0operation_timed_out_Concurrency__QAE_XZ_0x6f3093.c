// 函数: ??0operation_timed_out@Concurrency@@QAE@XZ
// 地址: 0x6f3093
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::context_unblock_unbalanced::`vftable'{for `std::exception'}
return arg1
