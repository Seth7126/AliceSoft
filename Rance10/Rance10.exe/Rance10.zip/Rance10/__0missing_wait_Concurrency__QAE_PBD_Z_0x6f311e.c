// 函数: ??0missing_wait@Concurrency@@QAE@PBD@Z
// 地址: 0x6f311e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::invalid_scheduler_policy_value::VTable** result = arg1
sub_62be70(arg1, arg2)
*result = &Concurrency::invalid_scheduler_policy_value::`vftable'{for `std::exception'}
return result
