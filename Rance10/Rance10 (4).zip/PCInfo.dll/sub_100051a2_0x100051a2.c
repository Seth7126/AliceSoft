// 函数: sub_100051a2
// 地址: 0x100051a2
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(
    &data_10016c90, arg1)
