// 函数: __convertTOStoQNaN
// 地址: 0x70de3c
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return 
