// 函数: ____lc_codepage_func
// 地址: 0x70d2fc
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

void* var_8 = arg1
void* eax = sub_714cce()
var_8 = *(eax + 0x4c)
___acrt_update_multibyte_info(eax, &var_8)
return *(var_8 + 8)
