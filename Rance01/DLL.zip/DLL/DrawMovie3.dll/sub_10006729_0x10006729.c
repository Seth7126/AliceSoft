// 函数: sub_10006729
// 地址: 0x10006729
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

terminate()
noreturn
