// 函数: ___acrt_uninitialize
// 地址: 0x10006228
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_execute_uninitializers(&data_1000fba0, &data_1000fc18)
