// 函数: ___scrt_initialize_default_local_stdio_options
// 地址: 0x1000293e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t ecx = data_10016bbc
data_10016bb8 |= 4
data_10016bbc = ecx
int32_t ecx_1 = data_10016bc4
data_10016bc0 |= 2
data_10016bc4 = ecx_1
return &data_10016bc0
