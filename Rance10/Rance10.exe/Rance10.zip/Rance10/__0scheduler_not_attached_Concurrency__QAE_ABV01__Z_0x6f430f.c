// 函数: ??0scheduler_not_attached@Concurrency@@QAE@ABV01@@Z
// 地址: 0x6f430f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::details::_Interruption_exception::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &Concurrency::details::_Interruption_exception::`vftable'{for `std::exception'}
return result
