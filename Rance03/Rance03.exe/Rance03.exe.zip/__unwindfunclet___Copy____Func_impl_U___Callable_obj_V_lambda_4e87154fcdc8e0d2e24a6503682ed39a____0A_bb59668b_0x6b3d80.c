// 函数: __unwindfunclet$?_Copy@?$_Func_impl@U?$_Callable_obj@V<lambda_4e87154fcdc8e0d2e24a6503682ed39a>@@$0A@@std@@V?$allocator@V?$_Func_class@XPAV?$message@I@Concurrency@@U_Nil@std@@U34@U34@U34@U34@U34@@std@@@2@XPAV?$message@I@Concurrency@@U_Nil@2@U62@U62@U62@U62@U62@@std@@UAEPAV?$_Func_base@XPAV?$message@I@Concurrency@@U_Nil@std@@U34@U34@U34@U34@U34@@2@PAX@Z$0
// 地址: 0x6b3d80
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_4 = *(arg1 + 8)
int32_t result = *(arg1 - 0x18)
int32_t result_1 = result
return result
