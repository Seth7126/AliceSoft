// 函数: sub_100030d5
// 地址: 0x100030d5
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return TlsAlloc()
