// 函数: Release
// 地址: 0x10016690
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10016240(&data_10021498)
