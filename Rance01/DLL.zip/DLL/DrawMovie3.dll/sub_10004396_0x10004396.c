// 函数: sub_10004396
// 地址: 0x10004396
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (sub_10009230(&data_1001c328) != 0)
    sub_10012c1b(arg1)

sub_10009173()
int32_t result = __initterm_e(0x1001a1ac, 0x1001a1c4)

if (result != 0)
    return result

sub_10004355(0x1001a1a0, _atexit(sub_10005d3f))

if (data_10023650 != 0 && sub_10009230(&data_10023650) != 0)
    data_10023650(0, 2, 0)

return 0
