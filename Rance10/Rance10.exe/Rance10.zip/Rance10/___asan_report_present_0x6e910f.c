// 函数: ___asan_report_present
// 地址: 0x6e910f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result
result.b = data_7fd610 != 0
return result
