// 函数: sub_402590
// 地址: 0x402590
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

jump(*(*(*(*data_797d28 + 0x10))(arg1) + 0x10))
