// 函数: sub_100020e4
// 地址: 0x100020e4
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax = sub_10003063(data_10021a10)

if (eax != 0)
    jump(eax)

sub_10003d38()
noreturn sub_10001fbc() __tailcall
