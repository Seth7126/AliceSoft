// 函数: sub_100042d7
// 地址: 0x100042d7
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

HANDLE eax
uint32_t ecx
int32_t edx
eax, ecx, edx = __FF_MSGBANNER()
sub_10002e04(eax, edx, ecx, arg1)
return sub_10003063(data_100202a0)(0xff)
