// 函数: ___acrt_initialize_heap
// 地址: 0x7197dc
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

HANDLE result = GetProcessHeap()
data_7fcae4 = result
result.b = result != 0
return result
