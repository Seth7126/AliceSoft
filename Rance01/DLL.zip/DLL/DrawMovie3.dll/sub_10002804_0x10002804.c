// 函数: sub_10002804
// 地址: 0x10002804
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10006bf8(arg2, arg3, arg4, arg5, arg1, 0, nullptr, 0)
