// 函数: ___initmbctable
// 地址: 0x10007e54
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (data_1002364c == 0)
    sub_10007cba(0xfffffffd)
    data_1002364c = 1

return 0
