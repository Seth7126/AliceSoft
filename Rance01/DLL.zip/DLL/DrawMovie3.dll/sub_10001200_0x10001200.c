// 函数: sub_10001200
// 地址: 0x10001200
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = &std::logic_error::`vftable'{for `std::exception'}

if (arg1[9] u>= 0x10)
    int32_t var_8_1 = arg1[4]
    sub_10001d52()

arg1[9] = 0xf
arg1[8] = 0
arg1[4].b = 0
return sub_10001f69(arg1) __tailcall
