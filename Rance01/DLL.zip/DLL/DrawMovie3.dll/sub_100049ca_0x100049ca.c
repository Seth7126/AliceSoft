// 函数: sub_100049ca
// 地址: 0x100049ca
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* esi = arg1

while (arg3 s> 0)
    arg1.b = arg2
    arg3 -= 1
    int32_t edx
    arg1, edx = sub_10004997(arg1, edx, arg4, esi)
    
    if (*esi == 0xffffffff)
        break
