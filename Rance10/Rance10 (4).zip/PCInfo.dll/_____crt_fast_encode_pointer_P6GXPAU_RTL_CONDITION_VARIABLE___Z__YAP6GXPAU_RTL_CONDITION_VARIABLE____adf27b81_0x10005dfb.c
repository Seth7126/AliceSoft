// 函数: ??$__crt_fast_encode_pointer@P6GXPAU_RTL_CONDITION_VARIABLE@@@Z@@YAP6GXPAU_RTL_CONDITION_VARIABLE@@@ZQ6GX0@Z@Z
// 地址: 0x10005dfb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ror.d(arg1, 0x20 - ((__security_cookie).b & 0x1f)) ^ __security_cookie
