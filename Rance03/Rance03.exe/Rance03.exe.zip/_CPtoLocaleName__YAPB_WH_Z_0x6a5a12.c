// 函数: ?CPtoLocaleName@@YAPB_WH@Z
// 地址: 0x6a5a12
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 == 0x3a4)
    return u"ja-JP"

if (arg1 == 0x3a8)
    return u"zh-CN"

if (arg1 == 0x3b5)
    return u"ko-KR"

if (arg1 == 0x3b6)
    return u"zh-TW"

return 0
