// 函数: ??0exception@std@@QAE@ABV01@@Z
// 地址: 0x69e47b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

arg1[1] = 0
*arg1 = &std::exception::`vftable'
arg1[2].b = 0
std::exception::operator=(arg1, arg2)
return arg1
