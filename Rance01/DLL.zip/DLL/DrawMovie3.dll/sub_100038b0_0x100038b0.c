// 函数: sub_100038b0
// 地址: 0x100038b0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax = sub_10003063(data_10022088)

if (eax != 0 && eax(arg1) != 0)
    return 1

return 0
