// 函数: ??_G?$time_put@DV?$ostreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@MAEPAXI@Z
// 地址: 0x6d7bd2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

sub_6d7950(arg1)

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
