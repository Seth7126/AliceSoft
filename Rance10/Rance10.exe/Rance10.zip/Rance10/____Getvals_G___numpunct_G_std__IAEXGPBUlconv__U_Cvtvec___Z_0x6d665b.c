// 函数: ??$_Getvals@G@?$numpunct@G@std@@IAEXGPBUlconv@@U_Cvtvec@@@Z
// 地址: 0x6d665b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t __saved_ebp
int32_t eax_1 = __security_cookie ^ &__saved_ebp
void var_34
void arg_c
__builtin_memcpy(&var_34, &arg_c, 0x2c)
void* var_44 = &var_34
int32_t var_48 = 0
*(arg1 + 0xc) = sub_6d6873(zx.d(**arg2))
void* var_50 = &var_34
int32_t var_54 = 0
int16_t result = sub_6d6873(zx.d(*arg2[1]))
*(arg1 + 0xe) = result
@__security_check_cookie@4(eax_1 ^ &__saved_ebp)
return result
