// 函数: __allmul
// 地址: 0x6a74b0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if ((arg4 | arg2) == 0)
    return arg1 * arg3

int32_t result
int32_t edx
edx:result = mulu.dp.d(arg1, arg3)
return result
