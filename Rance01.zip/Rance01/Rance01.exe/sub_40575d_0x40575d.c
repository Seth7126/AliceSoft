// 函数: sub_40575d
// 地址: 0x40575d
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t var_4 = *(arg1 - 0x14)
sub_6b4d5b()
sub_6b77db(0, nullptr)
noreturn
