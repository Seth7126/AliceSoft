// 函数: __errno
// 地址: 0x69bf6c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t* eax_2 = sub_69fc72()

if (eax_2 != 0)
    return &eax_2[2]

return 0x74a168
