// 函数: ??0regex_error@std@@QAE@W4error_type@regex_constants@1@@Z
// 地址: 0x6d07d0
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::runtime_error::std::regex_error::VTable** var_8 = arg1
struct std::runtime_error::std::regex_error::VTable** var_8_1 = arg1
sub_62be70(arg1, std::regex_error::_Stringify(arg2))
arg1[3] = arg2
*arg1 = &std::regex_error::`vftable'{for `std::runtime_error'}
return arg1
