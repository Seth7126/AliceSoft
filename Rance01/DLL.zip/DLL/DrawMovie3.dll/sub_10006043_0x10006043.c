// 函数: sub_10006043
// 地址: 0x10006043
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = &std::bad_exception::`vftable'{for `std::exception'}
return sub_10001f69(arg1) __tailcall
