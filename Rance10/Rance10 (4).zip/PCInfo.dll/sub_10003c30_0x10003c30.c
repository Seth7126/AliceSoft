// 函数: sub_10003c30
// 地址: 0x10003c30
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return 1
