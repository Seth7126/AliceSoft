// 函数: ??__E?s_cookie@Security@details@Concurrency@@2KA@@YAXXZ
// 地址: 0x402f31
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result = Concurrency::details::Security::InitializeCookie()
data_7fc308 = result
return result
