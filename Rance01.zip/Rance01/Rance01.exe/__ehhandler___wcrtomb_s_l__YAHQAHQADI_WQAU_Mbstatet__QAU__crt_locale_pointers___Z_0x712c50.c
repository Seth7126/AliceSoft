// 函数: __ehhandler$?_wcrtomb_s_l@@YAHQAHQADI_WQAU_Mbstatet@@QAU__crt_locale_pointers@@@Z
// 地址: 0x712c50
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b4885(*(arg1 - 0x24) ^ (arg1 + 0xc))
return sub_6bb3b5(0x77402c) __tailcall
