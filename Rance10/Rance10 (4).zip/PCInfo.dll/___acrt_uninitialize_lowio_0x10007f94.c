// 函数: ___acrt_uninitialize_lowio
// 地址: 0x10007f94
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

CRITICAL_SECTION* result

for (int32_t i = 0; i u< 0x200; i += 4)
    result = *(i + &data_10017028)
    
    if (result != 0)
        ___acrt_lowio_destroy_handle_array(result)
        *(i + &data_10017028) = 0

result.b = 1
return result
