// 函数: ??0CancellationTokenRegistration_TaskProc@details@Concurrency@@QAE@P6AXPAX@Z0H@Z
// 地址: 0x6f42e2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::details::_RefCounter::VTable** var_8 = arg1
struct Concurrency::details::_CancellationTokenRegistration::Concurrency::details::CancellationTokenRegistration_TaskProc::VTable
    ** result = arg1
struct Concurrency::details::_CancellationTokenRegistration::Concurrency::details::CancellationTokenRegistration_TaskProc::VTable
    ** result_1 = result
sub_697290(arg1, arg4)
result[0x1b] = arg2
result[0x1c] = arg3
*result = &Concurrency::details::CancellationTokenRegistration_TaskProc::`vftable'{for `Concurrency::details::_CancellationTokenRegistration'}
return result
