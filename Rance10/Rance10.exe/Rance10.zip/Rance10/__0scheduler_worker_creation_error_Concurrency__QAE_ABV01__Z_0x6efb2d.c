// 函数: ??0scheduler_worker_creation_error@Concurrency@@QAE@ABV01@@Z
// 地址: 0x6efb2d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::improper_scheduler_reference::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &Concurrency::improper_scheduler_reference::`vftable'{for `std::exception'}
return result
