// 函数: __cexit
// 地址: 0x6b708a
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6b6f1e(0, 0, 1)
