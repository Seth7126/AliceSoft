// 函数: sub_10006298
// 地址: 0x10006298
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* result = *arg2 + arg1

if (arg2[1] s< 0)
    return result

int32_t* edx_1 = arg2[1]
return result + *(*(edx_1 + arg1) + arg2[2]) + edx_1
