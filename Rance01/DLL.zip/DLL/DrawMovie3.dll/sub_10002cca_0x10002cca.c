// 函数: sub_10002cca
// 地址: 0x10002cca
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1
