// 函数: ??0WorkItem@details@Concurrency@@QAE@PAVInternalContextBase@12@@Z
// 地址: 0x6fd689
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 1
arg1[1] = sub_425af0(arg2 + 4)
arg1[2] = arg2
return arg1
