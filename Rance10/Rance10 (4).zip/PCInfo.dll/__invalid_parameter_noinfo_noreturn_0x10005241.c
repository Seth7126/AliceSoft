// 函数: __invalid_parameter_noinfo_noreturn
// 地址: 0x10005241
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

__invalid_parameter(0, 0, 0, 0, 0)
int32_t var_18
__builtin_memset(&var_18, 0, 0x14)
__invoke_watson()
noreturn
