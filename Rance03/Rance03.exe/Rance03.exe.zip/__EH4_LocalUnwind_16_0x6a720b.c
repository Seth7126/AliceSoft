// 函数: @_EH4_LocalUnwind@16
// 地址: 0x6a720b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __local_unwind4(arg4, arg1, arg2)
