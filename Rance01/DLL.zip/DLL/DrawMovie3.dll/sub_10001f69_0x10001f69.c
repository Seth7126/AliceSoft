// 函数: sub_10001f69
// 地址: 0x10001f69
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

bool cond:0 = arg1[2] == 0
*arg1 = &std::exception::`vftable'

if (not(cond:0))
    sub_10003602(arg1[1])
