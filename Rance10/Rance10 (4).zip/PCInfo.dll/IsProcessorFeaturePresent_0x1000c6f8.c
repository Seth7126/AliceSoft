// 函数: IsProcessorFeaturePresent
// 地址: 0x1000c6f8
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return IsProcessorFeaturePresent(ProcessorFeature) __tailcall
