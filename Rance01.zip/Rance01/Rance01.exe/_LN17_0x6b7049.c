// 函数: $LN17
// 地址: 0x6b7049
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (*(arg1 + 0x10) != 0)
    __unlock(8)
