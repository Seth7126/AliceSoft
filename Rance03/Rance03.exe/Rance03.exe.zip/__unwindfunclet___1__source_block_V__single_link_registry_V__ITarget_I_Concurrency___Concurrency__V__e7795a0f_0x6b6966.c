// 函数: __unwindfunclet$??1?$source_block@V?$single_link_registry@V?$ITarget@I@Concurrency@@@Concurrency@@V?$ordered_message_processor@I@2@@Concurrency@@UAE@XZ$3
// 地址: 0x6b6966
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_403510(*(arg1 - 0x10) + 0xb0) __tailcall
