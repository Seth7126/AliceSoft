// 函数: __ui64tow_s
// 地址: 0x10013149
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10013079(arg1, arg2, arg3, arg4, arg5, 0)
