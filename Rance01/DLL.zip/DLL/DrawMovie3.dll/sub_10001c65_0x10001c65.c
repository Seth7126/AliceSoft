// 函数: sub_10001c65
// 地址: 0x10001c65
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::logic_error::std::out_of_range::VTable** result = arg1
*result = &std::out_of_range::`vftable'{for `std::logic_error'}
sub_10001200(arg1)

if ((arg2 & 1) != 0)
    struct std::logic_error::std::out_of_range::VTable** result_1 = result
    sub_10001d52()

return result
