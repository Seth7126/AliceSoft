// 函数: j_sub_6b4978
// 地址: 0x6b479d
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6b4978(arg1) __tailcall
