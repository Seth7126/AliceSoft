// 函数: $LN13
// 地址: 0x10007978
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(5)
