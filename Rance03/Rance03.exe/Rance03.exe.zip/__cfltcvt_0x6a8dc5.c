// 函数: __cfltcvt
// 地址: 0x6a8dc5
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __cfltcvt_l(arg1, arg2, arg3, arg4, arg5, arg6, nullptr)
