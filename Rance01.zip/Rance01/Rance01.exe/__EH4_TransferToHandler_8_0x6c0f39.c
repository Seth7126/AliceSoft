// 函数: @_EH4_TransferToHandler@8
// 地址: 0x6c0f39
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

__NLG_Notify(arg1, arg2, 1)
jump(arg1)
