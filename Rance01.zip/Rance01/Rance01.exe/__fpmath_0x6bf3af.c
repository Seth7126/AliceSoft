// 函数: __fpmath
// 地址: 0x6bf3af
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t result = __cfltcvt_init()

if (arg1 != 0)
    result = sub_6c3f5d()

__fnclex()
return result
