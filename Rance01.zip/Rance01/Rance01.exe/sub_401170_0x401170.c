// 函数: sub_401170
// 地址: 0x401170
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1[5] u>= 0x10)
    *arg1
