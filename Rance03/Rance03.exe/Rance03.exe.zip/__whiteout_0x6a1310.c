// 函数: __whiteout
// 地址: 0x6a1310
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t result
int32_t i

do
    *arg1 += 1
    result = __getc_nolock(arg2)
    
    if (result == 0xffffffff)
        break
    
    i = _isspace(zx.d(result.b))
while (i != 0)
return result
