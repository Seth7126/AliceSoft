// 函数: _findenv
// 地址: 0x6ad897
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t* ecx = data_75c928
int32_t* esi = ecx
char* i = *esi

if (i != 0)
    do
        if (boost::math::tools::evaluate_rational<9,long double,long double,long double>(arg1, i, 
                arg2) == 0)
            int32_t eax_1
            eax_1.b = arg2[*esi]
            
            if (eax_1.b == 0x3d || eax_1.b == 0)
                return (esi - data_75c928) s>> 2
        
        esi = &esi[1]
        i = *esi
    while (i != 0)
    
    ecx = data_75c928

return neg.d((esi - ecx) s>> 2)
