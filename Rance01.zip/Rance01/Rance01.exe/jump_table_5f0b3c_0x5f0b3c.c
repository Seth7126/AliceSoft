// 函数: jump_table_5f0b3c
// 地址: 0x5f0b3c
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __das(arg1.b, eflags)
arg1.b = temp0
int32_t entry_ebx
char* ebx = entry_ebx | *arg4
arg3.b |= *ebx
*__return_addr += ebx.b
*__return_addr
*arg3 += arg1.b
arg1.b += *arg1
*arg2 += arg1
*arg3 += arg1.b
arg3.b += arg1:1.b
breakpoint
