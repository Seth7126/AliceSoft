// 函数: $LN37
// 地址: 0x6a6509
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t entry_ebx

if (entry_ebx != 0)
    __unlock(0)
