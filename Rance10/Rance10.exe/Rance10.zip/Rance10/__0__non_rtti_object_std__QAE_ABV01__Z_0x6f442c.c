// 函数: ??0__non_rtti_object@std@@QAE@ABV01@@Z
// 地址: 0x6f442c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::missing_wait::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &Concurrency::missing_wait::`vftable'{for `std::exception'}
return result
