// 函数: __amsg_exit
// 地址: 0x69cfb1
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

__FF_MSGBANNER()
__NMSG_WRITE(arg1)
__exit(0xff)
noreturn
