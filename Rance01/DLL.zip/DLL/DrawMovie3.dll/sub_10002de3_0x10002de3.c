// 函数: sub_10002de3
// 地址: 0x10002de3
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = data_10020058.d
data_10020058.d = (not.d(arg2) & result) | (arg1 & arg2)
return result
