// 函数: ___acrt_locale_free_monetary
// 地址: 0x10009c27
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    return 

int32_t eax_1 = *(arg1 + 0xc)

if (eax_1 != data_1001670c)
    __free_base(eax_1)

int32_t eax_2 = *(arg1 + 0x10)

if (eax_2 != data_10016710)
    __free_base(eax_2)

int32_t eax_3 = *(arg1 + 0x14)

if (eax_3 != data_10016714)
    __free_base(eax_3)

int32_t eax_4 = *(arg1 + 0x18)

if (eax_4 != data_10016718)
    __free_base(eax_4)

int32_t eax_5 = *(arg1 + 0x1c)

if (eax_5 != data_1001671c)
    __free_base(eax_5)

int32_t eax_6 = *(arg1 + 0x20)

if (eax_6 != data_10016720)
    __free_base(eax_6)

int32_t eax_7 = *(arg1 + 0x24)

if (eax_7 != data_10016724)
    __free_base(eax_7)

int32_t eax_8 = *(arg1 + 0x38)

if (eax_8 != data_10016738)
    __free_base(eax_8)

int32_t eax_9 = *(arg1 + 0x3c)

if (eax_9 != data_1001673c)
    __free_base(eax_9)

int32_t eax_10 = *(arg1 + 0x40)

if (eax_10 != data_10016740)
    __free_base(eax_10)

int32_t eax_11 = *(arg1 + 0x44)

if (eax_11 != data_10016744)
    __free_base(eax_11)

int32_t eax_12 = *(arg1 + 0x48)

if (eax_12 != data_10016748)
    __free_base(eax_12)

int32_t eax = *(arg1 + 0x4c)

if (eax != data_1001674c)
    __free_base(eax)
