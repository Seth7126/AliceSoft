// 函数: __CIcos_pentium4
// 地址: 0x6b1c60
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return start(zx.o(fconvert.d(arg1)))
