// 函数: ?HasRealizedChores@ScheduleGroupSegmentBase@details@Concurrency@@IBE_NXZ
// 地址: 0x4fe220
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result
result.b = *(arg1 + 0x28) != 0
return result
