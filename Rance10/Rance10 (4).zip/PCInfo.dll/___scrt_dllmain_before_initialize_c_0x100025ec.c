// 函数: ___scrt_dllmain_before_initialize_c
// 地址: 0x100025ec
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___scrt_initialize_onexit_tables(0) != 0
