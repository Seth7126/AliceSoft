// 函数: ??$_LStrxfrm@G@std@@YAIPAG0PBG1PBU_Collvec@@@Z
// 地址: 0x6d6840
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result = (arg4 - arg3) s>> 1
int32_t eax_2 = (arg2 - arg1) s>> 1

if (result u<= eax_2)
    _memcpy_s(arg1, eax_2 * 2, arg3, result * 2)

return result
