// 函数: sub_100056c2
// 地址: 0x100056c2
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

sub_1000624c()
noreturn
