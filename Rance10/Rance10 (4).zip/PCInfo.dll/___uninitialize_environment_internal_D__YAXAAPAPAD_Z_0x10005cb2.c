// 函数: ??$uninitialize_environment_internal@D@@YAXAAPAPAD@Z
// 地址: 0x10005cb2
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* result = *arg1

if (result != data_10016db8)
    result = free_environment<char>(result)

return result
