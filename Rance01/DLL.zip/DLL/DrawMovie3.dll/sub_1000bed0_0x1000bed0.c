// 函数: sub_1000bed0
// 地址: 0x1000bed0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = arg2
EnterCriticalSection(arg2)
return arg1
