// 函数: ??1_Lockit@std@@QAE@XZ
// 地址: 0x6d0c5a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result = *arg1

if (result == 0)
    return ___acrt_unlock(4)

if (result s< 8)
    result = OsAwareDeleteFile(result * 0x18 + &data_7fb9e0)

return result
