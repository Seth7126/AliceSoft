// 函数: __fload_withFB
// 地址: 0x100173e5
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if ((*(arg2 + 4) & 0x7ff00000) != 0x7ff00000)
    return fconvert.t(*arg2)

int32_t var_4 = *(arg2 + 4) | 0x7fff0000
int32_t ecx = *arg2
int32_t var_6 = *(arg2 + 4) << 0xb | ecx u>> 0xffffffeb
*(arg2 + 4)
return (ecx << 0xb).t
