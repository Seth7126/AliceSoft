// 函数: j_sub_5da690
// 地址: 0x5dc8d0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5da690(arg1) __tailcall
