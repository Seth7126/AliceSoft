// 函数: ??0stl_critical_section_vista@details@Concurrency@@QAE@XZ
// 地址: 0x6d5c8b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &Concurrency::details::stl_critical_section_vista::`vftable'{for `Concurrency::details::stl_critical_section_interface'}
___crtInitializeCriticalSectionEx(&arg1[1], 0xfa0, 0)
return arg1
