// 函数: sub_401430
// 地址: 0x401430
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f62c, 0x6da21b, nullptr)
return _atexit(sub_6d2020)
