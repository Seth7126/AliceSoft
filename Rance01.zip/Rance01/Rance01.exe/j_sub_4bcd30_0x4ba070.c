// 函数: j_sub_4bcd30
// 地址: 0x4ba070
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_4bcd30(arg1) __tailcall
