// 函数: sub_1000264e
// 地址: 0x1000264e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* eax_1 = *(arg1 - 0x14)
return sub_10005f69(**eax_1, eax_1)
