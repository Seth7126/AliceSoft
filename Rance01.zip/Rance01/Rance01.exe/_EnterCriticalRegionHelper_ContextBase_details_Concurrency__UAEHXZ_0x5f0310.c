// 函数: ?EnterCriticalRegionHelper@ContextBase@details@Concurrency@@UAEHXZ
// 地址: 0x5f0310
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t result = *(arg1 + 0xc) + 1
*(arg1 + 0xc) = result
return result
