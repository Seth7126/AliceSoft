// 函数: j_sub_70dd4b
// 地址: 0x70da9e
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_70dd4b() __tailcall
