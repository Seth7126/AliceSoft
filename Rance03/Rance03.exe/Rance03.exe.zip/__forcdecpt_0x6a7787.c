// 函数: __forcdecpt
// 地址: 0x6a7787
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_6a774d(arg1, nullptr)
