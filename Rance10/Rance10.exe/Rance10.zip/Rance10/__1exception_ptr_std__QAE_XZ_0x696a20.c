// 函数: ??1exception_ptr@std@@QAE@XZ
// 地址: 0x696a20
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return __ExceptionPtrDestroy(arg1)
