// 函数: sub_100010b0
// 地址: 0x100010b0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* eax = arg1[-2]
arg1 = eax
jump(*(*eax + 4))
