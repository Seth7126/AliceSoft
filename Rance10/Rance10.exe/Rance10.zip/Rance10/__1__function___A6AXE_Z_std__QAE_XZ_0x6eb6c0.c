// 函数: ??1?$function@$$A6AXE@Z@std@@QAE@XZ
// 地址: 0x6eb6c0
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

j_sub_6f09b1()
return Concurrency::details::_NonReentrantLock::_Acquire(arg1) __tailcall
