// 函数: __errno
// 地址: 0x10003c87
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* eax_2 = sub_10003236()

if (eax_2 != 0)
    return eax_2 + 8

return 0x10020298
