// 函数: _initialize_pointers
// 地址: 0x10006146
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = 0x20
int32_t __security_cookie_1 = __security_cookie
sub_100051a2(__security_cookie_1)
sub_100052c2(__security_cookie_1)
___acrt_initialize_signal_handlers(__security_cookie_1)
sub_100083f8(__security_cookie_1)
__initp_misc_invarg(__security_cookie_1)
int32_t result
result.b = 1
return result
