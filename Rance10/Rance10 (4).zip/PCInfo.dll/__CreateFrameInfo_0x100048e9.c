// 函数: __CreateFrameInfo
// 地址: 0x100048e9
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

*arg1 = arg2
arg1[1] = *(sub_10004538() + 0x24)
*(sub_10004538() + 0x24) = arg1
return arg1
