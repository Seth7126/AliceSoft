// 函数: ___set_app_type
// 地址: 0x6c08fc
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_797ac4 = arg1
return arg1
