// 函数: sub_401140
// 地址: 0x401140
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

char* eax = arg2

do
    arg1 = *eax
    eax = &eax[1]
while (arg1 != 0)

return sub_401270(arg3, eax - &eax[1], arg2)
