// 函数: sub_1000ced0
// 地址: 0x1000ced0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = (*(**(arg1 + 0xd8) + 0x94))(arg2)

if (result s< 0)
    return result

int32_t var_c_1 = arg2
return sub_1000c4a0()
