// 函数: __ui64tow_s
// 地址: 0x6c386b
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c37a4(arg1, arg2, arg3, arg4, arg5, 0)
