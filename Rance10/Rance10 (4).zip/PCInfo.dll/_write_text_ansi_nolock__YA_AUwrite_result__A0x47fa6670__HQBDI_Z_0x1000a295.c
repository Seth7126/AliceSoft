// 函数: ?write_text_ansi_nolock@@YA?AUwrite_result@?A0x47fa6670@@HQBDI@Z
// 地址: 0x1000a295
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

__alloca_probe(0x1410)
int32_t __saved_ebp
int32_t var_8 = __security_cookie ^ &__saved_ebp
char* ebx = arg3
int32_t edi
int32_t var_10 = edi
HANDLE hFile = *((&data_10017028)[arg2 s>> 6] + (arg2 & 0x3f) * 0x30 + 0x18)
*arg1 = 0
void* eax_6 = arg4 + ebx
arg1[1] = 0
arg1[2] = 0
HANDLE hFile_1 = hFile
void* var_140c = eax_6

while (ebx u< eax_6)
    uint8_t buffer[0x13e4]
    uint8_t (* edi_1)[0x13e4] = &buffer
    
    while (ebx u< eax_6)
        eax_6.b = *ebx
        ebx = &ebx[1]
        
        if (eax_6.b == 0xa)
            arg1[2] += 1
            *edi_1 = 0xd
            edi_1 = &(*edi_1)[1]
        
        *edi_1 = eax_6.b
        edi_1 = &(*edi_1)[1]
        eax_6 = var_140c
        int32_t __saved_esi
        
        if (edi_1 u>= &__saved_esi:3)
            break
    
    uint32_t nNumberOfBytesToWrite = edi_1 - &buffer
    uint32_t numberOfBytesWritten
    
    if (WriteFile(hFile, &buffer, nNumberOfBytesToWrite, &numberOfBytesWritten, nullptr) == 0)
        *arg1 = GetLastError()
        break
    
    uint32_t numberOfBytesWritten_1 = numberOfBytesWritten
    arg1[1] += numberOfBytesWritten_1
    
    if (numberOfBytesWritten_1 u< nNumberOfBytesToWrite)
        break
    
    eax_6 = var_140c
    hFile = hFile_1

int32_t entry_ebx
@__security_check_cookie@4(entry_ebx ^ &__saved_ebp)
return arg1
