// 函数: ??8type_info@@QBE_NABV0@@Z
// 地址: 0x69ad89
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax_3 = _strcmp(arg2 + 9, arg1 + 9)
int32_t eax_4 = neg.d(eax_3)
return sbb.d(eax_4, eax_4, eax_3 != 0) + 1
