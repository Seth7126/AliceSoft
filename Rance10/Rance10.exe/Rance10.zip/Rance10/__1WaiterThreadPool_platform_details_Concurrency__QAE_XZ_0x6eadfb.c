// 函数: ??1WaiterThreadPool@platform@details@Concurrency@@QAE@XZ
// 地址: 0x6eadfb
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t* ecx = *arg1

if (ecx != 0)
    *ecx[0x40] = 0
    Concurrency::details::platform::WaiterThread::notify(ecx, 1)

return sub_6ea7d7(&arg1[1]) __tailcall
