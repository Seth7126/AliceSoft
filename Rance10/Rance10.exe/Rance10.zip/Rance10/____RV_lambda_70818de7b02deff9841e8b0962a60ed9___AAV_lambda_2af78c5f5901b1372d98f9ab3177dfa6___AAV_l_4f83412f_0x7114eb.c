// 函数: ??$?RV<lambda_70818de7b02deff9841e8b0962a60ed9>@@AAV<lambda_2af78c5f5901b1372d98f9ab3177dfa6>@@AAV<lambda_f51fe5fd7c79a33db34fc9310f277369>@@@?$__crt_seh_guarded_call@X@@QAEX$$QAV<lambda_70818de7b02deff9841e8b0962a60ed9>@@AAV<lambda_2af78c5f5901b1372d98f9ab3177dfa6>@@AAV<lambda_f51fe5fd7c79a33db34fc9310f277369>@@@Z
// 地址: 0x7114eb
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t __saved_ebp_1 = 8
int32_t var_8 = 0x7de580
int32_t (* var_10)(int32_t* arg1, void* arg2, int32_t arg3) = __except_handler4
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
uint32_t __security_cookie_1 = __security_cookie
int32_t var_8_3 = 0x7de580 ^ __security_cookie_1
int32_t __saved_ebp
int32_t var_2c = __security_cookie_1 ^ &__saved_ebp
int32_t* var_1c = &var_2c
void* const var_30 = &data_7114f7
int32_t var_8_4 = 0xfffffffe
int32_t var_c = var_8_3
fsbase->NtTib.ExceptionList = &ExceptionList
int32_t var_8_1 = 0
<lambda_2af78c5f5901b1372d98f9ab3177dfa6>::operator()(arg1)
int32_t var_8_2 = 0xfffffffe
void* result = $LN14(&__saved_ebp)
fsbase->NtTib.ExceptionList = ExceptionList
void* const __saved_ebp_2 = &data_711514
return result
