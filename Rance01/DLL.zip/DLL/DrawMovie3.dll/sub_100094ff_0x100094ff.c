// 函数: sub_100094ff
// 地址: 0x100094ff
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000b210(*(arg1 + 8))
