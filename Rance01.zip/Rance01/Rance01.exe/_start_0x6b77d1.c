// 函数: _start
// 地址: 0x6b77d1
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6c148d()
int32_t esi
int32_t edi
return sub_6b7664(esi, edi) __tailcall
