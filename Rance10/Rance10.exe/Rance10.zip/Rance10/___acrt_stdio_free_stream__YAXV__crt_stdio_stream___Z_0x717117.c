// 函数: ?__acrt_stdio_free_stream@@YAXV__crt_stdio_stream@@@Z
// 地址: 0x717117
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 0
arg1[1] = 0
arg1[2] = 0
arg1[4] = 0xffffffff
arg1[5] = 0
arg1[6] = 0
arg1[7] = 0
arg1[3]
arg1[3] = 0
return &arg1[3]
