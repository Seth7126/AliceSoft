// 函数: __unwindfunclet$??1VirtualProcessor@details@Concurrency@@UAE@XZ$1
// 地址: 0x6b41bc
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_697ef0(*(arg1 - 0x10) + 0x98) __tailcall
