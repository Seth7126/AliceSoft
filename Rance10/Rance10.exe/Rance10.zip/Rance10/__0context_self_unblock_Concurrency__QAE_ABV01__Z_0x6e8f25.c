// 函数: ??0context_self_unblock@Concurrency@@QAE@ABV01@@Z
// 地址: 0x6e8f25
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::bad_alloc::std::bad_array_new_length::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &std::bad_array_new_length::`vftable'{for `std::bad_alloc'}
return result
