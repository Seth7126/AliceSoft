// 函数: ___acrt_initialize_command_line
// 地址: 0x71b84f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

data_7fcb18 = GetCommandLineA()
data_7fcb1c = GetCommandLineW()
PWSTR result
result.b = 1
return result
