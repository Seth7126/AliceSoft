// 函数: __RTC_Terminate
// 地址: 0x6a75b5
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

for (void* const i = &data_727290; i u< &data_727290; i += 4)
    int32_t eax = *i
    
    if (eax != 0)
        eax()
