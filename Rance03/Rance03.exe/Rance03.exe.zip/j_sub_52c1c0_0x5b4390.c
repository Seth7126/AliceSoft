// 函数: j_sub_52c1c0
// 地址: 0x5b4390
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_52c1c0(arg1) __tailcall
