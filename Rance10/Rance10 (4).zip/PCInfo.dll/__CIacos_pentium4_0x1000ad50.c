// 函数: __CIacos_pentium4
// 地址: 0x1000ad50
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

double var_10 = fconvert.d(arg1)
return start(zx.o(var_10), var_10)
