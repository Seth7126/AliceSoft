// 函数: ___crtGetTickCount64
// 地址: 0x6e7aa3
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbea4 ^ __security_cookie

if (esi_1 == 0)
    return GetTickCount()

j_sub_4033e0()
return esi_1()
