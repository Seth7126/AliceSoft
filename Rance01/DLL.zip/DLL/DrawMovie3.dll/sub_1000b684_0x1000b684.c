// 函数: sub_1000b684
// 地址: 0x1000b684
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000b5aa(1)
