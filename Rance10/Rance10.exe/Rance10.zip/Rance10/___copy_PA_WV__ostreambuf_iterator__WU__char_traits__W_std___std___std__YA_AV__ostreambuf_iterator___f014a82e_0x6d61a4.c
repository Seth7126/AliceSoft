// 函数: ??$copy@PA_WV?$ostreambuf_iterator@_WU?$char_traits@_W@std@@@std@@@std@@YA?AV?$ostreambuf_iterator@_WU?$char_traits@_W@std@@@0@PA_W0V10@@Z
// 地址: 0x6d61a4
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_8 = arg3
int32_t var_c = arg3
int32_t* eax = sub_6d623f(&var_c, arg5, arg6, arg7, arg8)
*arg4 = *eax
arg4[1] = eax[1]
return arg4
