// 函数: ___crtCreateSemaphoreExW
// 地址: 0x6e794d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

uint32_t __security_cookie_1 = __security_cookie
int32_t esi_1 = data_7fbe70 ^ __security_cookie_1

if (esi_1 != 0)
    j_sub_4033e0()
    return esi_1(arg1, arg2, arg3, arg4, arg5, arg6)

int32_t esi_3 = data_7fbe6c ^ __security_cookie_1

if (esi_3 == 0)
    return 0

j_sub_4033e0()
return esi_3(arg1, arg2, arg3, arg4)
