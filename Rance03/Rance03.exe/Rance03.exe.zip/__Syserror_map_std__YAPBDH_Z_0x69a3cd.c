// 函数: ?_Syserror_map@std@@YAPBDH@Z
// 地址: 0x69a3cd
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

void* const eax = &data_6d4848

while (*eax != arg1)
    eax += 8
    
    if (*(eax + 4) == 0)
        return 0

return *(eax + 4)
