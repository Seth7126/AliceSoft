// 函数: sub_1000628f
// 地址: 0x1000628f
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

terminate()
noreturn
