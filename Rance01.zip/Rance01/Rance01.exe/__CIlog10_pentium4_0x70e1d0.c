// 函数: __CIlog10_pentium4
// 地址: 0x70e1d0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_70e1ee(zx.o(fconvert.d(arg1)))
