// 函数: sub_401040
// 地址: 0x401040
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*arg1 = &common::CStringWrapper::`vftable'{for `IString'}

if (arg1[6] u>= 0x10)
    int32_t var_4_1 = arg1[1]
    sub_6b4d5b()

arg1[6] = 0xf
arg1[5] = 0
arg1[1].b = 0
return 0
