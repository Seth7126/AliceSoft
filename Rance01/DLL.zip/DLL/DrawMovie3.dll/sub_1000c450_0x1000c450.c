// 函数: sub_1000c450
// 地址: 0x1000c450
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* ecx = arg1[0x14]

if (ecx != 0)
    sub_10011fc0(ecx)

(*(*arg1 + 0x28))(1)
return 0
