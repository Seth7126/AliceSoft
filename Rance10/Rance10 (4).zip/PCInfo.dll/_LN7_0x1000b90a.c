// 函数: $LN7
// 地址: 0x1000b90a
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_lowio_unlock_fh(**(arg1 + 0x10))
