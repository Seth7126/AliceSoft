// 函数: sub_1000cfc0
// 地址: 0x1000cfc0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = sub_1000f7d0(arg1, arg2)

if (result s< 0)
    return result

return (*(**(arg1 + 0xd8) + 0x90))(arg2)
