// 函数: ??$__crt_fast_encode_pointer@PAP6AXXZ@@YAPAP6AXXZQAP6AXXZ@Z
// 地址: 0x6e8584
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return ror.d(arg1, 0x20 - ((__security_cookie).b & 0x1f)) ^ __security_cookie
