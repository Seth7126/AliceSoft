// 函数: sub_10001d19
// 地址: 0x10001d19
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax
int32_t edx
int32_t ebp
int32_t esi
int32_t edi

if (arg1 != __security_cookie)
    noreturn sub_10002bc6(eax, edx, arg1, ebp, esi, edi) __tailcall
