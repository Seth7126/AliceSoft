// 函数: sub_1000c030
// 地址: 0x1000c030
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* eax = arg1[-2]
arg1 = eax
jump(*(*eax + 8))
