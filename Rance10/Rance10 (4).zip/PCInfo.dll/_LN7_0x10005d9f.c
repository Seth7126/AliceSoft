// 函数: $LN7
// 地址: 0x10005d9f
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(**(arg1 + 0x10))
