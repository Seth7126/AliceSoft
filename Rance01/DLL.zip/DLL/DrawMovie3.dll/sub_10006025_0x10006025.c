// 函数: sub_10006025
// 地址: 0x10006025
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void arg_4
sub_10001e9c(arg1, &arg_4)
*arg1 = &std::bad_exception::`vftable'{for `std::exception'}
return arg1
