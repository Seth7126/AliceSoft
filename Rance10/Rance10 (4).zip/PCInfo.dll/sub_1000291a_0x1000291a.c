// 函数: sub_1000291a
// 地址: 0x1000291a
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return InitializeSListHead(&data_10016bb0)
