// 函数: ?initialize_multibyte@@YAHXZ
// 地址: 0x10009254
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = ___acrt_initialize_multibyte() == 0
return result
