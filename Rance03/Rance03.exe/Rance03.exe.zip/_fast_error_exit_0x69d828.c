// 函数: _fast_error_exit
// 地址: 0x69d828
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (data_75d418 == 1)
    __FF_MSGBANNER()

__NMSG_WRITE(arg1)
___crtExitProcess(0xff)
noreturn
