// 函数: sub_10002143
// 地址: 0x10002143
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

*arg1
