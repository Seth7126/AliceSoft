// 函数: ___free_lconv_num
// 地址: 0x6aaa93
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 == 0)
    return 

int32_t eax_1 = *arg1

if (eax_1 != data_74b0b8)
    _free(eax_1)

int32_t eax_2 = arg1[1]

if (eax_2 != data_74b0bc)
    _free(eax_2)

int32_t eax_3 = arg1[2]

if (eax_3 != data_74b0c0)
    _free(eax_3)

int32_t eax_4 = arg1[0xc]

if (eax_4 != data_74b0e8)
    _free(eax_4)

int32_t eax = arg1[0xd]

if (eax != data_74b0ec)
    _free(eax)
