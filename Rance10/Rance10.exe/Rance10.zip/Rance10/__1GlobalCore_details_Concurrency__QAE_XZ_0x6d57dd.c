// 函数: ??1GlobalCore@details@Concurrency@@QAE@XZ
// 地址: 0x6d57dd
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return operator new(*(arg1 + 0x20))
