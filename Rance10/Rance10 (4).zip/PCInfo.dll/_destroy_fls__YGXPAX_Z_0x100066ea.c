// 函数: ?destroy_fls@@YGXPAX@Z
// 地址: 0x100066ea
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    return 

int32_t var_8_1 = arg1
int32_t** ecx
destroy_ptd(ecx)
__free_base(arg1)
