// 函数: sub_10006fa2
// 地址: 0x10006fa2
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (*(arg1 - 0x1c) != 0)
    __unlock(0)
