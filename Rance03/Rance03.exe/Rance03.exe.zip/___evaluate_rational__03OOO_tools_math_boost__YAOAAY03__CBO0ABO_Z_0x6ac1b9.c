// 函数: ??$evaluate_rational@$03OOO@tools@math@boost@@YAOAAY03$$CBO0ABO@Z
// 地址: 0x6ac1b9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_6ac087(arg1, arg2, arg3, nullptr)
