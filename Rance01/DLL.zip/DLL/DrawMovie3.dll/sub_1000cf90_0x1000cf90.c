// 函数: sub_1000cf90
// 地址: 0x1000cf90
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

jump(*(**(arg1 + 0xd8) + 0x74))
