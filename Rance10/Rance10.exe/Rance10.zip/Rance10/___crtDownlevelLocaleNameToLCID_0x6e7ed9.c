// 函数: ___crtDownlevelLocaleNameToLCID
// 地址: 0x6e7ed9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg1 != 0)
    int32_t eax_1 = _GetTableIndexFromLocaleName(arg1)
    
    if (eax_1 s>= 0 && eax_1 u< 0xe4)
        return *((eax_1 << 3) + &data_750988)

return 0
