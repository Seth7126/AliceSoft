// 函数: __ehhandler$??_U@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x10018fd3
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10001d19(*(arg1 - 0x14) ^ (arg1 + 0xc))
return sub_10002804(0x1001e4f0) __tailcall
