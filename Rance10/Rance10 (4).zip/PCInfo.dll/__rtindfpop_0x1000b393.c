// 函数: __rtindfpop
// 地址: 0x1000b393
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10012fe0

if (*(arg1 - 0x90) s> 0)
    return 

return sub_1000b3a6(arg1) __tailcall
