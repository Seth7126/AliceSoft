// 函数: ?getSystemCP@@YAHH@Z
// 地址: 0x1000755c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* var_14
_LocaleUpdate::_LocaleUpdate(&var_14, nullptr)
data_10017004 = 0
uint32_t result = arg1

if (result == 0xfffffffe)
    data_10017004 = 1
    result = GetOEMCP()
else if (result == 0xfffffffd)
    data_10017004 = 1
    result = GetACP()
else if (result == 0xfffffffc)
    data_10017004 = 1
    void* var_10
    result = *(var_10 + 8)

char var_8

if (var_8 != 0)
    void* ecx_1 = var_14
    *(ecx_1 + 0x350) &= 0xfffffffd

return result
