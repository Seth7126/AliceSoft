// 函数: __unwindfunclet$??1VirtualProcessor@details@Concurrency@@UAE@XZ$2
// 地址: 0x6be216
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_401fb0(*(arg1 - 0x10) + 0x98) __tailcall
