// 函数: __msize
// 地址: 0x69e6f2
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 != 0)
    return HeapSize(data_75cb40, HEAP_NONE, arg1)

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
