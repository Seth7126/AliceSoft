// 函数: ??8HardwareAffinity@details@Concurrency@@QAE_NABU012@@Z
// 地址: 0x6fcd8b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg2[1].w == arg1[1].w && *arg2 == *arg1)
    return 1

return 0
