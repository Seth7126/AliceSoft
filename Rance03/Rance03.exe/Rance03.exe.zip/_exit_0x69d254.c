// 函数: _exit
// 地址: 0x69d254
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

_doexit(status, 0, 0)
