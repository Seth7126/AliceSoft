// 函数: ___vswprintf_l
// 地址: 0x69c603
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return _fread_s(arg1, 0xffffffff, arg2, arg3, arg4)
