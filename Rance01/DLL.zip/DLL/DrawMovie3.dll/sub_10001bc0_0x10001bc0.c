// 函数: sub_10001bc0
// 地址: 0x10001bc0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::exception::std::bad_alloc::VTable** result = arg1
sub_10001f0c(arg1, arg2)
*result = &std::bad_alloc::`vftable'{for `std::exception'}
return result
