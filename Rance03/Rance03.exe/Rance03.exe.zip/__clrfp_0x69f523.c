// 函数: __clrfp
// 地址: 0x69f523
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int16_t ecx
int16_t var_8 = ecx
__fnclex()
bool c0
bool c1
bool c2
bool c3
return sx.d((c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe)
