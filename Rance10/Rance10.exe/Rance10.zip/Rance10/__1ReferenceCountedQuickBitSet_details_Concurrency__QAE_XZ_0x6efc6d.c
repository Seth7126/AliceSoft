// 函数: ??1ReferenceCountedQuickBitSet@details@Concurrency@@QAE@XZ
// 地址: 0x6efc6d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

_free(*(arg1 + 8))
return _free(*(arg1 + 4))
