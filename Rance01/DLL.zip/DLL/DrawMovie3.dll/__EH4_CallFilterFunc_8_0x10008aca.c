// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x10008aca
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t ecx
return ecx()
