// 函数: j_sub_58cec0
// 地址: 0x58cd20
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_58cec0(arg1) __tailcall
