// 函数: ___AdjustPointer
// 地址: 0x10003b89
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* esi = arg2[1]
void* result = *arg2 + arg1

if (esi s< 0)
    return result

return result + *(*(esi + arg1) + arg2[2]) + esi
