// 函数: sub_100042a7
// 地址: 0x100042a7
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t edi
int32_t var_8 = edi
uint32_t dwMilliseconds = 0x3e8
HMODULE i

do
    Sleep(dwMilliseconds)
    i = GetModuleHandleW(arg1)
    dwMilliseconds += 0x3e8
    
    if (dwMilliseconds u> 0xea60)
        break
while (i == 0)

return i
