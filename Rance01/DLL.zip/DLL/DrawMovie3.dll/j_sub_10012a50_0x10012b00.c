// 函数: j_sub_10012a50
// 地址: 0x10012b00
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10012a50(arg1, arg2) __tailcall
