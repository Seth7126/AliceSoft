// 函数: sub_10004355
// 地址: 0x10004355
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

for (int32_t* i = arg1; i u< arg2; i = &i[1])
    arg1 = *i
    
    if (arg1 != 0)
        arg1()
