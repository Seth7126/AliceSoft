// 函数: __invalid_parameter_noinfo
// 地址: 0x6b8709
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return __invalid_parameter(0, 0, 0, 0, 0)
