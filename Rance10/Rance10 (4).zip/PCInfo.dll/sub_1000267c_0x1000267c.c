// 函数: sub_1000267c
// 地址: 0x1000267c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

___acrt_uninitialize_critical(0)
return ___vcrt_uninitialize_critical() __tailcall
