// 函数: sub_1000a7d8
// 地址: 0x1000a7d8
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 == 0)
    return 

void* eax_1 = *arg1

if (eax_1 != data_10020df8)
    sub_10003602(eax_1)

struct _EXCEPTION_REGISTRATION_RECORD** eax = arg1[1]

if (eax != data_10020dfc)
    sub_10003602(eax)

void* esi_1 = arg1[2]

if (esi_1 != data_10020e00)
    sub_10003602(esi_1)
