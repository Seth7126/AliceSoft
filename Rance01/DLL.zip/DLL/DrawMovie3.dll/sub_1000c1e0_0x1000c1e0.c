// 函数: sub_1000c1e0
// 地址: 0x1000c1e0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg2 != 1)
    SetEvent(*(arg1 + 0x58))
    return 0

ResetEvent(*(arg1 + 0x58))
return 0
