// 函数: ___acrt_locale_free_lc_time_if_unreferenced
// 地址: 0x71cc44
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg1 != 0 && arg1 != &data_7563b0 && arg1[0x2c] == 0)
    ___acrt_locale_free_time(arg1)
    __free_base(arg1)
