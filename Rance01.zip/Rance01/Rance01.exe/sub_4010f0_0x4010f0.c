// 函数: sub_4010f0
// 地址: 0x4010f0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*(arg1 + 0x14) = 0xf
*(arg1 + 0x10) = 0
*arg1 = 0
return arg1
