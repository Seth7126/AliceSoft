// 函数: sub_10002a84
// 地址: 0x10002a84
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return 
