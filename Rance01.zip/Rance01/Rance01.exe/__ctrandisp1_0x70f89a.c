// 函数: __ctrandisp1
// 地址: 0x70f89a
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t __saved_ebp
int32_t* ebp = &__saved_ebp
int32_t var_2dc = arg3
int32_t entry_ebx
long double result = __fload(arg2, entry_ebx.w)
int16_t x87status
int16_t temp0
temp0, x87status = __fnstcw_memmem16(arg1)
int16_t var_a8 = temp0
char var_2cc
char var_2cc_1 = var_2cc & 0xfd
int32_t ecx
void* edx
__trandisp1(ecx, edx, ebp, result)
ctranexit(ebp)
return result
