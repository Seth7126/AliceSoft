// 函数: @__security_check_cookie@4
// 地址: 0x10002013
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 != __security_cookie)
    noreturn ___report_gsfailure() __tailcall
