// 函数: __flushall
// 地址: 0x10009a2f
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return _common_flush_all(1)
