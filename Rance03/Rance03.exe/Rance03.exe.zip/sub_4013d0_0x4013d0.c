// 函数: sub_4013d0
// 地址: 0x4013d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f5cc, "Volume.sav", 0xa)
return _atexit(sub_6d1f00)
