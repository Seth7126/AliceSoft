// 函数: sub_10002944
// 地址: 0x10002944
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t var_8 = arg3
sub_10001d19(*(arg5 + 8) ^ arg5)

if ((arg4->ExceptionFlags & 0x66) != 0)
    *(arg5 + 0x24) = 1
    return 1

sub_10006bf8(arg4, *(arg5 + 0x10), arg6, nullptr, *(arg5 + 0xc), *(arg5 + 0x14), *(arg5 + 0x18), 1)

if (*(arg5 + 0x24) == 0)
    sub_100027b0(arg5, arg4)

int32_t var_10_2 = 0
sub_1000286d(0x123, &var_8, 0, 0, 0, 0)
*(arg5 + 0x1c)
*(arg5 + 0x20)
jump(var_8)
