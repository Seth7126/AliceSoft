// 函数: _isdigit
// 地址: 0x6aa018
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (data_75d30c != 0)
    return __isdigit_l(arg1, nullptr)

return zx.d((*data_74ae90)[arg1]) & 4
