// 函数: j_sub_5ce4d0
// 地址: 0x5d1300
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5ce4d0() __tailcall
