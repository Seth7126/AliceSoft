// 函数: ___acrt_DownlevelLocaleNameToLCID
// 地址: 0x71ec9b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg1 != 0)
    int32_t eax_1 = GetTableIndexFromLocaleName(arg1)
    
    if (eax_1 s>= 0 && eax_1 u< 0xe4)
        return *((eax_1 << 3) + &data_757830)

return 0
