// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x6c0f22
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t ecx
return ecx()
