// 函数: j_sub_579180
// 地址: 0x578d80
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_579180(arg1) __tailcall
