// 函数: ??0invalid_multiple_scheduling@Concurrency@@QAE@PBD@Z
// 地址: 0x6f30f2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::invalid_scheduler_policy_key::VTable** result = arg1
sub_62be70(arg1, arg2)
*result = &Concurrency::invalid_scheduler_policy_key::`vftable'{for `std::exception'}
return result
