// 函数: __updatetlocinfoEx_nolock
// 地址: 0x6a59a9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg2 == 0 || arg1 == 0)
    return nullptr

void* esi_1 = *arg1

if (esi_1 != arg2)
    *arg1 = arg2
    sub_6a569a(arg2)
    
    if (esi_1 != 0)
        sub_6a5889(esi_1)
        
        if (*esi_1 == 0 && esi_1 != 0x74ae00)
            sub_6a572f(esi_1)

return arg2
