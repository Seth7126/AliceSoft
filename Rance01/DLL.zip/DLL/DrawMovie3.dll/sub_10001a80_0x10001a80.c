// 函数: sub_10001a80
// 地址: 0x10001a80
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

uint32_t ecx = arg1

if (ecx u<= 0)
    ecx = 0
else if (divu.dp.d(0:0xffffffff, ecx) u< 1)
    arg1 = 0
    struct std::exception::VTable* var_c
    sub_10001e9c(&var_c, &arg1)
    var_c = &std::bad_alloc::`vftable'{for `std::exception'}
    sub_1000272b(&var_c, 0x1001eed8)
    noreturn

return sub_10001dc9(ecx)
