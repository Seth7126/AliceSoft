// 函数: __fassign_l
// 地址: 0x6a975a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_c = arg3
int32_t result_1
int32_t result

if (result_1 == 0)
    boost::math::tools::evaluate_rational<4,long double,long double,long double>(&result_1, arg5, 
        arg6)
    result = result_1
    *arg4 = result
else
    sub_6ac12b(&var_c, arg5, arg6)
    *arg4 = var_c
    result = arg3
    arg4[1] = result

return result
