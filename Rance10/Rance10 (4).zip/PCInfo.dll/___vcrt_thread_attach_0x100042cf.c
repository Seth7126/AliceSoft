// 函数: ___vcrt_thread_attach
// 地址: 0x100042cf
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = ___vcrt_getptd_noexit() != 0
return result
