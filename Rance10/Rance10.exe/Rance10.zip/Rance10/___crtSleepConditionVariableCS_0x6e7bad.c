// 函数: ___crtSleepConditionVariableCS
// 地址: 0x6e7bad
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbec0 ^ __security_cookie
j_sub_4033e0()
return esi_1(arg1, arg2, arg3)
