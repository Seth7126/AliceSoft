// 函数: ?__CreateThread@platform@details@Concurrency@@YAPAXPAU_SECURITY_ATTRIBUTES@@IP6GKPAX@Z1KPAK@Z
// 地址: 0x6eaf79
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return CreateThread(arg1, arg2, arg3, arg4, arg5, arg6)
