// 函数: sub_10007ec3
// 地址: 0x10007ec3
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (data_10022358 != 0)
    return sub_10007e72(arg1, nullptr)

return zx.d((*data_10020528)[arg1]) & 4
