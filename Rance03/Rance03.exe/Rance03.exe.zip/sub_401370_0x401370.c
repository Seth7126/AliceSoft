// 函数: sub_401370
// 地址: 0x401370
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f584, 0x6da0fb, nullptr)
return _atexit(sub_6d1d90)
