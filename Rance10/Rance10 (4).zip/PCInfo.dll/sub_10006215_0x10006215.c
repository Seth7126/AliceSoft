// 函数: sub_10006215
// 地址: 0x10006215
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = ___acrt_getptd_noexit() != 0
return result
