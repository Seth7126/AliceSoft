// 函数: sub_1000d1b0
// 地址: 0x1000d1b0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t ecx = arg1[0x55]
int32_t edx = arg1[0x54]
int32_t eax_1 = *(*arg1 + 0xb4)
arg1[0x3d] = 0
arg1[0x3e] = 0x4c4b40
eax_1(edx, ecx)
int32_t esi_1 = arg1[0x3c]

if (esi_1 s<= 0)
    return Sleep(0) __tailcall

return Sleep(esi_1 s/ 0x2710) __tailcall
