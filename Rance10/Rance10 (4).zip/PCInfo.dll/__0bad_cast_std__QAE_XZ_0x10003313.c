// 函数: ??0bad_cast@std@@QAE@XZ
// 地址: 0x10003313
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

arg1[1] = 0
arg1[2] = 0
arg1[1] = "bad exception"
*arg1 = &std::bad_exception::`vftable'{for `std::exception'}
return arg1
