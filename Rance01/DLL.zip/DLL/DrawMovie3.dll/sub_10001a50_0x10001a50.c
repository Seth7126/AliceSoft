// 函数: sub_10001a50
// 地址: 0x10001a50
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* i = arg1

if (arg1 u> 0)
    char* ecx_1 = arg3
    
    do
        *ecx_1 = *arg2
        i -= 1
        ecx_1 = &ecx_1[1]
    while (i u> 0)

return arg1 + arg3
