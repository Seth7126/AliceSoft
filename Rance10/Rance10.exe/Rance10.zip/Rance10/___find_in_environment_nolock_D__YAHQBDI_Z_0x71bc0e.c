// 函数: ??$find_in_environment_nolock@D@@YAHQBDI@Z
// 地址: 0x71bc0e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t edi
int32_t var_10 = edi
int32_t* edi_1 = data_7fc6d0
int32_t* esi = edi_1

if (*edi_1 != 0)
    do
        if (sub_71792c(arg1, *esi, arg2) == 0)
            int32_t eax_2
            eax_2.b = arg2[*esi]
            
            if (eax_2.b == 0x3d || eax_2.b == 0)
                return (esi - edi_1) s>> 2
        
        esi = &esi[1]
    while (*esi != 0)

return neg.d((esi - edi_1) s>> 2)
