// 函数: __CIlog10_pentium4
// 地址: 0x6b1e30
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_6b1e4e(zx.o(fconvert.d(arg1)))
