// 函数: __NLG_Notify1
// 地址: 0x6a629c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_8 = arg3
data_74aed8 = arg3
data_74aed4 = arg1
data_74aedc = arg4
int32_t var_c = arg4
int32_t var_10 = arg3
return arg1
