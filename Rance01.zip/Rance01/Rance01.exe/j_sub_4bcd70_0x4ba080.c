// 函数: j_sub_4bcd70
// 地址: 0x4ba080
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_4bcd70(arg1) __tailcall
