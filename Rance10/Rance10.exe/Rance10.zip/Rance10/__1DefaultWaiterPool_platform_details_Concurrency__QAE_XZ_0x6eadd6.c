// 函数: ??1DefaultWaiterPool@platform@details@Concurrency@@QAE@XZ
// 地址: 0x6eadd6
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t* esi = data_7fc280

if (esi == 0)
    return 

Concurrency::details::platform::WaiterThreadPool::~WaiterThreadPool(esi)
operator new(esi)
data_7fc280 = 0
