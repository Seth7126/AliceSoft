// 函数: ___vcrt_initialize_pure_virtual_call_handler
// 地址: 0x10004f04
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_4 = 0x20
int32_t __security_cookie_1 = __security_cookie
data_10016c50 = __security_cookie_1
return __security_cookie_1
