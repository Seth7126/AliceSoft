// 函数: ??0SchedulerPolicy@Concurrency@@QAE@ABV01@@Z
// 地址: 0x6f4f80
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

char* eax = sub_6e810c(0x28)
*arg1 = eax
sub_700660(eax, *arg2, 0x28)
return arg1
