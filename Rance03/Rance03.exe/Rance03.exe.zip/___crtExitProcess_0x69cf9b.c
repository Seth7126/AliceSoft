// 函数: ___crtExitProcess
// 地址: 0x69cf9b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax
HMODULE ecx
int32_t edx
___crtCorExitProcess(eax, edx, ecx, arg1)
ExitProcess(arg1)
noreturn
