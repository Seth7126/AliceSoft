// 函数: sub_100027be
// 地址: 0x100027be
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = ***(arg1 - 0x14) == 0xc0000005
return result
