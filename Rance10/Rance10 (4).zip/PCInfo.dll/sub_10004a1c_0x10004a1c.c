// 函数: sub_10004a1c
// 地址: 0x10004a1c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___InternalCxxFrameHandler(arg2, arg3, arg4, arg5, arg1, 0, nullptr, 0)
