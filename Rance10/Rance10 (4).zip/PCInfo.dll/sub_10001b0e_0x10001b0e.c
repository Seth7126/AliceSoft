// 函数: sub_10001b0e
// 地址: 0x10001b0e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax_3 = *(arg1 + 8)
*(arg1 + 8) = eax_3
*(arg1 - 0x10) = &__return_addr
*(arg1 - 4) = 2
*(arg1 - 0x18) = sub_10001a10(eax_3 + 1)
return 0x10001b2b
