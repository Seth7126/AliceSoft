// 函数: sub_10007437
// 地址: 0x10007437
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (*((arg1 << 3) + &data_10020330) == 0 && sub_10007374(arg1) == 0)
    sub_100042d7(0x11)

return EnterCriticalSection(*((arg1 << 3) + &data_10020330))
