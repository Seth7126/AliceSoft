// 函数: sub_1000bdf0
// 地址: 0x1000bdf0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return arg2 - 1
