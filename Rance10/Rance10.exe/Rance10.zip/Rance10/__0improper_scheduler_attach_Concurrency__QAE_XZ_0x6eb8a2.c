// 函数: ??0improper_scheduler_attach@Concurrency@@QAE@XZ
// 地址: 0x6eb8a2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::invalid_operation::`vftable'{for `std::exception'}
return arg1
