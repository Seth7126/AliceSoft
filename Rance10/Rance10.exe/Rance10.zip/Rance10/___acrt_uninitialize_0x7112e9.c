// 函数: ___acrt_uninitialize
// 地址: 0x7112e9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return ___acrt_execute_uninitializers(&data_755868, &data_7558e0)
