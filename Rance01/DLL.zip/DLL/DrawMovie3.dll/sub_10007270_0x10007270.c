// 函数: sub_10007270
// 地址: 0x10007270
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 s>= 0)
    if (arg1 s<= 2)
        int32_t result = data_10021a20
        data_10021a20 = arg1
        return result
    
    if (arg1 == 3)
        return data_10021a20

*__errno() = 0x16
sub_100020e4(0, 0, 0, 0, 0)
return 0xffffffff
