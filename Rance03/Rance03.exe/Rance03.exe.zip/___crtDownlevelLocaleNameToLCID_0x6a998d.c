// 函数: ___crtDownlevelLocaleNameToLCID
// 地址: 0x6a998d
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 != 0)
    int32_t eax_1 = _GetTableIndexFromLocaleName(arg1)
    
    if (eax_1 s>= 0 && eax_1 u< 0xe4)
        return *((eax_1 << 3) + &data_6d6da0)

return 0
