// 函数: ___acrt_locale_free_time
// 地址: 0x10009dca
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    return 

free_crt_array_internal(arg1, 7)
free_crt_array_internal(&arg1[7], 7)
free_crt_array_internal(&arg1[0xe], 0xc)
free_crt_array_internal(&arg1[0x1a], 0xc)
free_crt_array_internal(&arg1[0x26], 2)
__free_base(arg1[0x28])
__free_base(arg1[0x29])
__free_base(arg1[0x2a])
free_crt_array_internal(&arg1[0x2d], 7)
free_crt_array_internal(&arg1[0x34], 7)
free_crt_array_internal(&arg1[0x3b], 0xc)
free_crt_array_internal(&arg1[0x47], 0xc)
free_crt_array_internal(&arg1[0x53], 2)
__free_base(arg1[0x55])
__free_base(arg1[0x56])
__free_base(arg1[0x57])
__free_base(arg1[0x58])
