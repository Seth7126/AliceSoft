// 函数: sub_1000a14b
// 地址: 0x1000a14b
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* var_14
sub_10004910(&var_14, arg2)
int32_t result = zx.d(*(*(var_14 + 0xc8) + (zx.d(arg1) << 1))) & 0x8000
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
