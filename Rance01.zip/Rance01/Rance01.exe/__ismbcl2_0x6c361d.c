// 函数: __ismbcl2
// 地址: 0x6c361d
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c3490(arg1, nullptr)
