// 函数: ??0scheduler_worker_creation_error@Concurrency@@QAE@J@Z
// 地址: 0x6f3178
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
arg1[3] = arg2
*arg1 = &Concurrency::scheduler_worker_creation_error::`vftable'{for `Concurrency::scheduler_resource_allocation_error'}
return arg1
