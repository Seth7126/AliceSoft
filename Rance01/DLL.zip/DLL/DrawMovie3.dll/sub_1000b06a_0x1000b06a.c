// 函数: sub_1000b06a
// 地址: 0x1000b06a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_100042d7(2)
