// 函数: j_sub_6b1ef0
// 地址: 0x728e90
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6b1ef0() __tailcall
