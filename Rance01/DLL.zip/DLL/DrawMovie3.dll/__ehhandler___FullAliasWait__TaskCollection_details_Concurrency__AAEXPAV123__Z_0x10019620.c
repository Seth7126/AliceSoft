// 函数: __ehhandler$?_FullAliasWait@_TaskCollection@details@Concurrency@@AAEXPAV123@@Z
// 地址: 0x10019620
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10001d19(*(arg1 - 0x2c) ^ (arg1 + 0xc))
return sub_10002804(0x1001ef50) __tailcall
