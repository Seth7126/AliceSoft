// 函数: __mtterm
// 地址: 0x69fe0a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t eax_1 = data_74a564

if (eax_1 != 0xffffffff)
    sub_69f726(eax_1)
    data_74a564 = 0xffffffff

return __mtdeletelocks() __tailcall
