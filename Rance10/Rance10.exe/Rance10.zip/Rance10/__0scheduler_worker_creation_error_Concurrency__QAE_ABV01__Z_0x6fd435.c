// 函数: ??0scheduler_worker_creation_error@Concurrency@@QAE@ABV01@@Z
// 地址: 0x6fd435
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::scheduler_resource_allocation_error::Concurrency::scheduler_worker_creation_error::VTable
    ** result = arg1
sub_6eadb2(arg1, arg2)
*result = &Concurrency::scheduler_worker_creation_error::`vftable'{for `Concurrency::scheduler_resource_allocation_error'}
return result
