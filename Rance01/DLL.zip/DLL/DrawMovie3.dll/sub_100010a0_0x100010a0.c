// 函数: sub_100010a0
// 地址: 0x100010a0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 
