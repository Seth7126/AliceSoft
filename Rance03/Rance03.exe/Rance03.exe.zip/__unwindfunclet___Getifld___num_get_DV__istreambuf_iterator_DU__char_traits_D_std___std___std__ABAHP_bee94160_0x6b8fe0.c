// 函数: __unwindfunclet$?_Getifld@?$num_get@DV?$istreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@ABAHPADAAV?$istreambuf_iterator@DU?$char_traits@D@std@@@2@1HABVlocale@2@@Z$1
// 地址: 0x6b8fe0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return j_sub_45d550(arg1 - 0x44) __tailcall
