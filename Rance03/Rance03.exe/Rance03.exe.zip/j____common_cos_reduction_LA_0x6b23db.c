// 函数: j____common_cos_reduction_LA
// 地址: 0x6b23db
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int16_t arg1
return ___common_cos_reduction_LA(arg1, arg2, arg3, arg4) __tailcall
