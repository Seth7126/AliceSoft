// 函数: j_sub_10004a52
// 地址: 0x10002ada
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return sub_10004a52() __tailcall
