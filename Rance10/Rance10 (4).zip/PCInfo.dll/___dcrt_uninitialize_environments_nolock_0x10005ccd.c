// 函数: ___dcrt_uninitialize_environments_nolock
// 地址: 0x10005ccd
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

sub_10005c57(&data_10016db0, uninitialize_environment_internal<wchar_t>)
sub_10005c57(0x10016db4, uninitialize_environment_internal<char>)
free_environment<char>(data_10016dbc)
return free_environment<char>(data_10016db8)
