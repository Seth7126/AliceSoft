// 函数: __crt_atexit
// 地址: 0x1000607b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = arg1
int32_t var_c = 0x10016dc0
void* ecx
return __register_onexit_function(ecx)
