// 函数: ___pctype_func
// 地址: 0x10008788
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* var_8 = arg1
void* eax = sub_1000682b()
var_8 = *(eax + 0x4c)
___acrt_update_multibyte_info(eax, &var_8)
return *var_8
