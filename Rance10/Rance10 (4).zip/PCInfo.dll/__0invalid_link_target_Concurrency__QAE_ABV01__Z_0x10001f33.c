// 函数: ??0invalid_link_target@Concurrency@@QAE@ABV01@@Z
// 地址: 0x10001f33
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::logic_error::std::length_error::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::length_error::`vftable'{for `std::logic_error'}
return result
