// 函数: ?Clone@PdbMemStream@@UAGJPAPAUIStream@@@Z
// 地址: 0x1000eec0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 0x80004001
