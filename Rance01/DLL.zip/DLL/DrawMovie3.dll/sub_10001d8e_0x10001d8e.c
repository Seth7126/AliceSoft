// 函数: sub_10001d8e
// 地址: 0x10001d8e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax_2 = sub_10003700(arg2 + 9, arg1 + 9)
int32_t eax_3 = neg.d(eax_2)
return sbb.d(eax_3, eax_3, eax_2 != 0) + 1
