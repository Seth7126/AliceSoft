// 函数: __mbccpy_s
// 地址: 0x6aa37b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_8 = 0
return __wctomb_s_l(arg1, arg2, arg3, arg4)
