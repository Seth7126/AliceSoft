// 函数: ___dcrt_uninitialize_environments_nolock
// 地址: 0x710dc3
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

sub_710d48(&data_7fc6d0, uninitialize_environment_internal<wchar_t>)
sub_710d48(&data_7fc6d4, uninitialize_environment_internal<char>)
free_environment<char>(data_7fc6dc)
return free_environment<char>(data_7fc6d8)
