// 函数: ___vcrt_freefls@4
// 地址: 0x100044e6
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result = arg1

if (result != 0 && result != 0x10016bd8)
    result = __free_base(result)

return result
