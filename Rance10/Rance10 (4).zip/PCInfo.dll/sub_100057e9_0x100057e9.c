// 函数: sub_100057e9
// 地址: 0x100057e9
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return common_exit(arg1, 2, 0)
