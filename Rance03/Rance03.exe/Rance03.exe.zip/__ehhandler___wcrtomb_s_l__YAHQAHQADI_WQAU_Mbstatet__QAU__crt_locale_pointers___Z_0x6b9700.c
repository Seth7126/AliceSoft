// 函数: __ehhandler$?_wcrtomb_s_l@@YAHQAHQADI_WQAU_Mbstatet@@QAU__crt_locale_pointers@@@Z
// 地址: 0x6b9700
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_69a5bc(*(arg1 - 0x24) ^ (arg1 + 0xc))
return sub_69e38e(0x72e0fc) __tailcall
