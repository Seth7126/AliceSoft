// 函数: __unwindfunclet$?_Getmfld@?$money_get@DV?$istreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@ABE?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@2@AAV?$istreambuf_iterator@DU?$char_traits@D@std@@@2@0_NAAVios_base@2@AAY0M@D@Z$7
// 地址: 0x6cba52
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = *(arg1 - 0x74) & 4

if (result == 0)
    return result

*(arg1 - 0x74) &= 0xfffffffb
return sub_401fb0(arg1 - 0x40) __tailcall
