// 函数: $LN13
// 地址: 0x100097e2
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(7)
