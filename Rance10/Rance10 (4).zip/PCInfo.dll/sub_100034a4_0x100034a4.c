// 函数: sub_100034a4
// 地址: 0x100034a4
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* entry_ebx
*(entry_ebx - 4) = *(arg1 - 0x2c)
sub_1000490d(*(arg1 - 0x30))
void* eax = sub_10004538()
*(eax + 0x10) = *(arg1 - 0x34)
int32_t* result = sub_10004538()
result[5] = *(arg1 - 0x38)

if (*arg2 != 0xe06d7363 || arg2[4] != 3
        || (arg2[5] != 0x19930520 && arg2[5] != 0x19930521 && arg2[5] != 0x19930522))
    *(arg1 - 0x1c)
else if (*(arg1 - 0x3c) == 0 && *(arg1 - 0x1c) != 0)
    result = __IsExceptionObjectToBeDestroyed(arg2[6])
    
    if (result != 0)
        result.b = *(arg1 - 0x40) != 0
        uint32_t var_4_2 = zx.d(result.b)
        result = sub_10003264(arg2)

return result
