// 函数: sub_10001d5f
// 地址: 0x10001d5f
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = &type_info::`vftable'
return sub_10003690(arg1)
