// 函数: ___acrt_initialize
// 地址: 0x7112d7
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return ___acrt_execute_initializers(&data_755868, &data_7558e0)
