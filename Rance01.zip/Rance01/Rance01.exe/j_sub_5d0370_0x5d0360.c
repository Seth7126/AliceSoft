// 函数: j_sub_5d0370
// 地址: 0x5d0360
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5d0370(arg1) __tailcall
