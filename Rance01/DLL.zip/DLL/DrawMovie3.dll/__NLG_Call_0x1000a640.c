// 函数: __NLG_Call
// 地址: 0x1000a640
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax
return eax()
