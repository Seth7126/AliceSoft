// 函数: ??0ThreadScheduler@details@Concurrency@@QAE@ABVSchedulerPolicy@2@@Z
// 地址: 0x6fc14b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::IScheduler::VTable** var_8 = arg1
struct Concurrency::IScheduler::VTable** var_8_1 = arg1
*arg1 = &Concurrency::IScheduler::`vftable'
sub_6ef7f6(&arg1[2], arg2)
*arg1 = &Concurrency::details::ThreadScheduler::`vftable'{for `Concurrency::IScheduler'}
arg1[2] =
    &Concurrency::details::ThreadScheduler::`vftable'{for `Concurrency::details::SchedulerBase'}
return arg1
