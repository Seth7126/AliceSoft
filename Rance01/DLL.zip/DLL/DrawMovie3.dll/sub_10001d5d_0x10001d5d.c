// 函数: sub_10001d5d
// 地址: 0x10001d5d
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct type_info::VTable** ecx
return sub_10001d5f(ecx) __tailcall
