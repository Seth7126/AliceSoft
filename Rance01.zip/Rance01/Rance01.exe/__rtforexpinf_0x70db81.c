// 函数: __rtforexpinf
// 地址: 0x70db81
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 != 0)
    return sub_70dd46() __tailcall

return data_75c860
