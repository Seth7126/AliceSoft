// 函数: sub_10004b8e
// 地址: 0x10004b8e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return RtlUnwind(arg1, 0x10004ba2, arg2, nullptr)
