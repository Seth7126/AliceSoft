// 函数: sub_10001cfc
// 地址: 0x10001cfc
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::logic_error::std::out_of_range::VTable** result = arg1
sub_10001820(arg1, arg2)
*result = &std::out_of_range::`vftable'{for `std::logic_error'}
return result
