// 函数: ??4QuickBitSet@details@Concurrency@@QAEAAV012@$$QAV012@@Z
// 地址: 0x6fa869
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

_free(arg1[1])
*arg1 = *arg2
arg1[1] = arg2[1]
*arg2 = 0
arg2[1] = 0
return arg1
