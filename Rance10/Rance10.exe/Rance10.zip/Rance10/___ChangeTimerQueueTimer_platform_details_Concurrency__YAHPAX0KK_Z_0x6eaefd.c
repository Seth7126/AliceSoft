// 函数: ?__ChangeTimerQueueTimer@platform@details@Concurrency@@YAHPAX0KK@Z
// 地址: 0x6eaefd
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return ChangeTimerQueueTimer(arg1, arg2, arg3, arg4)
