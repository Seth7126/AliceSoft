// 函数: ?unexpected@@YAXXZ
// 地址: 0x6bb78f
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eax = __getptd()[0x1f]

if (eax != 0)
    eax()

noreturn terminate() __tailcall
