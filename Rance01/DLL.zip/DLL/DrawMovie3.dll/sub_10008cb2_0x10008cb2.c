// 函数: sub_10008cb2
// 地址: 0x10008cb2
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax_1 = ***(arg1 - 0x14)

if (eax_1 != 0xc0000005 && eax_1 != 0xc000001d)
    return 0

return 1
