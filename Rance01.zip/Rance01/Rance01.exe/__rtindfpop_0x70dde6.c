// 函数: __rtindfpop
// 地址: 0x70dde6
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_75c8c0

if (*(arg1 - 0x90) s<= 0)
    *(arg1 - 0x90) = 1
