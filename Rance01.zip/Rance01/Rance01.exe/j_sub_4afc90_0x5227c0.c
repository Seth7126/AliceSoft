// 函数: j_sub_4afc90
// 地址: 0x5227c0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_4afc90(arg1) __tailcall
