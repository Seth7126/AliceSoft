// 函数: ??1UMSThreadScheduler@details@Concurrency@@UAE@XZ
// 地址: 0x6fc17e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &Concurrency::details::ThreadScheduler::`vftable'{for `Concurrency::IScheduler'}
arg1[2] =
    &Concurrency::details::ThreadScheduler::`vftable'{for `Concurrency::details::SchedulerBase'}
return sub_6efc92(&arg1[2]) __tailcall
