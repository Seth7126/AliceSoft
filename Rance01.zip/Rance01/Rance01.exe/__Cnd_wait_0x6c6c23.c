// 函数: __Cnd_wait
// 地址: 0x6c6c23
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c6b73(arg1, arg2, nullptr)
