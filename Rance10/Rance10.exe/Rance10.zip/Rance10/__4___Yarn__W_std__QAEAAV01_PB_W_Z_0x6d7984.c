// 函数: ??4?$_Yarn@_W@std@@QAEAAV01@PB_W@Z
// 地址: 0x6d7984
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (*arg1 != arg2)
    if (*arg1 != 0)
        _free(*arg1)
    
    *arg1 = 0
    
    if (arg2 != 0)
        int16_t* esi_1 = arg2
        
        if (*arg2 != 0)
            do
                esi_1 = &esi_1[1]
            while (*esi_1 != 0)
        
        void* var_14_1 = esi_1 - arg2 + 2
        char* eax_1 = sub_705e22()
        *arg1 = eax_1
        
        if (eax_1 != 0)
            sub_700660(eax_1, arg2, esi_1 - arg2 + 2)

return arg1
