// 函数: sub_1000cb20
// 地址: 0x1000cb20
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

EnterCriticalSection(arg1 + 0x94)
*(arg1 + 0xb0) = arg2
return LeaveCriticalSection(arg1 + 0x94)
