// 函数: sub_100032c4
// 地址: 0x100032c4
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = *(arg1 + 0xc) != 0
return result
