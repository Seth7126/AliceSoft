// 函数: ??1_Scoped_lock@_NonReentrantLock@details@Concurrency@@QAE@XZ
// 地址: 0x6eb9e8
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t* result = *arg1
*result = 0
return result
