// 函数: __initp_misc_purevirt
// 地址: 0x100035f3
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_1002207c = arg1
return arg1
