// 函数: sub_10003e26
// 地址: 0x10003e26
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

___FrameUnwindFilter(*(arg1 - 0x14))
return 0
