// 函数: ??_G?$_Func_impl@V<lambda_4471c1faea23acf00f5de6f001106c5d>@@V?$allocator@H@std@@XPAV?$message@W4agent_status@Concurrency@@@Concurrency@@@std@@QAEPAXI@Z
// 地址: 0x6eff73
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &Concurrency::details::_Chore::`vftable'

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
