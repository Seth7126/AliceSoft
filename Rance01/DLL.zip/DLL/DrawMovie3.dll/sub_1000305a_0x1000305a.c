// 函数: sub_1000305a
// 地址: 0x1000305a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10002fe8(0)
