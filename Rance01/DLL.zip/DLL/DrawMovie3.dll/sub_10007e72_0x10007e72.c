// 函数: sub_10007e72
// 地址: 0x10007e72
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* var_14
sub_10004910(&var_14, arg2)
void* eax = var_14
int32_t result

if (*(eax + 0xac) s<= 1)
    result = zx.d(*(*(eax + 0xc8) + (arg1 << 1))) & 4
else
    result = sub_1000af2a(arg1, 4, &var_14)

char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
