// 函数: __getptd
// 地址: 0x6bb9d8
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

uint32_t* result = sub_6bb95f()

if (result != 0)
    return result

__amsg_exit(0x10)
noreturn
