// 函数: __mbscat_s
// 地址: 0x1000b413
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000b2fc(arg1, arg2, arg3, nullptr)
