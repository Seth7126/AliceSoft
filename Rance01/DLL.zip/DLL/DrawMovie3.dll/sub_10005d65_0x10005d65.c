// 函数: sub_10005d65
// 地址: 0x10005d65
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

enum HEAP_FLAGS flOptions
flOptions.b = arg1 == 0
HANDLE result = HeapCreate(flOptions, 0x1000, 0)
data_100221d4 = result

if (result == 0)
    return result

data_10023520 = 1
return 1
