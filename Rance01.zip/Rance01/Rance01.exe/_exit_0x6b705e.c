// 函数: _exit
// 地址: 0x6b705e
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b6f1e(status, 0, 0)
