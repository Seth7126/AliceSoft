// 函数: _rand_s
// 地址: 0x6bc5c5
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 != 0)
    *arg1 = data_78c4cc
    return 0

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0x16
