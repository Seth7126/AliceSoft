// 函数: ___acrt_initialize_timeset
// 地址: 0x715b34
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(&data_7fc9f8, 
    0x7080)
__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(&data_7fc9fc, 1)
__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(&data_7fca00, 
    0xfffff1f0)
data_7fca04 = 0x7e1718
return 0
