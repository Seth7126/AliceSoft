// 函数: _dyntls_init_exception_filter
// 地址: 0x100055b0
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = arg1 == 0xe06d7363
return result
