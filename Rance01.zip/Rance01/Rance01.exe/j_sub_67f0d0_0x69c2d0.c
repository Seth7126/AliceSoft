// 函数: j_sub_67f0d0
// 地址: 0x69c2d0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_67f0d0() __tailcall
