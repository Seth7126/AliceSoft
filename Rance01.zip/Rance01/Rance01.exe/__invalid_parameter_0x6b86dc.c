// 函数: __invalid_parameter
// 地址: 0x6b86dc
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eax = DecodePointer(data_797860)

if (eax != 0)
    jump(eax)

int32_t var_8_1 = arg5
int32_t var_c = arg4
int32_t var_10 = arg3
int32_t var_14 = arg2
int32_t var_18 = arg1
sub_6b86b7()
noreturn
