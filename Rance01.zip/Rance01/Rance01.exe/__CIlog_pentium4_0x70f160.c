// 函数: __CIlog_pentium4
// 地址: 0x70f160
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

double var_10 = fconvert.d(arg1)
return start(zx.o(var_10), var_10)
