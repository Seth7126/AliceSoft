// 函数: __convertTOStoQNaN
// 地址: 0x6a9cdc
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return 
