// 函数: ??0invalid_link_target@Concurrency@@QAE@ABV01@@Z
// 地址: 0x69a43c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

struct std::exception::std::bad_function_call::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::bad_function_call::`vftable'{for `std::exception'}
return result
