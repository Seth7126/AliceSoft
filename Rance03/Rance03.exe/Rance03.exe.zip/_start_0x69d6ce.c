// 函数: _start
// 地址: 0x69d6ce
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

___security_init_cookie()
int32_t esi
int32_t edi
return ___tmainCRTStartup(esi, edi) __tailcall
