// 函数: ??0?$output_processor@_WV?$console_output_adapter@_W@__crt_stdio_output@@V?$standard_base@_WV?$console_output_adapter@_W@__crt_stdio_output@@@2@@__crt_stdio_output@@QAE@ABV?$console_output_adapter@_W@1@_KQB_WQAU__crt_locale_pointers@@QAD@Z
// 地址: 0x7044aa
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

__crt_stdio_output::output_adapter_data<wchar_t,class __crt_stdio_output::stream_output_adapter<wchar_t> >::output_adapter_data<wchar_t,class __crt_stdio_output::stream_output_adapter<wchar_t> >(
    arg1, arg2, arg3, arg4, arg5, arg6, arg7)
arg1[0x114] = 0
arg1[3] = __errno()
return arg1
