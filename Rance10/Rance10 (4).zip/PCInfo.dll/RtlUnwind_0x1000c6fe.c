// 函数: RtlUnwind
// 地址: 0x1000c6fe
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
