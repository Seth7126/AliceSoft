// 函数: __ehhandler$___std_fs_get_file_id@8
// 地址: 0x1000e1c8
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

@__security_check_cookie@4(*(arg1 - 0x20) ^ (arg1 + 0xc))
return sub_10004a1c(0x10014220) __tailcall
