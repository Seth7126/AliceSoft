// 函数: ??0EnumC13Lines@@QAE@XZ
// 地址: 0x45d250
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &decodecg::CDecodeTGA::`vftable'
arg1[1] = 0
arg1[2] = 0
arg1[3] = 0
arg1[4] = 0
return arg1
