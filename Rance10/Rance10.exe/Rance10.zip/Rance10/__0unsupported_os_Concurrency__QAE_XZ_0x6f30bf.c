// 函数: ??0unsupported_os@Concurrency@@QAE@XZ
// 地址: 0x6f30bf
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::improper_scheduler_attach::`vftable'{for `std::exception'}
return arg1
