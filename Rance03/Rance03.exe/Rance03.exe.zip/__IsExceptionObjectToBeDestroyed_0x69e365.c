// 函数: __IsExceptionObjectToBeDestroyed
// 地址: 0x69e365
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

for (int32_t* i = __getptd()[0x26]; i != 0; i = i[1])
    if (*i == arg1)
        return 0

return 1
