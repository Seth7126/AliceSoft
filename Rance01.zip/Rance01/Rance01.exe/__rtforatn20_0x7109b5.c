// 函数: __rtforatn20
// 地址: 0x7109b5
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

arg1.b = arg1.b

if (arg1.b == 0)
    arg1:1.b = arg1:1.b
else
    arg1:1.b = arg1:1.b
