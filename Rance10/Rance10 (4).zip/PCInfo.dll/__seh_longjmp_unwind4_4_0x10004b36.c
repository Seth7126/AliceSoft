// 函数: __seh_longjmp_unwind4@4
// 地址: 0x10004b36
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* var_8 = arg1
*arg1
return __local_unwind4(arg1[0xa], arg1[6], arg1[7])
