// 函数: __unwindfunclet$?create_stl_condition_variable@details@Concurrency@@YAXPAVstl_condition_variable_interface@12@@Z$0
// 地址: 0x6b66c0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_4 = *(arg1 + 8)
int32_t result = *(arg1 - 0x14)
int32_t result_1 = result
return result
