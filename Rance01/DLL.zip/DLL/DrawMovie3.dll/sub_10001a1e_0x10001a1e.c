// 函数: sub_10001a1e
// 地址: 0x10001a1e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* esi = *(arg1 - 0x14)

if (*(esi + 0x18) u>= 0x10)
    int32_t var_4_1 = *(esi + 4)
    sub_10001d52()

*(esi + 0x18) = 0xf
*(esi + 0x14) = 0
*(esi + 4) = 0
sub_1000272b(0, nullptr)
noreturn
