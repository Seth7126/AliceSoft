// 函数: sub_1000dd10
// 地址: 0x1000dd10
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 4
return sub_100010b0() __tailcall
