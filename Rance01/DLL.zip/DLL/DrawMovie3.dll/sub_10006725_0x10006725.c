// 函数: sub_10006725
// 地址: 0x10006725
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 1
