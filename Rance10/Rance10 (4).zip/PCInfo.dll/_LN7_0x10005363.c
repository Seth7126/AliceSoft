// 函数: $LN7
// 地址: 0x10005363
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(0)
