// 函数: ___vcrt_uninitialize_ptd
// 地址: 0x1000460b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

BOOL result = data_10016020

if (result != 0xffffffff)
    sub_10004da1(result)
    data_10016020 = 0xffffffff

result.b = 1
return result
