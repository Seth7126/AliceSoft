// 函数: ??0WaitBlock@details@Concurrency@@QAE@XZ
// 地址: 0x6e95fa
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
*arg1 = &Concurrency::details::WaitBlock::`vftable'
arg1[2] = 0
arg1[1] = Concurrency::Context::CurrentContext()
return arg1
