// 函数: j_sub_566160
// 地址: 0x565d80
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_566160(arg1) __tailcall
