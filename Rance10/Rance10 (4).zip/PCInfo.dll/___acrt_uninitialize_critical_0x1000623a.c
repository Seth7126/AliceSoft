// 函数: ___acrt_uninitialize_critical
// 地址: 0x1000623a
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = arg1
___acrt_uninitialize_ptd()
BOOL result
result.b = 1
return result
