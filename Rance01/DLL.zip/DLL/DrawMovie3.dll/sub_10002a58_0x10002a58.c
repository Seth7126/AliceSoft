// 函数: sub_10002a58
// 地址: 0x10002a58
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = arg2
arg1[1] = *(__getptd() + 0x98)
*(__getptd() + 0x98) = arg1
return arg1
