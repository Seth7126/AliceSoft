// 函数: ?construct_ptd@@YAXQAU__acrt_ptd@@QAPAU__crt_locale_data@@@Z
// 地址: 0x10006671
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t** var_8 = arg1
int32_t** var_c = arg1
int32_t* arg_4
arg_4[6] = 1
*arg_4 = 0x1000fad8
arg_4[0xd4] = 1
arg_4[0x12] = &data_10016350
arg_4[0x1b].w = 0x43
*(arg_4 + 0x172) = 0x43
arg_4[0xd3] = 0
var_8 = &arg_4
__acrt_lock_and_call<class <lambda_b7fb1a997d3ebc0cc0186c5835178808> >(5, &var_8)
var_c = &arg_4
void arg_8
var_8 = &arg_8
return __acrt_lock_and_call<class <lambda_b2ea41f6bbb362cd97d94c6828d90b61> >(4, &var_c)
