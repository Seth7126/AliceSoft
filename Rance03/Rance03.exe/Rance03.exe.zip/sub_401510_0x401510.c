// 函数: sub_401510
// 地址: 0x401510
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f6a4, 0x6da253, nullptr)
return _atexit(sub_6d22c0)
