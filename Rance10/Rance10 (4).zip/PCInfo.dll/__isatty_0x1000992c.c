// 函数: __isatty
// 地址: 0x1000992c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 != 0xfffffffe)
    if (arg1 s>= 0 && arg1 u< data_10017228)
        return zx.d(*((&data_10017028)[arg1 s>> 6] + (arg1 & 0x3f) * 0x30 + 0x28)) & 0x40
    
    *__errno() = 9
    __invalid_parameter_noinfo()
else
    *__errno() = 9

return 0
