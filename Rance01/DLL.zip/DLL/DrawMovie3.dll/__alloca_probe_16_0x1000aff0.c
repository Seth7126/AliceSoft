// 函数: __alloca_probe_16
// 地址: 0x1000aff0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void arg_4
void* ecx_1 = (&arg_4 - arg1) & 0xf
return __chkstk((arg1 + ecx_1) | sbb.d(ecx_1, ecx_1, arg1 + ecx_1 u< arg1)) __tailcall
