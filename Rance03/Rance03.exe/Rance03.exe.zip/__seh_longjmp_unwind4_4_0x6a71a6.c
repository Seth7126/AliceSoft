// 函数: __seh_longjmp_unwind4@4
// 地址: 0x6a71a6
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

*arg1
return __local_unwind4(arg1[0xa], arg1[6], arg1[7])
