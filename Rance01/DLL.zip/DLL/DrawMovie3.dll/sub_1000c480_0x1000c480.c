// 函数: sub_1000c480
// 地址: 0x1000c480
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* ecx = arg1[0x14]

if (ecx != 0)
    sub_10011fc0(ecx)

(*(*arg1 + 0x70))()
return 0
