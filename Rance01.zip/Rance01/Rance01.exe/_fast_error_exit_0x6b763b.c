// 函数: _fast_error_exit
// 地址: 0x6b763b
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (data_796ef4 == 1)
    __FF_MSGBANNER()

sub_6b7b48(arg1)
__endthreadex(0xff)
noreturn
