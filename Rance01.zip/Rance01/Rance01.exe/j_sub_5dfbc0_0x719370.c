// 函数: j_sub_5dfbc0
// 地址: 0x719370
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5dfbc0() __tailcall
