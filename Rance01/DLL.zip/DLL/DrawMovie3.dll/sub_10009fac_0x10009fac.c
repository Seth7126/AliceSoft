// 函数: sub_10009fac
// 地址: 0x10009fac
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result
result.b = data_100223e8 == (__security_cookie | 1)
return result
