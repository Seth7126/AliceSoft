// 函数: __rtpiby2
// 地址: 0x7109ac
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return data_75c8ca
