// 函数: ?AddRef@Dbg1Data@@QAEKXZ
// 地址: 0x5c7d70
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t result = *(arg1 + 0x28) + 1
*(arg1 + 0x28) = result
return result
