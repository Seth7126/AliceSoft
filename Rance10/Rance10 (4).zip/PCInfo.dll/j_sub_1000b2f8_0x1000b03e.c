// 函数: j_sub_1000b2f8
// 地址: 0x1000b03e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return sub_1000b2f8() __tailcall
