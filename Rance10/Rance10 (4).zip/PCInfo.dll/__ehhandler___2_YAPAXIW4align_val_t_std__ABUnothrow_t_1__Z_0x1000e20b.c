// 函数: __ehhandler$??2@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x1000e20b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

@__security_check_cookie@4(*(arg1 - 0x14) ^ (arg1 + 0xc))
return sub_10004a1c(0x10014538) __tailcall
