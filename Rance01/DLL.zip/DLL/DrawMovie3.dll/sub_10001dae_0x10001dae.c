// 函数: sub_10001dae
// 地址: 0x10001dae
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t var_8 = 1
struct std::exception::std::bad_alloc::VTable** result = arg1
sub_10001eef(arg1, &data_10020040)
*result = &std::bad_alloc::`vftable'{for `std::exception'}
return result
