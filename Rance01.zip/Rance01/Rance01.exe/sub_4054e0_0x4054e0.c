// 函数: sub_4054e0
// 地址: 0x4054e0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t* result = *arg1

if (result != 0)
    sub_405780(result, arg1[1])
    int32_t var_8_1 = *arg1
    result = sub_6b4d5b()

*arg1 = 0
arg1[1] = 0
arg1[2] = 0
return result
