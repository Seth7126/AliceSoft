// 函数: __RTC_Initialize
// 地址: 0x6a7595
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

for (void* const i = &data_727288; i u< &data_727288; i += 4)
    int32_t eax = *i
    
    if (eax != 0)
        eax()
