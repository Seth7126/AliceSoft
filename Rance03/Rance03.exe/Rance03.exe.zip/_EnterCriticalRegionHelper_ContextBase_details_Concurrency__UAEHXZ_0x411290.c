// 函数: ?EnterCriticalRegionHelper@ContextBase@details@Concurrency@@UAEHXZ
// 地址: 0x411290
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = *(arg1 + 0xc) + 1
*(arg1 + 0xc) = result
return result
