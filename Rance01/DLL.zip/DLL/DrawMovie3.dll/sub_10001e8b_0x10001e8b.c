// 函数: sub_10001e8b
// 地址: 0x10001e8b
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1[1] = 0
arg1[2] = 0
*arg1 = &std::exception::`vftable'
return arg1
