// 函数: __unwindfunclet$??0VirtualProcessor@details@Concurrency@@QAE@XZ$1
// 地址: 0x10019194
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000bec0(*(arg1 - 0x10) + 0x94) __tailcall
