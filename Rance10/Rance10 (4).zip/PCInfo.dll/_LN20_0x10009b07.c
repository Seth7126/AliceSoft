// 函数: $LN20
// 地址: 0x10009b07
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(8)
