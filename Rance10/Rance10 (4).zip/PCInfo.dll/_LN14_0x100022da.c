// 函数: $LN14
// 地址: 0x100022da
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___scrt_release_startup_lock((*(arg1 - 0x1d)).b)
