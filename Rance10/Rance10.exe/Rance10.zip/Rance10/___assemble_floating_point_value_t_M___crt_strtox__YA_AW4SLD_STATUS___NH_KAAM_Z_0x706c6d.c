// 函数: ??$assemble_floating_point_value_t@M@__crt_strtox@@YA?AW4SLD_STATUS@@_NH_KAAM@Z
// 地址: 0x706c6d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg4 = ((arg2 + 0x7f) << 0x17 & 0x7f800000) | zx.d(arg1) << 0x1f | (arg3 & 0x7fffff)
return 0
