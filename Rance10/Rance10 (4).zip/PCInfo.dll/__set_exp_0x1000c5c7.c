// 函数: __set_exp
// 地址: 0x1000c5c7
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t ecx
int32_t var_8 = ecx
int32_t var_c = ecx
var_c.q = fconvert.d(fconvert.t(arg1))
var_8:2.w = ((arg3 + 0x3fe) << 4).w | (arg2 & 0x800f)
return fconvert.t(var_c.q)
