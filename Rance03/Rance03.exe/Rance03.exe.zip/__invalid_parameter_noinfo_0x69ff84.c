// 函数: __invalid_parameter_noinfo
// 地址: 0x69ff84
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __invalid_parameter(0, 0, 0, 0, 0)
