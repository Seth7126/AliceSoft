// 函数: __raise_exc
// 地址: 0x10013810
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return __cfltcvt_l(arg1, arg2, arg3, arg4, arg5, arg6, nullptr)
