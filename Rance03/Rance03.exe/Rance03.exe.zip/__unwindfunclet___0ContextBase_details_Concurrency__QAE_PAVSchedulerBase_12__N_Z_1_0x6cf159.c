// 函数: __unwindfunclet$??0ContextBase@details@Concurrency@@QAE@PAVSchedulerBase@12@_N@Z$1
// 地址: 0x6cf159
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_401fb0(*(arg1 - 0x10) + 0x80) __tailcall
