// 函数: __cropzeros
// 地址: 0x6a96b1
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __cropzeros_l(arg1, nullptr)
