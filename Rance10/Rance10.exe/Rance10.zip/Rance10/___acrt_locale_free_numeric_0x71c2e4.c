// 函数: ___acrt_locale_free_numeric
// 地址: 0x71c2e4
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg1 == 0)
    return 

int32_t eax_1 = *arg1

if (eax_1 != data_7e14f8)
    __free_base(eax_1)

int32_t eax_2 = arg1[1]

if (eax_2 != data_7e14fc)
    __free_base(eax_2)

int32_t eax_3 = arg1[2]

if (eax_3 != data_7e1500)
    __free_base(eax_3)

int32_t eax_4 = arg1[0xc]

if (eax_4 != data_7e1528)
    __free_base(eax_4)

int32_t eax = arg1[0xd]

if (eax != data_7e152c)
    __free_base(eax)
