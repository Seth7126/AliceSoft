// 函数: ??1?$WorkStealingQueue@V_UnrealizedChore@details@Concurrency@@V_CriticalNonReentrantLock@23@@details@Concurrency@@QAE@XZ
// 地址: 0x6f32ce
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

_free(*(arg1 + 0x1c))
return _free(*(arg1 + 0x20))
