// 函数: ___acrt_initialize_winapi_thunks
// 地址: 0x715a51
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_8 = 0x20
int32_t ecx
int32_t edi
edi, ecx = __memfill_u32(&data_7fc970, __security_cookie, 0x20)
int32_t result
result.b = 1
return result
