// 函数: __unwindfunclet$??1?$ordered_message_processor@I@Concurrency@@UAE@XZ$4
// 地址: 0x6ce066
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_5f4250(*(arg1 - 0x10) + 0x80) __tailcall
