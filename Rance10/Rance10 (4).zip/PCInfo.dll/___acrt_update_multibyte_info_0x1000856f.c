// 函数: ___acrt_update_multibyte_info
// 地址: 0x1000856f
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* result = *arg2

if (result != data_10017240)
    result = data_100166f0
    
    if ((*(arg1 + 0x350) & result) == 0)
        result = sub_10008a78()
        *arg2 = result

return result
