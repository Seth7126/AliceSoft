// 函数: __initp_misc_invarg
// 地址: 0x100057cb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10016c9c = arg1
return arg1
