// 函数: __cexit
// 地址: 0x1000455d
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000441b(0, 0, 1)
