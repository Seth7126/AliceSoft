// 函数: ___onexitinit
// 地址: 0x69ac14
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t* eax = sub_69e723(0x20, 4)
int32_t eax_1 = EncodePointer(eax)
data_75df54 = eax_1
data_75df50 = eax_1

if (eax == 0)
    return 0x18

*eax = 0
return 0
