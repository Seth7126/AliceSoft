// 函数: sub_10003c34
// 地址: 0x10003c34
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

sub_1000624c()
noreturn
