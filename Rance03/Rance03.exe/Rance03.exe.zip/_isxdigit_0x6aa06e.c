// 函数: _isxdigit
// 地址: 0x6aa06e
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (data_75d30c != 0)
    return __isxdigit_l(arg1, nullptr)

return zx.d((*data_74ae90)[arg1]) & 0x80
