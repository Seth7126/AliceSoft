// 函数: sub_10007f88
// 地址: 0x10007f88
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t ebx
ebx.b = *(arg1 - 0x19)
return $LN8() __tailcall
