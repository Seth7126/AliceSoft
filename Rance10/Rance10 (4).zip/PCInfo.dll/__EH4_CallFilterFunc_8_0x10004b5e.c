// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x10004b5e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t ecx
return ecx()
