// 函数: sub_401570
// 地址: 0x401570
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f71c, &(*U",\n\n}")[0]:3, nullptr)
return _atexit(sub_6d23e0)
