// 函数: __invalid_parameter_noinfo
// 地址: 0x10005231
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __invalid_parameter(0, 0, 0, 0, 0)
