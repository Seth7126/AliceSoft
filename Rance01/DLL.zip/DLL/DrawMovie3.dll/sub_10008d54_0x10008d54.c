// 函数: sub_10008d54
// 地址: 0x10008d54
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t edi = arg1
uint32_t i_1 = arg2 u>> 7
uint32_t i

do
    __builtin_memset(edi, 0, 0x80)
    edi += 0x80
    i = i_1
    i_1 -= 1
while (i != 1)
