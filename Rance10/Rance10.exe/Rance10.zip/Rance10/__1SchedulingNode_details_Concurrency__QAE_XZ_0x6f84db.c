// 函数: ??1SchedulingNode@details@Concurrency@@QAE@XZ
// 地址: 0x6f84db
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

sub_6f8464(arg1 + 0x38)
sub_6f3000(arg1 + 0x10)
_free(*(arg1 + 0x18))
return _free(*(arg1 + 0xc))
