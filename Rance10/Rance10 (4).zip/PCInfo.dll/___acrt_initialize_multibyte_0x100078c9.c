// 函数: ___acrt_initialize_multibyte
// 地址: 0x100078c9
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (data_10017008 == 0)
    setmbcp_internal(0xfffffffd, 1)
    data_10017008 = 1

int32_t result
result.b = 1
return result
