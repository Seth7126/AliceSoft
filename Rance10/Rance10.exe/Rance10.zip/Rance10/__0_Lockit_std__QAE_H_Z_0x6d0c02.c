// 函数: ??0_Lockit@std@@QAE@H@Z
// 地址: 0x6d0c02
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = arg2

if (arg2 == 0)
    sub_70d7d8()
else if (arg2 s< 8)
    ___vcrt_FlsFree(arg2 * 0x18 + &data_7fb9e0)

return arg1
