// 函数: sub_1000b64c
// 地址: 0x1000b64c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10009f4b(arg1, *(data_100224e4 + (arg1 << 2)))
