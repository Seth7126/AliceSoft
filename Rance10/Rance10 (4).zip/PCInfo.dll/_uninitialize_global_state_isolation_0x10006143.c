// 函数: _uninitialize_global_state_isolation
// 地址: 0x10006143
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result
result.b = 1
return result
