// 函数: __CIasin_default
// 地址: 0x69ea60
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int16_t x87control
return sub_69ea7d(x87control, arg1)
