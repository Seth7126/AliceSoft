// 函数: sub_10009d61
// 地址: 0x10009d61
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 == 0xfffffffe)
    *__errno() = 9
    return 0

if (arg1 s>= 0 && arg1 u< data_10023524)
    return sx.d(*((&data_10023540)[arg1 s>> 5] + ((arg1 & 0x1f) << 6) + 4)) & 0x40

*__errno() = 9
sub_100020e4(0, 0, 0, 0, 0)
return 0
