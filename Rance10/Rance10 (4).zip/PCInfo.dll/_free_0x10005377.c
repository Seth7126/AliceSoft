// 函数: _free
// 地址: 0x10005377
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __free_base(arg1) __tailcall
