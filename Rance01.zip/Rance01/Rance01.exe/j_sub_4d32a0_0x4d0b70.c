// 函数: j_sub_4d32a0
// 地址: 0x4d0b70
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_4d32a0(arg1) __tailcall
