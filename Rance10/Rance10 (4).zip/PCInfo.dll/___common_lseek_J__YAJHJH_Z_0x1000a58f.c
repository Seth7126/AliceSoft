// 函数: ??$common_lseek@J@@YAJHJH@Z
// 地址: 0x1000a58f
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t __saved_ebp_1 = 0x14
int32_t var_8 = 0x10014848
int32_t (* var_10)(int32_t* arg1, void* arg2, int32_t arg3) = __except_handler4
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
uint32_t __security_cookie_1 = __security_cookie
int32_t var_8_3 = 0x10014848 ^ __security_cookie_1
int32_t __saved_ebp
int32_t var_38 = __security_cookie_1 ^ &__saved_ebp
int32_t* var_1c = &var_38
void* const var_3c_2 = &data_1000a59b
int32_t var_8_4 = 0xfffffffe
int32_t var_c = var_8_3
fsbase->NtTib.ExceptionList = &ExceptionList
int32_t result

if (arg1 != 0xfffffffe)
    int32_t ecx_1
    int32_t ebx_2
    
    if (arg1 s>= 0 && arg1 u< data_10017228)
        ebx_2 = arg1 s>> 6
        ecx_1 = (arg1 & 0x3f) * 0x30
    
    if (arg1 s< 0 || arg1 u>= data_10017228
            || (zx.d(*((&data_10017028)[ebx_2] + ecx_1 + 0x28)) & 1) == 0)
        *___doserrno() = 0
        *__errno() = 9
        __invalid_parameter_noinfo()
        result = 0xffffffff
    else
        ___acrt_lowio_lock_fh(arg1)
        int32_t result_1 = 0xffffffff
        int32_t var_20_1 = 0xffffffff
        int32_t var_8_1 = 0
        
        if ((*((&data_10017028)[ebx_2] + ecx_1 + 0x28) & 1) != 0)
            result_1 = __write_nolock(arg1, arg2, arg3)
            int32_t result_2 = result_1
        else
            *__errno() = 9
            *___doserrno() = 0
        
        int32_t var_8_2 = 0xfffffffe
        $LN13(arg1)
        result = result_1
else
    *___doserrno() = 0
    *__errno() = 9
    result = 0xffffffff

fsbase->NtTib.ExceptionList = ExceptionList
void* const __saved_ebp_2 = &data_1000a679
return result
