// 函数: __initp_misc_invarg
// 地址: 0x10001fad
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_10021a10 = arg1
return arg1
