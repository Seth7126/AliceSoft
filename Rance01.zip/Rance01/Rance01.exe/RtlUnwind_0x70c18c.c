// 函数: RtlUnwind
// 地址: 0x70c18c
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
