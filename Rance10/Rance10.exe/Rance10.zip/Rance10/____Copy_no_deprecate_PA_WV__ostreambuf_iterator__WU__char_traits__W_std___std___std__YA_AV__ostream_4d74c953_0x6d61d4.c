// 函数: ??$_Copy_no_deprecate@PA_WV?$ostreambuf_iterator@_WU?$char_traits@_W@std@@@std@@@std@@YA?AV?$ostreambuf_iterator@_WU?$char_traits@_W@std@@@0@PA_W0V10@@Z
// 地址: 0x6d61d4
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t ecx
int32_t var_c = ecx
int32_t var_10 = ecx
int32_t eax
int32_t edx
std::copy<wchar_t*,class std::ostreambuf_iterator<wchar_t,struct std::char_traits<wchar_t> > >(eax, 
    edx, ecx, arg1, arg2, arg3, arg4, arg5)
return arg1
