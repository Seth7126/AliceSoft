// 函数: __CIatan_pentium4
// 地址: 0x70f910
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

double var_10 = fconvert.d(arg1)
return sub_70f92e(zx.o(var_10), var_10)
