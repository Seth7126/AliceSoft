// 函数: __setdefaultprecision
// 地址: 0x6a9863
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = __controlfp_s(nullptr, 0x10000, 0x30000)

if (result == 0)
    return result

int32_t var_18
__builtin_memset(&var_18, 0, 0x14)
__invoke_watson()
noreturn
