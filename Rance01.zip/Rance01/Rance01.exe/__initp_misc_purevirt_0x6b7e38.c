// 函数: __initp_misc_purevirt
// 地址: 0x6b7e38
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_797854 = arg1
return arg1
