// 函数: ?__construct_from_string_literal@__non_rtti_object@std@@SA?AV12@QBD@Z
// 地址: 0x702dee
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
arg1[1] = arg2
*arg1 = &std::__non_rtti_object::`vftable'{for `std::bad_typeid'}
return arg1
