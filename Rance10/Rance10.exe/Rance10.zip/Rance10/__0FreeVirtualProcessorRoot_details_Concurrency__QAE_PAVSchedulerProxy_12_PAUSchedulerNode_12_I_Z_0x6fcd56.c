// 函数: ??0FreeVirtualProcessorRoot@details@Concurrency@@QAE@PAVSchedulerProxy@12@PAUSchedulerNode@12@I@Z
// 地址: 0x6fcd56
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::IVirtualProcessorRoot::Concurrency::details::VirtualProcessorRoot::VTable** 
    var_8 = arg1
struct Concurrency::details::VirtualProcessorRoot::Concurrency::details::FreeVirtualProcessorRoot::VTable
    ** result = arg1
struct Concurrency::details::VirtualProcessorRoot::Concurrency::details::FreeVirtualProcessorRoot::VTable
    ** result_1 = result
Concurrency::details::VirtualProcessorRoot::VirtualProcessorRoot(arg1, arg2, arg3, arg4)
*result = &Concurrency::details::FreeVirtualProcessorRoot::`vftable'{for `Concurrency::details::VirtualProcessorRoot'}
result[0x14] = 0
result[0x15] = 0
return result
