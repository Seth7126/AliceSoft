// 函数: j_sub_4b4d00
// 地址: 0x4b4c10
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_4b4d00(arg1) __tailcall
