// 函数: _swprintf
// 地址: 0x6b51d7
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

void arg_10
return sub_6b52bf(arg1, arg2, arg3, 0, &arg_10)
