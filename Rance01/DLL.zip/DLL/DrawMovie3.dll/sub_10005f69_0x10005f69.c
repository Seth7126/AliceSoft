// 函数: sub_10005f69
// 地址: 0x10005f69
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 != 0xe06d7363)
    return 0

return sub_10005e09(0xe06d7363, arg2)
