// 函数: sub_10001400
// 地址: 0x10001400
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* result = sub_100018c0(arg1, arg2)

if (result.b != 0)
    uint32_t (* esi_1)[0x4] = *arg1
    _memset(esi_1, *arg3, arg2)
    result = esi_1 + arg2
    arg1[1] = result

return result
