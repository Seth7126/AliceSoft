// 函数: __cfltcvt_init
// 地址: 0x69e3db
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

data_74b074 = __cropzeros
data_74b070 = __cfltcvt
data_74b078 = __fassign
data_74b07c = __forcdecpt
data_74b080 = __positive
data_74b084 = __cfltcvt
data_74b088 = __cfltcvt_l
data_74b08c = __fassign_l
data_74b090 = __cropzeros_l
data_74b094 = __forcdecpt_l
return __cfltcvt
