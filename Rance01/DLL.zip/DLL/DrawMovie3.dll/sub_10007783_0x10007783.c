// 函数: sub_10007783
// 地址: 0x10007783
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = __unlock(0xc)
*(arg1 - 0x1c)
return result
