// 函数: ?unexpected@@YAXXZ
// 地址: 0x10006d17
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax = *(__getptd() + 0x7c)

if (eax != 0)
    eax()

noreturn terminate() __tailcall
