// 函数: ??_G?$moneypunct@G$00@std@@MAEPAXI@Z
// 地址: 0x6d7a57
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &std::_Mpunct<uint16_t>::`vftable'{for `std::money_base'}
sub_6ded0b(arg1)
*arg1 = &std::_Facet_base::`vftable'

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
