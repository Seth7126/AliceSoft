// 函数: sub_1000c410
// 地址: 0x1000c410
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1[5] == 1)
    ResetEvent(arg1[0x17])

(*(*arg1 + 0x28))(0)
(*(*arg1 + 0x6c))()
(*(*arg1 + 0x70))()
sub_1000c210(arg1)
return 0
