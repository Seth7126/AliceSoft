// 函数: ??$evaluate_polynomial@$04OO@tools@math@boost@@YAOAAY04$$CBOABO@Z
// 地址: 0x720eb0
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return __mbsdec_l(arg1, arg2, nullptr)
