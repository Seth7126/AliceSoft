// 函数: ?_Tidy@exception@std@@AAEXXZ
// 地址: 0x69e550
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (*(arg1 + 8) != 0)
    _free(*(arg1 + 4))

*(arg1 + 4) = 0
*(arg1 + 8) = 0
