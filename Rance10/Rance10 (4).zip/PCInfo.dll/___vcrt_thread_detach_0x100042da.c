// 函数: ___vcrt_thread_detach
// 地址: 0x100042da
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

___vcrt_freeptd(0)
uint32_t result
result.b = 1
return result
