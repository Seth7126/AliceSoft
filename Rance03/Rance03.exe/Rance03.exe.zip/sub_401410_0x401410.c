// 函数: sub_401410
// 地址: 0x401410
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f5e4, 0x6da1cf, nullptr)
return _atexit(sub_6d1fc0)
