// 函数: ??0invalid_scheduler_policy_key@Concurrency@@QAE@PBD@Z
// 地址: 0x69a472
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

struct std::exception::std::logic_error::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::logic_error::`vftable'{for `std::exception'}
return result
