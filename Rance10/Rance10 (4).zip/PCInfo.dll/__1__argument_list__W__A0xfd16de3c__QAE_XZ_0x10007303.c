// 函数: ??1?$argument_list@_W@?A0xfd16de3c@@QAE@XZ
// 地址: 0x10007303
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t edi
int32_t var_8 = edi

for (int32_t* i = *arg1; i != arg1[1]; i = &i[1])
    __free_base(*i)

return __free_base(*arg1)
