// 函数: ___acrt_locale_free_numeric
// 地址: 0x10009d25
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    return 

int32_t eax_1 = *arg1

if (eax_1 != data_10016700)
    __free_base(eax_1)

int32_t eax_2 = arg1[1]

if (eax_2 != data_10016704)
    __free_base(eax_2)

int32_t eax_3 = arg1[2]

if (eax_3 != data_10016708)
    __free_base(eax_3)

int32_t eax_4 = arg1[0xc]

if (eax_4 != data_10016730)
    __free_base(eax_4)

int32_t eax = arg1[0xd]

if (eax != data_10016734)
    __free_base(eax)
