// 函数: sub_100092bb
// 地址: 0x100092bb
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result
result.b = ***(arg1 - 0x14) == 0xc0000005
return result
