// 函数: ___acrt_uninitialize_ptd
// 地址: 0x714e03
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

BOOL result = data_7e1660

if (result != 0xffffffff)
    ___acrt_FlsFree@4(result)
    data_7e1660 = 0xffffffff

result.b = 1
return result
