// 函数: __fpmath
// 地址: 0x69e3c4
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = __cfltcvt_init()

if (arg1 != 0)
    result = __setdefaultprecision()

__fnclex()
return result
