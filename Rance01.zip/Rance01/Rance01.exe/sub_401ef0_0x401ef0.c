// 函数: sub_401ef0
// 地址: 0x401ef0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 != arg2)
    if (arg1[5] u>= 0x10)
        int32_t var_4_1 = *arg1
        sub_6b4d5b()
    
    arg1[5] = 0xf
    arg1[4] = 0
    *arg1 = 0
    
    if (*(arg2 + 0x14) u>= 0x10)
        *arg1 = *arg2
        *arg2 = 0
    else
        sub_6b49d0(arg1, arg2, *(arg2 + 0x10) + 1)
    
    arg1[4] = *(arg2 + 0x10)
    arg1[5] = *(arg2 + 0x14)
    *(arg2 + 0x14) = 0xf
    *(arg2 + 0x10) = 0
    *arg2 = 0

return arg1
