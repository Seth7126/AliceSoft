// 函数: $LN18
// 地址: 0x6c2117
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

uint32_t* result = __getptd()

if (result[0x24] s> 0)
    result = __getptd()
    result[0x24] -= 1

return result
