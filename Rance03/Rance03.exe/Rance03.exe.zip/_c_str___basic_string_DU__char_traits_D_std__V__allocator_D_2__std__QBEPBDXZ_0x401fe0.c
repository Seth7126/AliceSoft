// 函数: ?c_str@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QBEPBDXZ
// 地址: 0x401fe0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1[5] u< 0x10)
    return arg1

return *arg1
