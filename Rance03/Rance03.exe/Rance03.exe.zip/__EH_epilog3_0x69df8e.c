// 函数: __EH_epilog3
// 地址: 0x69df8e
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1[-3]
*arg1
*arg1 = __return_addr
