// 函数: __unwindfunclet$??1SchedulerBase@details@Concurrency@@UAE@XZ$9
// 地址: 0x6cb331
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_5e8d30(*(arg1 - 0x10) + 0x118) __tailcall
