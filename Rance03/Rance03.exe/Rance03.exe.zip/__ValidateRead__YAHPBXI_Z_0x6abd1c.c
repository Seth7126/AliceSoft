// 函数: ?_ValidateRead@@YAHPBXI@Z
// 地址: 0x6abd1c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax_1 = neg.d(arg1)
return sbb.d(eax_1, eax_1, arg1 != 0) & 1
