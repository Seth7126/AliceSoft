// 函数: __mbccpy_s
// 地址: 0x1000a12e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t var_8 = 0
return sub_10009fc2(arg1, arg2, arg3, arg4)
