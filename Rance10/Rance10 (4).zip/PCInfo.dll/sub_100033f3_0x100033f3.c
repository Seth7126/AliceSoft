// 函数: sub_100033f3
// 地址: 0x100033f3
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ExFilterRethrow(*(arg1 - 0x14))
