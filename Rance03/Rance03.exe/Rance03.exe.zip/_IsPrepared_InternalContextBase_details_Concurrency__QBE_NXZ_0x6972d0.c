// 函数: ?IsPrepared@InternalContextBase@details@Concurrency@@QBE_NXZ
// 地址: 0x6972d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result
result.b = *(arg1 + 0x1c) != 0
return result
