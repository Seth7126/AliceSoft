// 函数: ?__scrt_uninitialize_type_info@@YAXXZ
// 地址: 0x10002926
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___std_type_info_destroy_list(&data_10016bb0)
