// 函数: j_sub_60a4b0
// 地址: 0x60b2d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_60a4b0(arg1) __tailcall
