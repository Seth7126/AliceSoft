// 函数: sub_10007d3f
// 地址: 0x10007d3f
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __recalloc_base() __tailcall
