// 函数: sub_1000dbd0
// 地址: 0x1000dbd0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000dae0(arg1 - 0xe0, *(arg1 + 0x44) - 2, arg2, *(arg1 + 0x60), *(arg1 + 0x64), 
    *(arg1 + 0x68), *(arg1 + 0x6c))
