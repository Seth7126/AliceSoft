// 函数: ___set_app_type
// 地址: 0x6a7740
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

data_75d308 = arg1
return arg1
