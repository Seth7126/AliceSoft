// 函数: sub_10001080
// 地址: 0x10001080
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10016240(arg1)
*(arg1 + 4) -= 1
int32_t esi_1 = *(arg1 + 4)
int32_t eax
eax.b = esi_1 s<= 0
return (eax - 1) & esi_1
