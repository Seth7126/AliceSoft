// 函数: $LN10
// 地址: 0x69c14c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __unlock_file(arg1)
