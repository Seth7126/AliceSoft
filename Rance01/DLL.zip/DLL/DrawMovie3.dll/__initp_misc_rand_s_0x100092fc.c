// 函数: __initp_misc_rand_s
// 地址: 0x100092fc
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_100223e0 = arg1
return arg1
