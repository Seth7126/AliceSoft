// 函数: __ismbblead
// 地址: 0x6abd06
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_6abcac(nullptr, arg1, 0, 4)
