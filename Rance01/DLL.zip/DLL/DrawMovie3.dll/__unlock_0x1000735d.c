// 函数: __unlock
// 地址: 0x1000735d
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return LeaveCriticalSection(*((arg1 << 3) + &data_10020330))
