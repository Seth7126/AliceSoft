// 函数: _initialize_c
// 地址: 0x10006121
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

__initialize_onexit_table(0x10016dc0)
__initialize_onexit_table(0x10016dcc)
int32_t result
result.b = 1
return result
