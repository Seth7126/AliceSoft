// 函数: ??__E?m_badAllocExceptionPtr@__ExceptionPtr@@0V?$shared_ptr@V__ExceptionPtr@@@std@@A@@YAXXZ
// 地址: 0x402edd
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

__ExceptionPtr::_InitBadAllocException(&data_7fbaf8)
return _atexit(sub_74d6a6)
