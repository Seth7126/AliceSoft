// 函数: sub_10004997
// 地址: 0x10004997
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if ((arg3[3].b & 0x40) == 0 || arg3[2] != 0)
    int32_t temp0_1 = arg3[1]
    arg3[1] -= 1
    
    if (temp0_1 - 1 s< 0)
        int32_t* var_4_1 = arg3
        arg1 = sub_100047ac(sx.d(arg1.b))
    else
        **arg3 = arg1.b
        *arg3 += 1
        arg1 = zx.d(arg1.b)
    
    if (arg1 == 0xffffffff)
        *arg4 |= arg1
        return 

*arg4 += 1
