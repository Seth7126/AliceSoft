// 函数: sub_10004e52
// 地址: 0x10004e52
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax =
    try_get_function(8, "InitializeCriticalSectionEx", 0x1000f354, "InitializeCriticalSectionEx")

if (eax == 0)
    return InitializeCriticalSectionAndSpinCount(arg1, arg2)

j_sub_10004a52()
return eax(arg1, arg2, arg3)
