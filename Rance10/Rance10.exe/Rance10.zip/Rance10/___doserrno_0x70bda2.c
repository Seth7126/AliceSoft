// 函数: ___doserrno
// 地址: 0x70bda2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t eax_2 = ___acrt_getptd_noexit()

if (eax_2 != 0)
    return eax_2 + 0x14

return 0x7e14dc
