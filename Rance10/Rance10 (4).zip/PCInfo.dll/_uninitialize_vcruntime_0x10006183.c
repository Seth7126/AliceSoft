// 函数: _uninitialize_vcruntime
// 地址: 0x10006183
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___vcrt_uninitialize(0)
