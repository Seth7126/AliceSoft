// 函数: ??0bad_exception@std@@QAE@XZ
// 地址: 0x100024f6
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

arg1[1] = 0
arg1[2] = 0
arg1[1] = "bad array new length"
*arg1 = &std::bad_array_new_length::`vftable'{for `std::bad_alloc'}
return arg1
