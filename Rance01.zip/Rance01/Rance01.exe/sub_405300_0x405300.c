// 函数: sub_405300
// 地址: 0x405300
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1[0x17] u>= 0x10)
    int32_t __saved_ebx_1 = arg1[0x12]
    sub_6b4d5b()

arg1[0x17] = 0xf
arg1[0x16] = 0
arg1[0x12].b = 0

if (arg1[0x10] u>= 0x10)
    int32_t var_8_1 = arg1[0xb]
    sub_6b4d5b()

arg1[0x10] = 0xf
arg1[0xf] = 0
arg1[0xb].b = 0

if (arg1[5] u>= 0x10)
    int32_t var_8_2 = *arg1
    sub_6b4d5b()

arg1[4] = 0
arg1[5] = 0xf
*arg1 = 0
