// 函数: j_sub_405300
// 地址: 0x4052f0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_405300(arg1) __tailcall
