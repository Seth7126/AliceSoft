// 函数: sub_1000cff0
// 地址: 0x1000cff0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*(arg1 + 0x138) = 0xfffffc18
*(arg1 + 0x13c) = 0xffffffff
*(arg1 + 0x158) = timeGetTime()
*(arg1 + 0x10c) = 0xffffffff
*(arg1 + 0x110) = 0
*(arg1 + 0x108) = 0
__builtin_memset(arg1 + 0x140, 0, 0x18)
*(arg1 + 0xe8) = 0
*(arg1 + 0x104) = 0xfffb6c20
__builtin_memset(arg1 + 0xf0, 0, 0x14)
__builtin_memset(arg1 + 0x118, 0, 0x20)
return 0
