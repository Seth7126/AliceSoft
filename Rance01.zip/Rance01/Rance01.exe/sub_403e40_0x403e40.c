// 函数: sub_403e40
// 地址: 0x403e40
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (*(arg1 + 0x40) u>= 0x10)
    int32_t __saved_ebx_1 = *(arg1 + 0x2c)
    sub_6b4d5b()

*(arg1 + 0x40) = 0xf
*(arg1 + 0x3c) = 0
*(arg1 + 0x2c) = 0

if (*(arg1 + 0x24) u>= 0x10)
    int32_t var_8_1 = *(arg1 + 0x10)
    sub_6b4d5b()

*(arg1 + 0x20) = 0
*(arg1 + 0x24) = 0xf
*(arg1 + 0x10) = 0
