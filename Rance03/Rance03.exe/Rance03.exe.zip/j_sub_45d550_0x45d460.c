// 函数: j_sub_45d550
// 地址: 0x45d460
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_45d550(arg1) __tailcall
