// 函数: Run
// 地址: 0x100166a0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* eax_1 = data_100214ac

if (eax_1 != 0)
    if ((*(*eax_1 + 0x1c))(eax_1) s>= 0)
        int32_t eax
        eax.b = 1
        return eax
    
    sub_10015fa0(0x1001c5d4)

eax_1.b = 0
return eax_1
