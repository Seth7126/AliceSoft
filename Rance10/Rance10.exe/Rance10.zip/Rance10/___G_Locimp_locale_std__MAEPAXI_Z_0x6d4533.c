// 函数: ??_G_Locimp@locale@std@@MAEPAXI@Z
// 地址: 0x6d4533
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

std::locale::_Locimp::~_Locimp(arg1)

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
