// 函数: _mbtowc
// 地址: 0x10008555
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __mbtowc_l(arg1, arg2, arg3, nullptr)
