// 函数: ??0WaitAnyBlock@details@Concurrency@@QAE@I_N0@Z
// 地址: 0x6e95d2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::details::MultiWaitBlock::Concurrency::details::WaitAnyBlock::VTable** result =
    arg1
sub_6e94ad(arg1, arg2, arg3, arg4)
*result = &Concurrency::details::WaitAnyBlock::`vftable'{for `Concurrency::details::MultiWaitBlock'}
result[7] = 1
return result
