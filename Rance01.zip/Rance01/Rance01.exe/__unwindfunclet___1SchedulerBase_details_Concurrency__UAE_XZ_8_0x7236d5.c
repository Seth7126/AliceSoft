// 函数: __unwindfunclet$??1SchedulerBase@details@Concurrency@@UAE@XZ$8
// 地址: 0x7236d5
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5672c0(*(arg1 - 0x10) + 0xc8) __tailcall
