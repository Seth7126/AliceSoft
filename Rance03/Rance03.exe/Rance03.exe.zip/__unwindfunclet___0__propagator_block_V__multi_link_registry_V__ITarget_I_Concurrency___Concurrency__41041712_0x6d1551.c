// 函数: __unwindfunclet$??0?$propagator_block@V?$multi_link_registry@V?$ITarget@I@Concurrency@@@Concurrency@@V?$multi_link_registry@V?$ISource@I@Concurrency@@@2@V?$ordered_message_processor@I@2@@Concurrency@@QAE@XZ$1
// 地址: 0x6d1551
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_401fb0(*(arg1 - 0x10) + 0xe8) __tailcall
