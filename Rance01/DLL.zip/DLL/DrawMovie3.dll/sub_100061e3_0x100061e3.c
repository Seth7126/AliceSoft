// 函数: sub_100061e3
// 地址: 0x100061e3
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* result = __getptd()

if (*(result + 0x90) s> 0)
    result = __getptd() + 0x90
    *result -= 1

return result
