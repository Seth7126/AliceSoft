// 函数: sub_1000dca0
// 地址: 0x1000dca0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg2 == 0 && arg1->__offset(0x34).d != 0)
    int32_t eax_2 = neg.d(arg1 - 0xc)
    sub_1000eed0(arg1 - 0xc, 0x15, sbb.d(eax_2, eax_2, arg1 != 0xc) & arg1, nullptr)

return sub_10010430(arg1, arg2, arg3)
