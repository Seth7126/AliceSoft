// 函数: __unwindfunclet$??0ScheduleGroupSegmentBase@details@Concurrency@@IAE@PAVScheduleGroupBase@12@PAVSchedulingRing@12@PAVlocation@2@@Z$4
// 地址: 0x6c2632
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_403510(*(arg1 - 0x10) + 0xa8) __tailcall
