// 函数: __frnd
// 地址: 0x100188ad
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t ecx
int32_t var_8 = ecx
int32_t var_c = ecx
var_c.q = fconvert.d(roundint.t(fconvert.t(arg1)))
return fconvert.t(var_c.q)
