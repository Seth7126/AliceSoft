// 函数: j_sub_4d3de0
// 地址: 0x4d3130
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_4d3de0(arg1) __tailcall
