// 函数: ??0bad_function_call@std@@QAE@XZ
// 地址: 0x6f30e1
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::invalid_oversubscribe_operation::`vftable'{for `std::exception'}
return arg1
