// 函数: @_EH4_LocalUnwind@16
// 地址: 0x10008b14
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return __local_unwind4(arg4, arg1, arg2)
