// 函数: __cfltcvt_l
// 地址: 0x6a8de6
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg4 == 0x65 || arg4 == 0x45)
    return sub_6a9337(arg1, arg2, arg3, arg5, arg6, arg7)

if (arg4 == 0x66)
    return sub_6a94f1(arg1, arg2, arg3, arg5, arg7)

if (arg4 != 0x61 && arg4 != 0x41)
    return sub_6a95b2(arg1, arg2, arg3, arg5, arg6, arg7)

return sub_6a8e6c(arg1, arg2, arg3, arg5, arg6, arg7)
