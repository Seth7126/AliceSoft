// 函数: ??__EtytiNil@@YAXXZ
// 地址: 0x100162f0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

__builtin_memset(&data_100214a0, 0, 0x20)
data_10021498 = &CDrawPlugin::`vftable'{for `IDrawPlugin'}
data_1002149c = 1
data_100214c0 = 0x64
data_100214c4 = 0xffffffff
return &data_10021498
