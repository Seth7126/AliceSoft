// 函数: sub_1000dce0
// 地址: 0x1000dce0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 0x8c
return sub_1000c010() __tailcall
