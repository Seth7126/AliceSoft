// 函数: j__free
// 地址: 0x69b578
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return j__free(arg1) __tailcall
