// 函数: __seh_longjmp_unwind4@4
// 地址: 0x6c0f06
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*arg1
return __local_unwind4(arg1[0xa], arg1[6], arg1[7])
