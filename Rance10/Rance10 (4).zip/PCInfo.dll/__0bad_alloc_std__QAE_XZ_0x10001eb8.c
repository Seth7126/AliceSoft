// 函数: ??0bad_alloc@std@@QAE@XZ
// 地址: 0x10001eb8
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

arg1[1] = 0
arg1[2] = 0
arg1[1] = "bad allocation"
*arg1 = &std::bad_alloc::`vftable'{for `std::exception'}
return arg1
