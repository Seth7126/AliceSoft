// 函数: sub_100073e4
// 地址: 0x100073e4
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return sub_10006f59() __tailcall
