// 函数: sub_10005af3
// 地址: 0x10005af3
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return common_configure_argv<char>() __tailcall
