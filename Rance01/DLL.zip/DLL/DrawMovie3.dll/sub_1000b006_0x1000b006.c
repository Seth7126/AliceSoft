// 函数: sub_1000b006
// 地址: 0x1000b006
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void arg_4
void* ecx_1 = (&arg_4 - arg1) & 7
return __chkstk((arg1 + ecx_1) | sbb.d(ecx_1, ecx_1, arg1 + ecx_1 u< arg1)) __tailcall
