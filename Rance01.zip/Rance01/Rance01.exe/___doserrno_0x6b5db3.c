// 函数: ___doserrno
// 地址: 0x6b5db3
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

uint32_t* eax_2 = sub_6bb95f()

if (eax_2 != 0)
    return &eax_2[3]

return 0x78c1ec
