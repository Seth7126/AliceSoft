// 函数: ??$_Find_elem@D@std@@YAIPADD@Z
// 地址: 0x6d0c91
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

char* eax = arg1
char i = *arg1

if (i != 0)
    int32_t ebx
    ebx.b = arg2
    
    while (i != ebx.b)
        eax = &eax[1]
        i = *eax
        
        if (i == 0)
            break

return eax - arg1
