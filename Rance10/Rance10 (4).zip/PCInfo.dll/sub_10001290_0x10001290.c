// 函数: sub_10001290
// 地址: 0x10001290
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* ecx

if (*arg1 == 0)
    return sub_100016e0(ecx, arg1, nullptr)

char* edx = arg1
char i

do
    i = *edx
    edx = &edx[1]
while (i != 0)
return sub_100016e0(ecx, arg1, edx - &edx[1])
