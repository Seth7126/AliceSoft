// 函数: sub_100044ca
// 地址: 0x100044ca
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t esi = *(sub_10004538() + 4)

if (esi != 0)
    j_sub_10004a52()
    esi()

sub_1000624c()
noreturn
