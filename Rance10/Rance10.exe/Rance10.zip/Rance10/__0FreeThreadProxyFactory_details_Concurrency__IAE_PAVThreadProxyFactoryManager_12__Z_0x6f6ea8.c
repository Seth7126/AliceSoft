// 函数: ??0FreeThreadProxyFactory@details@Concurrency@@IAE@PAVThreadProxyFactoryManager@12@@Z
// 地址: 0x6f6ea8
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::details::IThreadProxyFactory::Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>::VTable
    ** var_8 = arg1
struct Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>::Concurrency::details::FreeThreadProxyFactory::VTable
    ** result = arg1
struct Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>::Concurrency::details::FreeThreadProxyFactory::VTable
    ** result_1 = result
Concurrency::details::ThreadProxyFactory<class Concurrency::details::UMSFreeThreadProxy>::ThreadProxyFactory<class Concurrency::details::UMSFreeThreadProxy>(
    arg1, arg2)
*result = &Concurrency::details::FreeThreadProxyFactory::`vftable'{for `Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>'}
result[0xa] = 1
result[0xb].b = 0
return result
