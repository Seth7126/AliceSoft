// 函数: sub_1000d220
// 地址: 0x1000d220
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

(*(*arg1 + 0xb4))(arg1[0x54], arg1[0x55])
uint32_t result = timeGetTime()
arg1[0x3f] = result
return result
