// 函数: ?_msize_base@@YAIQAX@Z
// 地址: 0x6b8354
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 != 0)
    return HeapSize(data_797930, HEAP_NONE, arg1)

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
