// 函数: sub_10001dc9
// 地址: 0x10001dc9
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t i

do
    void* result = sub_100037d7(arg1)
    
    if (result != 0)
        return result
    
    i = sub_100038b0(arg1)
while (i != 0)

if ((data_10021a0c & 1) == 0)
    data_10021a0c.d |= 1
    sub_10001dae(&data_10021a00)
    _atexit(sub_10019767)

struct std::exception::VTable* var_10
sub_10001bc0(&var_10, &data_10021a00)
sub_1000272b(&var_10, 0x1001eed8)
noreturn
