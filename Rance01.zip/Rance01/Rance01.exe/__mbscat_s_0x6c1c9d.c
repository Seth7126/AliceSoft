// 函数: __mbscat_s
// 地址: 0x6c1c9d
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c1b87(arg1, arg2, arg3, nullptr)
