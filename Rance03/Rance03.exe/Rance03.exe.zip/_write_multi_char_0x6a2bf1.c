// 函数: _write_multi_char
// 地址: 0x6a2bf1
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t i = arg2

while (i s> 0)
    i -= 1
    sub_6a2ba9(arg1, arg3, arg4)
    
    if (*arg4 == 0xffffffff)
        break
