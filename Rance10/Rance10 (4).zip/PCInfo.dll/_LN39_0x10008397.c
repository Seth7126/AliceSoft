// 函数: $LN39
// 地址: 0x10008397
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (*(arg1 - 0x1d) != 0)
    ___acrt_unlock(3)
