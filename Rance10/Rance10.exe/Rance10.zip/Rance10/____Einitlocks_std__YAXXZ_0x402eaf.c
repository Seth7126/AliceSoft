// 函数: ??__Einitlocks@std@@YAXXZ
// 地址: 0x402eaf
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

std::_Init_locks::_Init_locks(0x7fb9d8)
return _atexit(sub_74d688)
