// 函数: __mbsnextc
// 地址: 0x10012ef7
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10012dcb(arg1, nullptr)
