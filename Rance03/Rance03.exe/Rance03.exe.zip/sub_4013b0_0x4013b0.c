// 函数: sub_4013b0
// 地址: 0x4013b0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f59c, "AlicArch", 8)
return _atexit(sub_6d1e50)
