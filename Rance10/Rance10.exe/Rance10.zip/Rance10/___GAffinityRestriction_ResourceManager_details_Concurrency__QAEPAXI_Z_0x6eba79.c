// 函数: ??_GAffinityRestriction@ResourceManager@details@Concurrency@@QAEPAXI@Z
// 地址: 0x6eba79
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

operator new(*(arg1 + 4))

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
