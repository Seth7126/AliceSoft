// 函数: ??$?RV<lambda_823d65812123d985753d53e2a8c25d20>@@AAV<lambda_0a97c9e57da7be065955385c79108ff2>@@V<lambda_4d2973f3ad2d226f00468307185dca1b>@@@?$__crt_seh_guarded_call@H@@QAEH$$QAV<lambda_823d65812123d985753d53e2a8c25d20>@@AAV<lambda_0a97c9e57da7be065955385c79108ff2>@@$$QAV<lambda_4d2973f3ad2d226f00468307185dca1b>@@@Z
// 地址: 0x703ded
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t __saved_ebp_1 = 0xc
int32_t var_8 = 0x7de3b0
int32_t (* var_10)(int32_t* arg1, void* arg2, int32_t arg3) = __except_handler4
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
uint32_t __security_cookie_1 = __security_cookie
int32_t var_8_3 = 0x7de3b0 ^ __security_cookie_1
int32_t __saved_ebp
int32_t var_30 = __security_cookie_1 ^ &__saved_ebp
int32_t* var_1c = &var_30
void* const var_34_1 = &data_703df9
int32_t var_8_4 = 0xfffffffe
int32_t var_c = var_8_3
fsbase->NtTib.ExceptionList = &ExceptionList
int32_t var_20 = 0
__lock_file(*arg1)
int32_t var_8_1 = 0
int32_t result = <lambda_0a97c9e57da7be065955385c79108ff2>::operator()(arg2)
int32_t result_1 = result
int32_t var_8_2 = 0xfffffffe
$LN7(&__saved_ebp)
fsbase->NtTib.ExceptionList = ExceptionList
void* const __saved_ebp_2 = &data_703e2c
return result
