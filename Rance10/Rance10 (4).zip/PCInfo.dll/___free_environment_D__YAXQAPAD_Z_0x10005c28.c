// 函数: ??$free_environment@D@@YAXQAPAD@Z
// 地址: 0x10005c28
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    return 

int32_t i = *arg1
int32_t edi
int32_t var_c_1 = edi
int32_t* edi_1 = arg1

for (; i != 0; i = *edi_1)
    __free_base(i)
    edi_1 = &edi_1[1]

__free_base(arg1)
