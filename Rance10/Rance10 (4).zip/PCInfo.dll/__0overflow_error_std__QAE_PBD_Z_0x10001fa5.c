// 函数: ??0overflow_error@std@@QAE@PBD@Z
// 地址: 0x10001fa5
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::exception::VTable** var_8 = arg1
struct std::logic_error::std::out_of_range::VTable** result = arg1
struct std::logic_error::std::out_of_range::VTable** result_1 = result
std::exception::exception(arg1, arg2)
*result = &std::out_of_range::`vftable'{for `std::logic_error'}
return result
