// 函数: ___strncnt
// 地址: 0x10009eae
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

char* result = nullptr

if (*arg1 != 0)
    while (result != arg2)
        result = &result[1]
        
        if (*(result + arg1) == 0)
            break

return result
