// 函数: sub_10002f4c
// 地址: 0x10002f4c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

jump(*((arg1 << 2) + &data_10002f64))
