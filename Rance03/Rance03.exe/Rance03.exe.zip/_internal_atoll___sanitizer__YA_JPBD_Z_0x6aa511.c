// 函数: ?internal_atoll@__sanitizer@@YA_JPBD@Z
// 地址: 0x6aa511
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return _strtol(arg1, nullptr, 0xa)
