// 函数: ??1_Timevec@std@@QAE@XZ
// 地址: 0x417e00
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return j__free(*arg1)
