// 函数: ??$_Copy_unchecked@PADV?$ostreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@YA?AV?$ostreambuf_iterator@DU?$char_traits@D@std@@@0@PAD0V10@@Z
// 地址: 0x6e3757
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t ecx
int32_t var_8 = ecx
var_8.b = 0
int32_t var_c = var_8
int32_t var_10 = arg5
int32_t edi
std::_Copy_unchecked1<char*,class std::ostreambuf_iterator<char,struct std::char_traits<char> > >(
    edi, arg1, arg2, arg3, arg4)
return arg1
