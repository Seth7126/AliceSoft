// 函数: __shift
// 地址: 0x6a983b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg2 != 0)
    _memcpy(arg1 + arg2, arg1, _strlen(arg1) + 1)
