// 函数: __unwindfunclet$??1SchedulerBase@details@Concurrency@@UAE@XZ$10
// 地址: 0x6cfd77
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_670750(*(arg1 - 0x10) + 0x168) __tailcall
