// 函数: $LN9
// 地址: 0x1000ac82
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __unlock_file(*(arg1 - 0x20))
