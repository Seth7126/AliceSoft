// 函数: ___acrt_has_user_matherr
// 地址: 0x71132f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

uint32_t __security_cookie_1 = __security_cookie
int32_t eax_1 = ror.d(__security_cookie_1 ^ data_7fc6fc, __security_cookie_1.b & 0x1f)
int32_t eax_2 = neg.d(eax_1)
return neg.d(sbb.d(eax_2, eax_2, eax_1 != 0))
