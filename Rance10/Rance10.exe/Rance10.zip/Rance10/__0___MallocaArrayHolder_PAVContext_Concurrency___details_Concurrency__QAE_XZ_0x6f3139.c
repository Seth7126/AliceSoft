// 函数: ??0?$_MallocaArrayHolder@PAVContext@Concurrency@@@details@Concurrency@@QAE@XZ
// 地址: 0x6f3139
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::missing_wait::`vftable'{for `std::exception'}
return arg1
