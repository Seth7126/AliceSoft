// 函数: __unwindfunclet$??1?$call@IV?$function@$$A6AXABI@Z@std@@@Concurrency@@UAE@XZ$1
// 地址: 0x71e5e6
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_58ae70(*(arg1 - 0x10) + 0xf8) __tailcall
