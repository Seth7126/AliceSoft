// 函数: __initp_misc_rand_s
// 地址: 0x6a7dd9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

data_75cb48 = arg1
return arg1
