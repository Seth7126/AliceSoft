// 函数: j___CItan_pentium4
// 地址: 0x7103db
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return __CItan_pentium4(arg1) __tailcall
