// 函数: ___acrt_initialize_signal_handlers
// 地址: 0x10008193
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(0x1001722c, arg1)
__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(0x10017230, arg1)
__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(&data_10017234, 
    arg1)
return __crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(0x10017238, 
    arg1)
