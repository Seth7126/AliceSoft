// 函数: __IsExceptionObjectToBeDestroyed
// 地址: 0x10004957
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

for (int32_t* i = *(sub_10004538() + 0x24); i != 0; i = i[1])
    if (*i == arg1)
        return 0

return 1
