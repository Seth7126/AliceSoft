// 函数: _quick_exit
// 地址: 0x10004547
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_1000441b(exit_code, 1, 0)
