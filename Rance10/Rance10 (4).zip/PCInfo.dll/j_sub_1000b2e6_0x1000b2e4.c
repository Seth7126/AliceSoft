// 函数: j_sub_1000b2e6
// 地址: 0x1000b2e4
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return sub_1000b2e6() __tailcall
