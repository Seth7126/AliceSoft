// 函数: ??0VirtualProcessor@details@Concurrency@@QAE@XZ
// 地址: 0x6f7718
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::details::VirtualProcessor::VTable** var_8 = arg1
struct Concurrency::details::VirtualProcessor::VTable** var_8_1 = arg1
*arg1 = &Concurrency::details::VirtualProcessor::`vftable'
sub_6fc4a2(&arg1[4], &arg1[0x21])
arg1[0xa] = 0
arg1[0xb] = 0
arg1[0x12] = 0
arg1[0x13] = 0
arg1[0x21] = 0
__builtin_memset(&arg1[0x25], 0, 0x18)
arg1[0x30] = 0
return arg1
