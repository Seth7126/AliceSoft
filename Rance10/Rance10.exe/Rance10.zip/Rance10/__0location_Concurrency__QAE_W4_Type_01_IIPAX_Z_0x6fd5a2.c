// 函数: ??0location@Concurrency@@QAE@W4_Type@01@IIPAX@Z
// 地址: 0x6fd5a2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = arg2 & 0xfffffff
arg1[1] = arg4
arg1[3] = arg5
arg1[2] = arg3
return arg1
