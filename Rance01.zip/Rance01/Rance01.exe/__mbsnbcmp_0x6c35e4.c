// 函数: __mbsnbcmp
// 地址: 0x6c35e4
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t var_8 = 0
int32_t eax
int32_t ecx
int32_t edx
return sub_6c35a2(eax, edx, ecx, arg1, arg2, arg3)
