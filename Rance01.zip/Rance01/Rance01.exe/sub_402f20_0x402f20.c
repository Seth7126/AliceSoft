// 函数: sub_402f20
// 地址: 0x402f20
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_402f40(arg1)

if ((arg2 & 1) != 0)
    struct IAFAFile::afafactory::CAFAFile::VTable** var_8_1 = arg1
    sub_6b4d5b()

return arg1
