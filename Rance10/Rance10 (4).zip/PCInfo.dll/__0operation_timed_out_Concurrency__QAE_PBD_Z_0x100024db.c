// 函数: ??0operation_timed_out@Concurrency@@QAE@PBD@Z
// 地址: 0x100024db
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::bad_alloc::std::bad_array_new_length::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::bad_array_new_length::`vftable'{for `std::bad_alloc'}
return result
