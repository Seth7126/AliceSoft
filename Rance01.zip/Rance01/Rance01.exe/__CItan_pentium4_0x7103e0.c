// 函数: __CItan_pentium4
// 地址: 0x7103e0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

double var_10 = fconvert.d(arg1)
uint64_t xmm5[0x2]
int64_t xmm6
return start(zx.o(var_10), xmm5, xmm6, var_10)
