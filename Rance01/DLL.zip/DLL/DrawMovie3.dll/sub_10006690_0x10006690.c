// 函数: sub_10006690
// 地址: 0x10006690
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

terminate()
noreturn
