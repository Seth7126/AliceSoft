// 函数: __unwindfunclet$??1SchedulerBase@details@Concurrency@@UAE@XZ$7
// 地址: 0x6b5176
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_697200(*(arg1 - 0x10) + 0xb4) __tailcall
