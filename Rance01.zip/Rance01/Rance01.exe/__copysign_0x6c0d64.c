// 函数: __copysign
// 地址: 0x6c0d64
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t ecx
int32_t var_8 = ecx
int32_t var_c = ecx
var_c.q = fconvert.d(float.t(0))
int32_t var_8_1 = ((arg3 ^ arg2) & 0x7fffffff) ^ arg3
return fconvert.t(arg1.q)
