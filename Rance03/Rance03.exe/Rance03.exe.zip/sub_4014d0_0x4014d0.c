// 函数: sub_4014d0
// 地址: 0x4014d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f674, 0x6da24f, nullptr)
return _atexit(sub_6d2200)
