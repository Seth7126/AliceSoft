// 函数: ??0?$COMRefPtr@VIDebugSSubSection@@@@QAE@XZ
// 地址: 0x6976f0
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 0
return arg1
