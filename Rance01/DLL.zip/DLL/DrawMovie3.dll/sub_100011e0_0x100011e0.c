// 函数: sub_100011e0
// 地址: 0x100011e0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::logic_error::std::length_error::VTable** result = arg1
sub_10001110(arg1, arg2)
*result = &std::length_error::`vftable'{for `std::logic_error'}
return result
