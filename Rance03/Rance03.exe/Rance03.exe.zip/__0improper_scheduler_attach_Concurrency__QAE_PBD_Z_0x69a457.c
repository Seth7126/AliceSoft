// 函数: ??0improper_scheduler_attach@Concurrency@@QAE@PBD@Z
// 地址: 0x69a457
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

struct std::logic_error::std::length_error::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::length_error::`vftable'{for `std::logic_error'}
return result
