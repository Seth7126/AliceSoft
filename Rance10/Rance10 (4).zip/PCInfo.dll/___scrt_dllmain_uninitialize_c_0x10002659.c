// 函数: ___scrt_dllmain_uninitialize_c
// 地址: 0x10002659
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (___asan_report_present() != 0)
    void* ecx
    return __execute_onexit_table(ecx)

int32_t result = sub_100057ff()

if (result == 0)
    return common_exit(0, 0, 1)

return result
