// 函数: IsEnd
// 地址: 0x10016760
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* result = data_100214b4

if (result != 0)
    result.b = *(result + 0x70) != 0
    return result

result.b = 1
return result
