// 函数: __alloca_probe_16
// 地址: 0x6abc80
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

void arg_4
void* ecx_1 = (&arg_4 - arg1) & 0xf
return __chkstk((arg1 + ecx_1) | sbb.d(ecx_1, ecx_1, arg1 + ecx_1 u< arg1)) __tailcall
