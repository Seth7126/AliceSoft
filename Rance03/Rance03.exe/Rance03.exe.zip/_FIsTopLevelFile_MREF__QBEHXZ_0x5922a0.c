// 函数: ?FIsTopLevelFile@MREF@@QBEHXZ
// 地址: 0x5922a0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result
result.b = *(arg1 + 8) == 1
return result
