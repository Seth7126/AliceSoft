// 函数: ___acrt_unlock
// 地址: 0x10006a03
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return LeaveCriticalSection(arg1 * 0x18 + &data_10016dd8)
