// 函数: sub_10002a7c
// 地址: 0x10002a7c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10016bc8 = 0
