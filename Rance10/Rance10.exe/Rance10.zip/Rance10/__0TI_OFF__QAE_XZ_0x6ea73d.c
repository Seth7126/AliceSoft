// 函数: ??0TI_OFF@@QAE@XZ
// 地址: 0x6ea73d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 0
arg1[1] = 0
return arg1
