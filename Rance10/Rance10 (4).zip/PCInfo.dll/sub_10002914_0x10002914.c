// 函数: sub_10002914
// 地址: 0x10002914
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return 1
