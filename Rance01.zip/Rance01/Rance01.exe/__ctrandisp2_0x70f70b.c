// 函数: __ctrandisp2
// 地址: 0x70f70b
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t __saved_ebp
int32_t* ebp = &__saved_ebp
int32_t var_2dc = arg3
int32_t entry_ebx
long double st0 = __fload(arg2, entry_ebx.w)
int32_t var_2dc_1 = arg5
long double result = __fload(arg4)
int16_t x87status
int16_t temp0
temp0, x87status = __fnstcw_memmem16(arg1)
int16_t var_a8 = temp0
char var_2cc
char var_2cc_1 = var_2cc | 2
int32_t ecx
void* edx
__trandisp2(ecx, edx, ebp, result, st0)
ctranexit(ebp)
return result
