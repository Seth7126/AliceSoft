// 函数: sub_4015d0
// 地址: 0x4015d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f734, &(*U",\n\n}")[2]:2, nullptr)
return _atexit(sub_6d2500)
