// 函数: sub_1000283a
// 地址: 0x1000283a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10001d19(arg2[2] ^ arg2)
return sub_10006bf8(arg1, arg2[4], arg3, nullptr, arg2[3], arg2[5], arg2, 0)
