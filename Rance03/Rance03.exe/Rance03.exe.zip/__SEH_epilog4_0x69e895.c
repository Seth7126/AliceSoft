// 函数: __SEH_epilog4
// 地址: 0x69e895
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1[-4]
*arg1
*arg1 = __return_addr
