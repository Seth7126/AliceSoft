// 函数: j_sub_10005afe
// 地址: 0x10005d04
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return common_initialize_environment_nolock<char>() __tailcall
