// 函数: __lseeki64_nolock
// 地址: 0x1000ab7b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax
int32_t ecx
int32_t edx
return common_lseek_nolock<int64_t>(eax, edx, ecx, arg1, arg2, arg3, arg4)
