// 函数: sub_10009173
// 地址: 0x10009173
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t edi
int32_t var_8 = edi
int32_t result

for (int32_t i = 0; i u< 0x28; )
    void* esi_1 = i + &data_10020a68
    result = sub_10002fe8(*esi_1)
    i += 4
    *esi_1 = result

return result
