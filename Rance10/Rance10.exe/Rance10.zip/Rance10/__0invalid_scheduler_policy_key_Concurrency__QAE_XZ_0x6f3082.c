// 函数: ??0invalid_scheduler_policy_key@Concurrency@@QAE@XZ
// 地址: 0x6f3082
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::context_self_unblock::`vftable'{for `std::exception'}
return arg1
