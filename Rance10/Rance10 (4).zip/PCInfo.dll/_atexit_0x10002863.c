// 函数: _atexit
// 地址: 0x10002863
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax = __onexit(arg1)
int32_t eax_1 = neg.d(eax)
return neg.d(sbb.d(eax_1, eax_1, eax != 0)) - 1
