// 函数: __rtzerospop
// 地址: 0x1000b2eb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return 
