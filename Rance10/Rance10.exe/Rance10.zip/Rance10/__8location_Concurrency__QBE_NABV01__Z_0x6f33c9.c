// 函数: ??8location@Concurrency@@QBE_NABV01@@Z
// 地址: 0x6f33c9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (((*arg2 ^ *arg1) & 0xfffffff) == 0 && *(arg1 + 8) == arg2[2])
    return 1

return 0
