// 函数: sub_1000778f
// 地址: 0x1000778f
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 == 0x3a4)
    return 0x411

if (arg1 == 0x3a8)
    return 0x804

if (arg1 == 0x3b5)
    return 0x412

if (arg1 == 0x3b6)
    return 0x404

return 0
