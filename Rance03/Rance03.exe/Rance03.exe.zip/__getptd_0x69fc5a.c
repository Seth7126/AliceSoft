// 函数: __getptd
// 地址: 0x69fc5a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t* result = sub_69fc72()

if (result != 0)
    return result

__amsg_exit(0x10)
noreturn
