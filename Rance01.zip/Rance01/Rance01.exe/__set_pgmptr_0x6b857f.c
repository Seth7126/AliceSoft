// 函数: __set_pgmptr
// 地址: 0x6b857f
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_797860 = arg1
return arg1
