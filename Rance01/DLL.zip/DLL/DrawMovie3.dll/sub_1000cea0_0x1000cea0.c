// 函数: sub_1000cea0
// 地址: 0x1000cea0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = (*(**(arg1 + 0xd8) + 0x8c))()

if (result s< 0)
    return result

return sub_1000fd90(arg1) __tailcall
