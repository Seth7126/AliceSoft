// 函数: j_sub_100127d0
// 地址: 0x1000ef20
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_100127d0(arg1) __tailcall
