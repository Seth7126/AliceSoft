// 函数: ??$?RV<lambda_c76fdea48760d5f9368b465f31df4405>@@AAV<lambda_e378711a6f6581bf7f0efd7cdf97f5d9>@@V<lambda_e927a58b2a85c081d733e8c6192ae2d2>@@@?$__crt_seh_guarded_call@X@@QAEX$$QAV<lambda_c76fdea48760d5f9368b465f31df4405>@@AAV<lambda_e378711a6f6581bf7f0efd7cdf97f5d9>@@$$QAV<lambda_e927a58b2a85c081d733e8c6192ae2d2>@@@Z
// 地址: 0x711526
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t __saved_ebp_1 = 8
int32_t var_8 = 0x7de5a0
int32_t (* var_10)(int32_t* arg1, void* arg2, int32_t arg3) = __except_handler4
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
uint32_t __security_cookie_1 = __security_cookie
int32_t var_8_3 = 0x7de5a0 ^ __security_cookie_1
int32_t __saved_ebp
int32_t var_2c = __security_cookie_1 ^ &__saved_ebp
int32_t* var_1c = &var_2c
void* const var_30_1 = &data_711532
int32_t var_8_4 = 0xfffffffe
int32_t var_c = var_8_3
fsbase->NtTib.ExceptionList = &ExceptionList
___acrt_lock(*arg1)
int32_t var_8_1 = 0
<lambda_e378711a6f6581bf7f0efd7cdf97f5d9>::operator()(arg2)
int32_t var_8_2 = 0xfffffffe
int32_t result = $LN14(&__saved_ebp)
fsbase->NtTib.ExceptionList = ExceptionList
void* const __saved_ebp_2 = &data_71155a
return result
