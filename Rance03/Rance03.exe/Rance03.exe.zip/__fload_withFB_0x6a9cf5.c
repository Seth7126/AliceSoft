// 函数: __fload_withFB
// 地址: 0x6a9cf5
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if ((*(arg2 + 4) & 0x7ff00000) != 0x7ff00000)
    return fconvert.t(*arg2)

int32_t var_4 = *(arg2 + 4) | 0x7fff0000
int32_t ecx = *arg2
int32_t var_6 = *(arg2 + 4) << 0xb | ecx u>> 0xffffffeb
*(arg2 + 4)
return (ecx << 0xb).t
