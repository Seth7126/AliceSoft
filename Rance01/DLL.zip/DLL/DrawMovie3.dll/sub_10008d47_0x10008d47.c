// 函数: sub_10008d47
// 地址: 0x10008d47
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax
int32_t edi
data_10023504 = sub_10008ce5(eax, edi)
return 0
