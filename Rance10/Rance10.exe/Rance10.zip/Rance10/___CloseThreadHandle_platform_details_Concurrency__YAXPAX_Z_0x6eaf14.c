// 函数: ?__CloseThreadHandle@platform@details@Concurrency@@YAXPAX@Z
// 地址: 0x6eaf14
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return CloseHandle(arg1)
