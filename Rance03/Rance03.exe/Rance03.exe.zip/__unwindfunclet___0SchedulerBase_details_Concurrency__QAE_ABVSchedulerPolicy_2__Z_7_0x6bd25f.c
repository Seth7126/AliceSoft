// 函数: __unwindfunclet$??0SchedulerBase@details@Concurrency@@QAE@ABVSchedulerPolicy@2@@Z$7
// 地址: 0x6bd25f
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_410440(*(arg1 - 0x10) + 0xb4) __tailcall
