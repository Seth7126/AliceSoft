// 函数: __NLG_Call
// 地址: 0x6bffd4
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eax
return eax()
