// 函数: sub_10001000
// 地址: 0x10001000
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_4 = 0
int32_t* var_8 = arg1
uint32_t edx
sub_10001c00(arg1, edx)
return arg1
