// 函数: sub_1000b054
// 地址: 0x1000b054
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000a464(arg1, nullptr, 0xa)
