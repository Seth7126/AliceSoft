// 函数: ?__ExceptionPtrCopy@@YAXPAXPBX@Z
// 地址: 0x6d54c3
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg1 == 0)
    return 

*arg1 = 0
arg1[1] = 0
std::_Ptr_base<class __ExceptionPtr,class __ExceptionPtr>::_Reset<class __ExceptionPtr>(arg2)
