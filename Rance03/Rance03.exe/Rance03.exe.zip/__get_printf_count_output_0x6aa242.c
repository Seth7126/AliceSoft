// 函数: __get_printf_count_output
// 地址: 0x6aa242
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result
result.b = data_75d460 == (__security_cookie | 1)
return result
