// 函数: __initp_misc_winsig
// 地址: 0x6a636c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

data_75d198 = arg1
data_75d19c = arg1
data_75d1a0 = arg1
data_75d1a4 = arg1
return arg1
