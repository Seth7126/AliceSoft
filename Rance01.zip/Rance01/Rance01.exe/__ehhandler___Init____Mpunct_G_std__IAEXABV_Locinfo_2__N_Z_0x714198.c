// 函数: __ehhandler$?_Init@?$_Mpunct@G@std@@IAEXABV_Locinfo@2@_N@Z
// 地址: 0x714198
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b4885(*(arg1 - 0x54) ^ (arg1 + 0xc))
sub_6b4885(*(arg1 - 8) ^ (arg1 + 0xc))
return sub_6bb3b5(0x775884) __tailcall
