// 函数: sub_10004da1
// 地址: 0x10004da1
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax = try_get_function(5, "FlsFree", 0x1000f31c, "FlsFree")

if (eax == 0)
    return TlsFree(arg1)

j_sub_10004a52()
return eax(arg1)
