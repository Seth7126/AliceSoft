// 函数: DefWindowProcA
// 地址: 0x61c140
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return DefWindowProcA(hWnd, Msg, wParam, lParam) __tailcall
