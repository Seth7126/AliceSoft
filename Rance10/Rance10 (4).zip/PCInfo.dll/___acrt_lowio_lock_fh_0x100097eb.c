// 函数: ___acrt_lowio_lock_fh
// 地址: 0x100097eb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return EnterCriticalSection((arg1 & 0x3f) * 0x30 + (&data_10017028)[arg1 s>> 6])
