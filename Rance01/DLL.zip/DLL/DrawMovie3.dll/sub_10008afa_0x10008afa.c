// 函数: sub_10008afa
// 地址: 0x10008afa
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return RtlUnwind(arg1, 0x10008b0f, nullptr, nullptr)
