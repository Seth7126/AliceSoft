// 函数: __twoToTOS
// 地址: 0x70de10
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

long double result = roundint.t(arg1)
__fscale(__f2xm1(fneg(result - arg1)) + float.t(1), result)
return result
