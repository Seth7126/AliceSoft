// 函数: sub_1000456c
// 地址: 0x1000456c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax = sub_1000305a()
__set_pgmptr(eax)
__initp_misc_rand_s(eax)
__initp_misc_invarg(eax)
__initp_misc_purevirt(eax)
___set_app_type(eax)
___acrt_initialize_signal_handlers(eax)
int32_t var_20 = eax
int32_t var_24 = eax
sub_10006d62()
void* result = sub_10002fe8(_quick_exit)
data_100202a0 = result
return result
