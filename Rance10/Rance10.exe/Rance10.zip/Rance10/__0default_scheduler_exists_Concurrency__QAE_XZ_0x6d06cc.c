// 函数: ??0default_scheduler_exists@Concurrency@@QAE@XZ
// 地址: 0x6d06cc
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &std::bad_function_call::`vftable'{for `std::exception'}
return arg1
