// 函数: __invalid_parameter
// 地址: 0x69ff59
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax = DecodePointer(data_75c974)

if (eax != 0)
    jump(eax)

int32_t var_8_1 = arg5
int32_t var_c = arg4
int32_t var_10 = arg3
int32_t var_14 = arg2
int32_t var_18 = arg1
__invoke_watson()
noreturn
