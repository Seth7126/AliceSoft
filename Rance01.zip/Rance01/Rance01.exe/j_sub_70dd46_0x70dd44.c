// 函数: j_sub_70dd46
// 地址: 0x70dd44
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_70dd46() __tailcall
