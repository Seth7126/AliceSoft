// 函数: __endthreadex
// 地址: 0x69b838
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t* eax = sub_69fc72()

if (eax != 0)
    if (eax[0xed] != 0)
        __uninitMTAoncurrentthread()
    
    ___vcrt_freeptd(eax)

ExitThread(arg1)
noreturn
