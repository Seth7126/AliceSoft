// 函数: ??0AllocatorBucket@details@Concurrency@@QAE@XZ
// 地址: 0x6f896e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 0
arg1[1] = Concurrency::details::Security::EncodePointer(0)
return arg1
