// 函数: ?<helper_func_cdecl>@<lambda_0dd5bdc19d053301b5cd8d3a41e3b3be>@@CAHPBX0@Z
// 地址: 0x10006f41
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

bool c = arg2 u< arg1

if (arg2 == arg1 || c)
    return neg.d(sbb.d(arg2, arg2, c))

return 0xffffffff
