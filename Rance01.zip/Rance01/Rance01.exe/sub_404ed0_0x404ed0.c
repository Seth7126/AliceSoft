// 函数: sub_404ed0
// 地址: 0x404ed0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return (*(arg1 + 0x98) - *(arg1 + 0x94)) s/ 0x1c
