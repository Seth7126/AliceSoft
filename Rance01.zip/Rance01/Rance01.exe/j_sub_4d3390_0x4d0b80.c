// 函数: j_sub_4d3390
// 地址: 0x4d0b80
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_4d3390(arg1) __tailcall
