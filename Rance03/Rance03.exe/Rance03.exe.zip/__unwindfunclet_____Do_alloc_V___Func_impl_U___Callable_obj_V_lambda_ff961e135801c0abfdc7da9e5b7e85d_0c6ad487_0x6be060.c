// 函数: __unwindfunclet$??$_Do_alloc@V?$_Func_impl@U?$_Callable_obj@V<lambda_ff961e135801c0abfdc7da9e5b7e85d2>@@$0A@@std@@V?$allocator@V?$_Func_class@XU_Nil@std@@U12@U12@U12@U12@U12@U12@@std@@@2@XU_Nil@2@U42@U42@U42@U42@U42@U42@@std@@V<lambda_ff961e135801c0abfdc7da9e5b7e85d2>@@V?$allocator@V?$_Func_class@XU_Nil@std@@U12@U12@U12@U12@U12@U12@@std@@@2@@?$_Func_class@XU_Nil@std@@U12@U12@U12@U12@U12@U12@@std@@AAEX$$QAV<lambda_ff961e135801c0abfdc7da9e5b7e85d2>@@V?$allocator@V?$_Func_class@XU_Nil@std@@U12@U12@U12@U12@U12@U12@@std@@@1@@Z$0
// 地址: 0x6be060
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_4 = *(arg1 - 0x14)
int32_t result = *(arg1 - 0x1c)
int32_t result_1 = result
return result
