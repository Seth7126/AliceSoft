// 函数: sub_402560
// 地址: 0x402560
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

void* esi = *data_797d28
int32_t eax_1 = (**arg2)()
data_797d28
return (*(esi + 0xc))(arg1, eax_1)
