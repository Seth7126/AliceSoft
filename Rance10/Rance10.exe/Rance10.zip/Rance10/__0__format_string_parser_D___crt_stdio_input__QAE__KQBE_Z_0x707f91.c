// 函数: ??0?$format_string_parser@D@__crt_stdio_input@@QAE@_KQBE@Z
// 地址: 0x707f91
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t edi
int32_t var_c = edi
*arg1 = arg2
arg1[1] = arg3
arg1[2] = arg4
arg1[3] = 0
__builtin_memset(&arg1[0xb], 0, 0x20)
arg1[4] = 0
arg1[5].w = 0
*(arg1 + 0x16) = 0
arg1[6] = 0
arg1[7] = 0
arg1[8] = 0
arg1[9].b = 0
arg1[0xa] = 0
return arg1
