// 函数: ?__Sleep@platform@details@Concurrency@@YAXK@Z
// 地址: 0x69fab0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return Sleep(arg1)
