// 函数: ?_HasUserException@?$_Task_completion_event_impl@E@details@Concurrency@@QAE_NXZ
// 地址: 0x60bdc0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result
result.b = *(arg1 + 0x34) != 0
return result
