// 函数: sub_100027a9
// 地址: 0x100027a9
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* const temp0 = arg2
arg2 = __return_addr
jump(temp0)
