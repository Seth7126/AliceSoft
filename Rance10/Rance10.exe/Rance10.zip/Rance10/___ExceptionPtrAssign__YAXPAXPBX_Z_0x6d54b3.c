// 函数: ?__ExceptionPtrAssign@@YAXPAXPBX@Z
// 地址: 0x6d54b3
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return std::shared_ptr<class __ExceptionPtr>::operator=(arg1, arg2)
