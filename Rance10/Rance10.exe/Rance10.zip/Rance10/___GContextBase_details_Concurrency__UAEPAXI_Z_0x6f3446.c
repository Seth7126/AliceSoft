// 函数: ??_GContextBase@details@Concurrency@@UAEPAXI@Z
// 地址: 0x6f3446
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

Concurrency::details::ContextBase::~ContextBase(arg1)

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
