// 函数: sub_10006cfe
// 地址: 0x10006cfe
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 1
