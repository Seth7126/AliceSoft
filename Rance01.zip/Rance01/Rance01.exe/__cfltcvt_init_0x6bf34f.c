// 函数: __cfltcvt_init
// 地址: 0x6bf34f
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_78d1b0 = __raise_exc
data_78d1b4 = __mbsnextc
data_78d1b8 = __mbsnbcmp
data_78d1bc = __ismbcl2
data_78d1c0 = sub_6c3586
data_78d1c4 = __raise_exc
data_78d1c8 = __cfltcvt_l
data_78d1cc = sub_6c35a2
data_78d1d0 = sub_6c3504
data_78d1d4 = sub_6c3490
return __raise_exc
