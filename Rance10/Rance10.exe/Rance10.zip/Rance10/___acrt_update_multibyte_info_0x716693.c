// 函数: ___acrt_update_multibyte_info
// 地址: 0x716693
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

void* result = *arg2

if (result != data_7fcacc)
    result = data_7e180c
    
    if ((*(arg1 + 0x350) & result) == 0)
        result = sub_71cd1e()
        *arg2 = result

return result
