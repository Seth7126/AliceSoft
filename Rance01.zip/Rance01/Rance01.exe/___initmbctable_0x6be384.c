// 函数: ___initmbctable
// 地址: 0x6be384
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (data_798220 == 0)
    sub_6be1ea(0xfffffffd)
    data_798220 = 1

return 0
