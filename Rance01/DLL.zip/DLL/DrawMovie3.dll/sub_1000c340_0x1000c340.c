// 函数: sub_1000c340
// 地址: 0x1000c340
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1[0x1e] == 0)
    (*(*arg1 + 0x1c))(0)

int32_t result
result.b = arg1[0x1e] != 0
return result
