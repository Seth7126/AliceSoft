// 函数: sub_1000a464
// 地址: 0x1000a464
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void** var_18

if (data_10022358 != 0)
    var_18 = nullptr
else
    var_18 = &data_10020540

return sub_1000a235(var_18, arg1, arg2, arg3, 0)
