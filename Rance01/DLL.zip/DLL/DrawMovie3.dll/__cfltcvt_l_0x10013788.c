// 函数: __cfltcvt_l
// 地址: 0x10013788
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg4 == 0x65 || arg4 == 0x45)
    return sub_10013079(arg1, arg2, arg3, arg5, arg6.b, arg7)

if (arg4 == 0x66)
    return sub_100135d3(arg1, arg2, arg3, arg5, arg7)

if (arg4 != 0x61 && arg4 != 0x41)
    return sub_1001368e(arg1, arg2, arg3, arg5, arg6.b, arg7)

return sub_10013169(arg1, arg2, arg3, arg5, arg6, arg7)
