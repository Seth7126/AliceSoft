// 函数: ??4?$__crt_unique_heap_ptr@_WU__crt_internal_free_policy@@@@QAEAAV0@$$QAV0@@Z
// 地址: 0x70457c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

__free_base(*arg1)
*arg1 = 0
*arg1 = *arg2
*arg2 = 0
return arg1
