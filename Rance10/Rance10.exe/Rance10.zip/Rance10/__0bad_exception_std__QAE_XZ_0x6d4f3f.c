// 函数: ??0bad_exception@std@@QAE@XZ
// 地址: 0x6d4f3f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
arg1[1] = "bad exception"
*arg1 = &std::bad_exception::`vftable'{for `std::exception'}
return arg1
