// 函数: ??1SchedulingRing@details@Concurrency@@QAE@XZ
// 地址: 0x6fa321
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*(arg1 + 8) = 0
sub_6fa2aa(arg1 + 0x60)
return sub_6fa2aa(arg1 + 0x10) __tailcall
