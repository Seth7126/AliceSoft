// 函数: $LN19
// 地址: 0x10006532
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(**(arg1 + 0x10))
