// 函数: ??$uninitialize_environment_internal@_W@@YAXAAPAPA_W@Z
// 地址: 0x10005c97
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* result = *arg1

if (result != data_10016dbc)
    result = free_environment<char>(result)

return result
