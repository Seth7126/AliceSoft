// 函数: __rtforexpinf
// 地址: 0x1000b121
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 != 0)
    return sub_1000b2e6() __tailcall

return data_10012f80
