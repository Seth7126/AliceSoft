// 函数: ??0task_continuation_context@Concurrency@@AAE@XZ
// 地址: 0x6d55ba
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = 0
arg1[1].b = 0
return arg1
