// 函数: sub_10006e21
// 地址: 0x10006e21
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10003063(data_100221e4)
