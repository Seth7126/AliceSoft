// 函数: $LN24
// 地址: 0x10009add
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __unlock_file(*(arg1 - 0x28))
