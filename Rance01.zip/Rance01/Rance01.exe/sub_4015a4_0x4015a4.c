// 函数: sub_4015a4
// 地址: 0x4015a4
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t* esi = *(arg1 + 8)

if (esi[5] u>= 0x10)
    int32_t var_4_1 = *esi
    sub_6b4d5b()

esi[5] = 0xf
esi[4] = 0
*esi = 0
sub_6b77db(0, nullptr)
noreturn
