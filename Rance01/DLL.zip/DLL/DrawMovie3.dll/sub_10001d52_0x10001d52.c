// 函数: sub_10001d52
// 地址: 0x10001d52
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_10003602() __tailcall
