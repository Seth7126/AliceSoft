// 函数: sub_10006274
// 地址: 0x10006274
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return 1
