// 函数: ??_G?$ctype@D@std@@MAEPAXI@Z
// 地址: 0x6d1254
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &std::ctype<char>::`vftable'{for `std::ctype_base'}
std::ctype<char>::_Tidy(arg1)
*arg1 = &std::_Facet_base::`vftable'

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
