// 函数: ??$evaluate_rational@$08OOO@tools@math@boost@@YAOAAY08$$CBO0ABO@Z
// 地址: 0x6ac624
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __mbsnbicoll_l(arg1, arg2, arg3, nullptr)
