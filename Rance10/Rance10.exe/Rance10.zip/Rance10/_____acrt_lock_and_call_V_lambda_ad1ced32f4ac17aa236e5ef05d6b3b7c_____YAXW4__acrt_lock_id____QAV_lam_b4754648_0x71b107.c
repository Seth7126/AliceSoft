// 函数: ??$__acrt_lock_and_call@V<lambda_ad1ced32f4ac17aa236e5ef05d6b3b7c>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_ad1ced32f4ac17aa236e5ef05d6b3b7c>@@@Z
// 地址: 0x71b107
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_978dc153c237d78434369da87b74ff60>,class <lambda_ad1ced32f4ac17aa236e5ef05d6b3b7c>&,class <lambda_4a8533e2866a575feecb8298ce776b0d>,void>::operator()<class <lambda_978dc153c237d78434369da87b74ff60>,class <lambda_ad1ced32f4ac17aa236e5ef05d6b3b7c>&,class <lambda_4a8533e2866a575feecb8298ce776b0d> >(
    &var_10, arg2)
