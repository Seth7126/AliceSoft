// 函数: ??0VirtualProcessorRoot@details@Concurrency@@QAE@PAVSchedulerProxy@12@PAUSchedulerNode@12@I@Z
// 地址: 0x6fcc4c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::IVirtualProcessorRoot::Concurrency::details::VirtualProcessorRoot::VTable** 
    var_8 = arg1
struct Concurrency::IVirtualProcessorRoot::Concurrency::details::VirtualProcessorRoot::VTable** 
    var_8_1 = arg1
*arg1 =
    &Concurrency::details::VirtualProcessorRoot::`vftable'{for `Concurrency::IVirtualProcessorRoot'}
arg1[1] = 0
sub_6f52dd(&arg1[2], arg2, arg3, arg4)
arg1[0x11].w = 0
arg1[0x13] = 0
int32_t eax = data_7fc35c
data_7fc35c += 1
arg1[0x12] = eax + 1
arg1[9] = arg1
return arg1
