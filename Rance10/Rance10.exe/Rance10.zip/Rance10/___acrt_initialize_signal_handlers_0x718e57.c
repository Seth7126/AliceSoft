// 函数: ___acrt_initialize_signal_handlers
// 地址: 0x718e57
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(0x7fcad4, arg1)
__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(0x7fcad8, arg1)
__crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(&data_7fcadc, arg1)
return __crt_state_management::dual_state_global<struct __crt_locale_data*>::initialize(0x7fcae0, 
    arg1)
