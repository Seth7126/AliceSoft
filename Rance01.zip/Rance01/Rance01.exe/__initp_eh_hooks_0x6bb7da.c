// 函数: __initp_eh_hooks
// 地址: 0x6bb7da
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t result = EncodePointer(terminate)
data_797864 = result
return result
