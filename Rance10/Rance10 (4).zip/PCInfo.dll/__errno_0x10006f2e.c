// 函数: __errno
// 地址: 0x10006f2e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax_2 = ___acrt_getptd_noexit()

if (eax_2 != 0)
    return eax_2 + 0x10

return 0x10016048
