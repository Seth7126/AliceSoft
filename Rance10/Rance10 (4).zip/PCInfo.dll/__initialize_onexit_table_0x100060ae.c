// 函数: __initialize_onexit_table
// 地址: 0x100060ae
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    return 0xffffffff

if (*arg1 == arg1[2])
    int32_t var_c_1 = 0x20
    int32_t __security_cookie_1 = __security_cookie
    *arg1 = __security_cookie_1
    arg1[1] = __security_cookie_1
    arg1[2] = __security_cookie_1

return 0
