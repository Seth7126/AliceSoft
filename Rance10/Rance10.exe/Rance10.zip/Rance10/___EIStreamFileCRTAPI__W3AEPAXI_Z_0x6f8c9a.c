// 函数: ??_EIStreamFileCRTAPI@@W3AEPAXI@Z
// 地址: 0x6f8c9a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return Concurrency::details::InternalContextBase::`scalar deleting destructor'(arg1 - 4) __tailcall
