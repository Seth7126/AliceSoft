// 函数: ??0InternalContextBase@details@Concurrency@@QAE@PAVSchedulerBase@12@@Z
// 地址: 0x6f8b2f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::IExecutionContext::VTable** var_8 = arg1
struct Concurrency::IExecutionContext::VTable** var_8_1 = arg1
*arg1 = &Concurrency::IExecutionContext::`vftable'
sub_6f31fd(&arg1[1], arg2, 0)
*(arg1 + 0xb3) &= 0xfc
*arg1 = &Concurrency::details::InternalContextBase::`vftable'{for `Concurrency::IExecutionContext'}
arg1[1] =
    &Concurrency::details::InternalContextBase::`vftable'{for `Concurrency::details::ContextBase'}
__builtin_memset(&arg1[0x27], 0, 0x15)
*(arg1 + 0xb2) = 0
arg1[0x39] = 0
arg1[7] = 0
arg1[0x3b].b = 1
return arg1
