// 函数: sub_1000252b
// 地址: 0x1000252b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void var_10
std::bad_exception::bad_exception(&var_10)
sub_10004084(&var_10, 0x1001441c)
noreturn
