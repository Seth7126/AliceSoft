// 函数: __endthreadex
// 地址: 0x1000432b
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10004300(arg1)
ExitProcess(arg1)
noreturn
