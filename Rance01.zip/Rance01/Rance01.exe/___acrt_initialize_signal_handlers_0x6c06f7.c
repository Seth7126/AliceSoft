// 函数: ___acrt_initialize_signal_handlers
// 地址: 0x6c06f7
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_797ab0 = arg1
data_797ab4 = arg1
data_797ab8 = arg1
data_797abc = arg1
return arg1
