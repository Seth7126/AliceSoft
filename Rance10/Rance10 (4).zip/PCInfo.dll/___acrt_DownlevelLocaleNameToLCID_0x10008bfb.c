// 函数: ___acrt_DownlevelLocaleNameToLCID
// 地址: 0x10008bfb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 != 0)
    int32_t eax_1 = GetTableIndexFromLocaleName(arg1)
    
    if (eax_1 s>= 0 && eax_1 u< 0xe4)
        return *((eax_1 << 3) + &data_10010da0)

return 0
