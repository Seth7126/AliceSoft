// 函数: sub_10002006
// 地址: 0x10002006
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

char const* const result = *(arg1 + 4)

if (result != 0)
    return result

return "Unknown exception"
