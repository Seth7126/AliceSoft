// 函数: ??$__crt_fast_encode_pointer@PAP6AXXZ@@YAPAP6AXXZQAP6AXXZ@Z
// 地址: 0x10004c29
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ror.d(arg1, 0x20 - ((__security_cookie).b & 0x1f)) ^ __security_cookie
