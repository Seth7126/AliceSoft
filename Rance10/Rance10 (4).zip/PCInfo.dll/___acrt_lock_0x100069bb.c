// 函数: ___acrt_lock
// 地址: 0x100069bb
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return EnterCriticalSection(arg1 * 0x18 + &data_10016dd8)
