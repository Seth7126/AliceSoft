// 函数: ??$__acrt_lowio_lock_fh_and_call@V<lambda_61d677f73751bd412abcbcd096bd0cc8>@@@@YAHH$$QAV<lambda_61d677f73751bd412abcbcd096bd0cc8>@@@Z
// 地址: 0x703747
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_8ccdbc1844700f1d8a5bf6490d3eb6ce>,class <lambda_61d677f73751bd412abcbcd096bd0cc8>&,class <lambda_9cd2faef5ba6c34f9de47eb89f6a8f7d>,int32_t>::operator()<class <lambda_8ccdbc1844700f1d8a5bf6490d3eb6ce>,class <lambda_61d677f73751bd412abcbcd096bd0cc8>&,class <lambda_9cd2faef5ba6c34f9de47eb89f6a8f7d> >(
    &var_10, arg2)
