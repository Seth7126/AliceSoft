// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x6a71c2
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t ecx
return ecx()
