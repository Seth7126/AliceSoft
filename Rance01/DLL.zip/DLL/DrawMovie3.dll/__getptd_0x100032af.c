// 函数: __getptd
// 地址: 0x100032af
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* result = sub_10003236()

if (result == 0)
    sub_100042d7(0x10)

return result
