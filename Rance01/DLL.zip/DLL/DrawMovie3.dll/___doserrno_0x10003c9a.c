// 函数: ___doserrno
// 地址: 0x10003c9a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* eax_2 = sub_10003236()

if (eax_2 != 0)
    return eax_2 + 0xc

return 0x1002029c
