// 函数: __freea_crt
// 地址: 0x6c0acc
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t* result = arg1

if (result != 0)
    result -= 8
    
    if (*result == 0xdddd)
        result = __free_base(result)

return result
