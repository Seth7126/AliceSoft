// 函数: ___free_lconv_mon
// 地址: 0x6aa997
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 == 0)
    return 

int32_t eax_1 = *(arg1 + 0xc)

if (eax_1 != data_74b0c4)
    _free(eax_1)

int32_t eax_2 = *(arg1 + 0x10)

if (eax_2 != data_74b0c8)
    _free(eax_2)

int32_t eax_3 = *(arg1 + 0x14)

if (eax_3 != data_74b0cc)
    _free(eax_3)

int32_t eax_4 = *(arg1 + 0x18)

if (eax_4 != data_74b0d0)
    _free(eax_4)

int32_t eax_5 = *(arg1 + 0x1c)

if (eax_5 != data_74b0d4)
    _free(eax_5)

int32_t eax_6 = *(arg1 + 0x20)

if (eax_6 != data_74b0d8)
    _free(eax_6)

int32_t eax_7 = *(arg1 + 0x24)

if (eax_7 != data_74b0dc)
    _free(eax_7)

int32_t eax_8 = *(arg1 + 0x38)

if (eax_8 != data_74b0f0)
    _free(eax_8)

int32_t eax_9 = *(arg1 + 0x3c)

if (eax_9 != data_74b0f4)
    _free(eax_9)

int32_t eax_10 = *(arg1 + 0x40)

if (eax_10 != data_74b0f8)
    _free(eax_10)

int32_t eax_11 = *(arg1 + 0x44)

if (eax_11 != data_74b0fc)
    _free(eax_11)

int32_t eax_12 = *(arg1 + 0x48)

if (eax_12 != data_74b100)
    _free(eax_12)

int32_t eax = *(arg1 + 0x4c)

if (eax != data_74b104)
    _free(eax)
