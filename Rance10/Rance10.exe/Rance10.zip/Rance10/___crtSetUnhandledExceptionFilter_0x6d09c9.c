// 函数: ___crtSetUnhandledExceptionFilter
// 地址: 0x6d09c9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return ReleaseSRWLockExclusive(arg1)
