// 函数: ??0EnumC13Lines@@QAE@XZ
// 地址: 0x47b310
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

*arg1 = 0x3f800000
arg1[1] = 0
arg1[2] = 0
arg1[3] = 0
arg1[4] = 0
arg1[5] = 0x3f800000
arg1[6] = 0
arg1[7] = 0
arg1[8] = 0
arg1[9] = 0
arg1[0xa] = 0x3f800000
arg1[0xb] = 0
arg1[0xc] = 0
arg1[0xd] = 0
arg1[0xe] = 0
arg1[0xf] = 0x3f800000
return arg1
