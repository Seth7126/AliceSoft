// 函数: ___acrt_initialize_signal_handlers
// 地址: 0x10006dcc
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_100221dc = arg1
data_100221e0 = arg1
data_100221e4 = arg1
data_100221e8 = arg1
return arg1
