// 函数: __checkTOS_withFB
// 地址: 0x1000b468
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax = arg1 & 0x7ff00000

if (eax == 0x7ff00000)
    return arg1

return eax
