// 函数: sub_4015f0
// 地址: 0x4015f0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f77c, 0x6da2a7, nullptr)
return _atexit(sub_6d2560)
