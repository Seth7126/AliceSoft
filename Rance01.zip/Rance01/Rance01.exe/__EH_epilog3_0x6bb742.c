// 函数: __EH_epilog3
// 地址: 0x6bb742
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1[-3]
*arg1
*arg1 = __return_addr
