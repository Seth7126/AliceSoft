// 函数: sub_1000a50c
// 地址: 0x1000a50c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t ebp
int32_t var_4 = ebp
int32_t result = RtlUnwind(arg1, 0x1000a524, nullptr, nullptr)
var_4
return result
