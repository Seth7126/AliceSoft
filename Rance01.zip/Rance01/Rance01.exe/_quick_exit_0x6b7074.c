// 函数: _quick_exit
// 地址: 0x6b7074
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b6f1e(exit_code, 1, 0)
