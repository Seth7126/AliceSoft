// 函数: ??0?$input_processor@DV?$string_input_adapter@D@__crt_stdio_input@@@__crt_stdio_input@@QAE@ABV?$string_input_adapter@D@1@_KQBDQAU__crt_locale_pointers@@QAD@Z
// 地址: 0x70800c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t edi
int32_t var_10 = edi
*arg1 = arg3
arg1[1] = arg4
arg1[2] = *arg2
void* edi_2 = &arg1[3]
void* esi_1 = arg2 + 4
*edi_2 = *esi_1
*(edi_2 + 4) = *(esi_1 + 4)
__crt_stdio_input::format_string_parser<char>::format_string_parser<char>(&arg1[6], arg3, arg4, 
    arg5)
arg1[0x1c] = 0
arg1[0x1d] = 0
arg1[0x1a] = arg6
arg1[0x1b] = arg7
return arg1
