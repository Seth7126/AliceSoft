// 函数: sub_10004e15
// 地址: 0x10004e15
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax = try_get_function(7, "FlsSetValue", 0x1000f340, "FlsSetValue")

if (eax == 0)
    return TlsSetValue(arg1, arg2)

j_sub_10004a52()
return eax(arg1, arg2)
