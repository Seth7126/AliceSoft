// 函数: j_sub_65eb20
// 地址: 0x728eb0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_65eb20() __tailcall
