// 函数: __heap_init
// 地址: 0x6bdca0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

HANDLE eax = HeapCreate(HEAP_NONE, 0x1000, 0)
int32_t result
result.b = eax != 0
data_797930 = eax
return result
