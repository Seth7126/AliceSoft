// 函数: sub_100060d4
// 地址: 0x100060d4
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax_2 = **arg1

if (eax_2 == 0xe0434f4d)
    if (*(__getptd() + 0x90) s> 0)
        void* eax_6 = __getptd() + 0x90
        *eax_6 -= 1
else if (eax_2 == 0xe06d7363)
    *(__getptd() + 0x90) = 0
    noreturn terminate() __tailcall

return 0
