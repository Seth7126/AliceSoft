// 函数: ??_G?$shared_ptr@$$CBU_EXCEPTION_RECORD@@@std@@QAEPAXI@Z
// 地址: 0x6d509d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t* ecx = *(arg1 + 4)

if (ecx != 0)
    sub_563db0(ecx)

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
