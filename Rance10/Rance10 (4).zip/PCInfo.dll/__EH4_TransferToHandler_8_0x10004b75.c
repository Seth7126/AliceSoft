// 函数: @_EH4_TransferToHandler@8
// 地址: 0x10004b75
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

__NLG_Notify(arg1, arg2, 1)
jump(arg1)
