// 函数: sub_10003658
// 地址: 0x10003658
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return __unlock(4)
