// 函数: CreateInterface
// 地址: 0x10016780
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax = sub_10001000(arg1, 0x1001c3dc)
int32_t eax_1 = neg.d(eax)
return sbb.d(eax_1, eax_1, eax != 0) & &data_10021498
