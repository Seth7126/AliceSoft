// 函数: __raise_exc
// 地址: 0x6c3f3a
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return __cfltcvt_l(arg1, arg2, arg3, arg4, arg5, arg6, nullptr)
