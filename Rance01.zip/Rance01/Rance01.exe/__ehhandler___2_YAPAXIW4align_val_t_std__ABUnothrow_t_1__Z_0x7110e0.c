// 函数: __ehhandler$??2@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x7110e0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b4885(*(arg1 - 0x14) ^ (arg1 + 0xc))
return sub_6bb3b5(0x771c70) __tailcall
