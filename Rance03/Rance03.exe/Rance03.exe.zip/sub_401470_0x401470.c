// 函数: sub_401470
// 地址: 0x401470
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f65c, 0x6da246, nullptr)
return _atexit(sub_6d20e0)
