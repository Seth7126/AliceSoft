// 函数: ??$?RV<lambda_8ccdbc1844700f1d8a5bf6490d3eb6ce>@@AAV<lambda_61d677f73751bd412abcbcd096bd0cc8>@@V<lambda_9cd2faef5ba6c34f9de47eb89f6a8f7d>@@@?$__crt_seh_guarded_call@H@@QAEH$$QAV<lambda_8ccdbc1844700f1d8a5bf6490d3eb6ce>@@AAV<lambda_61d677f73751bd412abcbcd096bd0cc8>@@$$QAV<lambda_9cd2faef5ba6c34f9de47eb89f6a8f7d>@@@Z
// 地址: 0x7036f6
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t __saved_ebp_1 = 0xc
int32_t var_8 = 0x7de370
int32_t (* var_10)(int32_t* arg1, void* arg2, int32_t arg3) = __except_handler4
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
uint32_t __security_cookie_1 = __security_cookie
int32_t var_8_3 = 0x7de370 ^ __security_cookie_1
int32_t __saved_ebp
int32_t var_30 = __security_cookie_1 ^ &__saved_ebp
int32_t* var_1c = &var_30
void* const var_34_1 = &data_703702
int32_t var_8_4 = 0xfffffffe
int32_t var_c = var_8_3
fsbase->NtTib.ExceptionList = &ExceptionList
int32_t var_20 = 0
__lock_file(*arg1)
int32_t var_8_1 = 0
int32_t result = sub_70376f(arg2)
int32_t result_1 = result
int32_t var_8_2 = 0xfffffffe
$LN7(&__saved_ebp)
fsbase->NtTib.ExceptionList = ExceptionList
void* const __saved_ebp_2 = &data_703735
return result
