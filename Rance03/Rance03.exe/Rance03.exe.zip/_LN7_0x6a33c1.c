// 函数: $LN7
// 地址: 0x6a33c1
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __unlock(6)
