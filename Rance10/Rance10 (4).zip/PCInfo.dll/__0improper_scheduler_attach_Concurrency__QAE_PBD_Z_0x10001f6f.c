// 函数: ??0improper_scheduler_attach@Concurrency@@QAE@PBD@Z
// 地址: 0x10001f6f
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

struct std::exception::std::logic_error::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::logic_error::`vftable'{for `std::exception'}
return result
