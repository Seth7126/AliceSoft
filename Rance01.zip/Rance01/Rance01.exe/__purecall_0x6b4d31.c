// 函数: __purecall
// 地址: 0x6b4d31
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eax = DecodePointer(data_797848)

if (eax != 0)
    eax()

sub_6b7b48(0x19)
sub_6b7b01(0, 1)
noreturn sub_6b7ace() __tailcall
