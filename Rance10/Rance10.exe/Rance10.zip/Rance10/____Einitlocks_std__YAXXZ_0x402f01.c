// 函数: ??__Einitlocks@std@@YAXXZ
// 地址: 0x402f01
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

std::_Init_locks::_Init_locks(0x7fbe4c)
return _atexit(std::initlocks::)
