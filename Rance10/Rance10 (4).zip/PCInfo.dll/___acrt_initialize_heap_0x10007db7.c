// 函数: ___acrt_initialize_heap
// 地址: 0x10007db7
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

HANDLE result = GetProcessHeap()
data_10017024 = result
result.b = result != 0
return result
