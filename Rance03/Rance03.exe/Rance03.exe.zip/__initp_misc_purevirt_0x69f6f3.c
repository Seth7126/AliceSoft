// 函数: __initp_misc_purevirt
// 地址: 0x69f6f3
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

data_75c970 = arg1
return arg1
