// 函数: __mbsnicoll
// 地址: 0x6c4f09
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c4e2b(arg1, arg2, arg3, nullptr)
