// 函数: sub_10005d19
// 地址: 0x10005d19
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t edi
int32_t var_8 = edi
return &data_1001e2b4
