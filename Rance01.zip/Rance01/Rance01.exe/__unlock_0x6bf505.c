// 函数: __unlock
// 地址: 0x6bf505
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return LeaveCriticalSection(*((arg1 << 3) + &data_78d008))
