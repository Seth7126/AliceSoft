// 函数: sub_1000c4b0
// 地址: 0x1000c4b0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if ((*(*arg2 + 0x14))(arg2, arg3, arg4) s>= 0)
    int32_t edx_1 = arg4[1]
    int32_t temp1_1 = arg3[1]
    
    if (edx_1 s<= temp1_1 && (edx_1 s< temp1_1 || *arg4 u< *arg3))
        return 0x80040228
    
    if (arg1[6] != 0)
        return (*(*arg1 + 0x5c))(arg2, arg3, arg4)

return 0
