// 函数: __endthreadex
// 地址: 0x6b6e06
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

sub_6b6ddb(arg1)
ExitProcess(arg1)
noreturn
