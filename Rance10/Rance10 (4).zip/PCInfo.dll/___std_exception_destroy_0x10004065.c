// 函数: ___std_exception_destroy
// 地址: 0x10004065
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1[1].b != 0)
    _free(*arg1)

*arg1 = 0
arg1[1].b = 0
