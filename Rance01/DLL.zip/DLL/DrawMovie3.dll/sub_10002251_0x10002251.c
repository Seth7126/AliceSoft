// 函数: sub_10002251
// 地址: 0x10002251
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* eax = __calloc_crt(0x20, 4)
int32_t eax_1 = sub_10002fe8(eax)
data_10023648 = eax_1
data_10023644 = eax_1

if (eax == 0)
    return 0x18

*eax = 0
return 0
