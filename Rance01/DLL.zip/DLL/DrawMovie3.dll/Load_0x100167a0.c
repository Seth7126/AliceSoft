// 函数: Load
// 地址: 0x100167a0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int128_t* eax_1 = (**arg1)()
char* ecx_1 = eax_1
int32_t var_4 = 0xf
int32_t var_8 = 0
char var_18 = 0
char i

do
    i = *ecx_1
    ecx_1 = &ecx_1[1]
while (i != 0)
void var_1c
sub_10001ae0(&var_1c, eax_1, ecx_1 - &ecx_1[1])
char result = sub_10016400(&var_1c)

if (var_4 u>= 0x10)
    int32_t __saved_edi_1 = var_18.d
    sub_10001d52()

return result
