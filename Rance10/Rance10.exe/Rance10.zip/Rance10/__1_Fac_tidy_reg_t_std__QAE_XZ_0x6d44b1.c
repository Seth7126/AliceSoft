// 函数: ??1_Fac_tidy_reg_t@std@@QAE@XZ
// 地址: 0x6d44b1
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

while (true)
    int32_t* esi_1 = data_7fbad0
    
    if (esi_1 == 0)
        break
    
    data_7fbad0 = *esi_1
    std::_Fac_node::~_Fac_node(esi_1)
    operator new(esi_1)
