// 函数: __twoToTOS
// 地址: 0x100173a0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

long double result = roundint.t(arg1)
__fscale(__f2xm1(fneg(result - arg1)) + float.t(1), result)
return result
