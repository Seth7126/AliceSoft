// 函数: sub_401610
// 地址: 0x401610
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f764, 0x6da2c3, nullptr)
return _atexit(sub_6d25c0)
