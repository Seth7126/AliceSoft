// 函数: ?what@exception@std@@UBEPBDXZ
// 地址: 0x69e56c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

char const* const result = *(arg1 + 4)

if (result != 0)
    return result

return "Unknown exception"
