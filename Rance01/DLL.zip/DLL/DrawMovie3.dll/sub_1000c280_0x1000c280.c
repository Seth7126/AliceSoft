// 函数: sub_1000c280
// 地址: 0x1000c280
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg3 == 0)
    return 0x80004003

if (sub_10011060(*(arg1 + 0x50), arg2, nullptr, 0, nullptr) != WAIT_TIMEOUT)
    *arg3 = *(arg1 + 8)
    return 0

*arg3 = *(arg1 + 8)
return 0x40237
