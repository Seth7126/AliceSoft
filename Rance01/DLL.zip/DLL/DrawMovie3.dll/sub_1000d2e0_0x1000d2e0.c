// 函数: sub_1000d2e0
// 地址: 0x1000d2e0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg2 s>= 0x3e8)
    *(arg1 + 0xc) = 0
    return 0

*(arg1 + 0xc) = divs.dp.d(0x172dd680, arg2 + 0xa7) - 0x50910
return 0
