// 函数: sub_10001240
// 地址: 0x10001240
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10016a30(arg1)

if ((arg2 & 1) != 0)
    struct CBaseVideoRenderer::CSurfaceRenderer::VTable** var_8_1 = arg1
    sub_10001d52()

return arg1
