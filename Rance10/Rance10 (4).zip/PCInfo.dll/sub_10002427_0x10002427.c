// 函数: sub_10002427
// 地址: 0x10002427
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* ecx = *(arg1 - 0x14)
return ___scrt_dllmain_exception_filter(*(arg1 + 8), *(arg1 + 0xc), *(arg1 + 0x10), 
    dllmain_crt_dispatch, **ecx, ecx)
