// 函数: ??0?$output_adapter_data@_WV?$stream_output_adapter@_W@__crt_stdio_output@@@__crt_stdio_output@@IAE@ABV?$stream_output_adapter@_W@1@_KQB_WQAU__crt_locale_pointers@@QAD@Z
// 地址: 0x70446e
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

__crt_stdio_output::common_data<char>::common_data<char>(arg1)
arg1[0x112] = *arg2
*arg1 = arg3
arg1[1] = arg4
arg1[2] = arg6
arg1[4] = arg5
arg1[5] = arg7
return arg1
