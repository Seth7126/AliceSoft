// 函数: ??0operation_timed_out@Concurrency@@QAE@ABV01@@Z
// 地址: 0x6eb8b3
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::unsupported_os::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &Concurrency::unsupported_os::`vftable'{for `std::exception'}
return result
