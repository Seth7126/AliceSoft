// 函数: _start
// 地址: 0x10002671
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

uint32_t eax

if (arg2 == 1)
    eax = sub_10005f8f()

return sub_1000257b(eax, arg2, arg3, arg1)
