// 函数: __swprintf_c
// 地址: 0x69b3ad
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

void arg_10
return __vsprintf_s_l(arg1, arg2, arg3, 0, &arg_10)
