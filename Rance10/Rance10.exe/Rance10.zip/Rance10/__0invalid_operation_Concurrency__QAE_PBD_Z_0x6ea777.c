// 函数: ??0invalid_operation@Concurrency@@QAE@PBD@Z
// 地址: 0x6ea777
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::Concurrency::improper_lock::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &Concurrency::improper_lock::`vftable'{for `std::exception'}
return result
