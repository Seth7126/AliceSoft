// 函数: $LN17
// 地址: 0x69d23f
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (*(arg1 + 0x10) != 0)
    __unlock(8)
