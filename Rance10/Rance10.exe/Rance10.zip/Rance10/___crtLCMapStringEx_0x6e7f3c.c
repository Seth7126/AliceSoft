// 函数: ___crtLCMapStringEx
// 地址: 0x6e7f3c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbeec ^ __security_cookie

if (esi_1 == 0)
    return LCMapStringW(___crtDownlevelLocaleNameToLCID(arg1), arg2, arg3, arg4, arg5, arg6)

j_sub_4033e0()
return esi_1(arg1, arg2, arg3, arg4, arg5, arg6, 0, 0, 0)
