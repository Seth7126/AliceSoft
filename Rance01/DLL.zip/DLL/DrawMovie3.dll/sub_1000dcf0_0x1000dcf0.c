// 函数: sub_1000dcf0
// 地址: 0x1000dcf0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 4
return sub_1000c030() __tailcall
