// 函数: __CIasin_default
// 地址: 0x70d110
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int16_t x87control
return sub_70d12d(x87control, arg1)
