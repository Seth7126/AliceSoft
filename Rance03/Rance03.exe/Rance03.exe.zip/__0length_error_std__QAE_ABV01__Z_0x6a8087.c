// 函数: ??0length_error@std@@QAE@ABV01@@Z
// 地址: 0x6a8087
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

struct std::exception::std::bad_exception::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::bad_exception::`vftable'{for `std::exception'}
return result
