// 函数: __free_base
// 地址: 0x6b5c09
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 != 0 && HeapFree(data_797930, HEAP_NONE, arg1) == 0)
    BOOL* esi_1 = __errno()
    *esi_1 = sub_6b5d5e(GetLastError())
