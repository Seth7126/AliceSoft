// 函数: _tolower
// 地址: 0x6abe6e
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (data_75d30c != 0)
    return __tolower_l(arg1, nullptr)

if (arg1 - 0x41 u> 0x19)
    return arg1

return arg1 + 0x20
