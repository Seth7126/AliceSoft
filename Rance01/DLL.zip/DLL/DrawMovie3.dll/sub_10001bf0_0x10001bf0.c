// 函数: sub_10001bf0
// 地址: 0x10001bf0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 0xd8
return sub_1000c010() __tailcall
