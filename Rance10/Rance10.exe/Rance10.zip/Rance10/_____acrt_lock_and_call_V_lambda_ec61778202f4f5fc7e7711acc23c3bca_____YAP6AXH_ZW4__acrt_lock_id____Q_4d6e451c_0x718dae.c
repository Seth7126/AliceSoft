// 函数: ??$__acrt_lock_and_call@V<lambda_ec61778202f4f5fc7e7711acc23c3bca>@@@@YAP6AXH@ZW4__acrt_lock_id@@$$QAV<lambda_ec61778202f4f5fc7e7711acc23c3bca>@@@Z
// 地址: 0x718dae
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
int32_t var_18 = arg2
return __crt_seh_guarded_call<class <lambda_a048d3beccc847880fc8490e18b82769>,class <lambda_ec61778202f4f5fc7e7711acc23c3bca>&,class <lambda_f7496a158712204296dd6628a163878e>,void (__cdecl*)(int32_t)>::operator()<class <lambda_a048d3beccc847880fc8490e18b82769>,class <lambda_ec61778202f4f5fc7e7711acc23c3bca>&,class <lambda_f7496a158712204296dd6628a163878e> >(
    &var_10)
