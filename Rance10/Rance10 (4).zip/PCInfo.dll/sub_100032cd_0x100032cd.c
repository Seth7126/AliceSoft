// 函数: sub_100032cd
// 地址: 0x100032cd
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

sub_1000624c()
noreturn
