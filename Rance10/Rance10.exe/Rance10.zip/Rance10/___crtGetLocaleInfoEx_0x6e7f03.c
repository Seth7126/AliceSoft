// 函数: ___crtGetLocaleInfoEx
// 地址: 0x6e7f03
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbee8 ^ __security_cookie

if (esi_1 == 0)
    return GetLocaleInfoW(___crtDownlevelLocaleNameToLCID(arg1), arg2, arg3, arg4)

j_sub_4033e0()
return esi_1(arg1, arg2, arg3, arg4)
