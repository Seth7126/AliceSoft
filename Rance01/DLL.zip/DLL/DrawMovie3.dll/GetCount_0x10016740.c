// 函数: GetCount
// 地址: 0x10016740
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* result = data_100214b4

if (result != 0)
    return *(result + 0x184)

return result
