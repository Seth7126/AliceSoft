// 函数: __callnewh
// 地址: 0x6b7e47
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eax = DecodePointer(data_797854)

if (eax != 0 && eax(arg1) != 0)
    return 1

return 0
