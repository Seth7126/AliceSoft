// 函数: j_sub_5d1590
// 地址: 0x5d1800
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5d1590() __tailcall
