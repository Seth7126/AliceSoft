// 函数: sub_100010e0
// 地址: 0x100010e0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::exception::std::bad_alloc::VTable** result = arg1
*result = &std::bad_alloc::`vftable'{for `std::exception'}
sub_10001f69(arg1)

if ((arg2 & 1) != 0)
    struct std::exception::std::bad_alloc::VTable** result_1 = result
    sub_10001d52()

return result
