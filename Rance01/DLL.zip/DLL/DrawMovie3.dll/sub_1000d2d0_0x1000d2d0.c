// 函数: sub_1000d2d0
// 地址: 0x1000d2d0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*(arg1 - 0x38) = arg2
return 0
