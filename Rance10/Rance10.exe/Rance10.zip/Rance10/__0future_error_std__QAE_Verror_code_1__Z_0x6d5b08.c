// 函数: ??0future_error@std@@QAE@Verror_code@1@@Z
// 地址: 0x6d5b08
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::VTable** var_8 = arg1
struct std::logic_error::std::future_error::VTable** result = arg1
struct std::logic_error::std::future_error::VTable** result_1 = result
sub_62be70(arg1, &data_794c78)
result[3] = arg2
result[4] = arg3
*result = &std::future_error::`vftable'{for `std::logic_error'}
return result
