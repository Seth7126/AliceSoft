// 函数: __flushall
// 地址: 0x69c759
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return _flsall(1)
