// 函数: sub_401010
// 地址: 0x401010
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

struct std::exception::std::bad_alloc::VTable** result = arg1
*result = &std::bad_alloc::`vftable'{for `std::exception'}
sub_6b4978(arg1)

if ((arg2 & 1) != 0)
    struct std::exception::std::bad_alloc::VTable** result_1 = result
    sub_6b4d5b()

return result
