// 函数: __unwindfunclet$??0?$call@IV?$function@$$A6AXABI@Z@std@@@Concurrency@@QAE@ABV?$function@$$A6AXABI@Z@std@@@Z$1
// 地址: 0x6c265c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_503ee0(*(arg1 - 0x10) + 0xf8) __tailcall
