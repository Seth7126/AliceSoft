// 函数: $LN12
// 地址: 0x69c6a7
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return __unlock_file(arg1)
