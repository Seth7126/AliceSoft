// 函数: sub_1000604e
// 地址: 0x1000604e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

struct std::exception::std::bad_exception::VTable** result = arg1
*result = &std::bad_exception::`vftable'{for `std::exception'}
sub_10001f69(arg1)

if ((arg2 & 1) != 0)
    struct std::exception::std::bad_exception::VTable** result_1 = result
    sub_10001d52()

return result
