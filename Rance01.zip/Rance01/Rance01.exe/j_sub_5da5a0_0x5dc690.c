// 函数: j_sub_5da5a0
// 地址: 0x5dc690
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_5da5a0() __tailcall
