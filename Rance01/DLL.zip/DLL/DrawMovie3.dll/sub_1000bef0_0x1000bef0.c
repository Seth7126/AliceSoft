// 函数: sub_1000bef0
// 地址: 0x1000bef0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return LeaveCriticalSection(*arg1)
