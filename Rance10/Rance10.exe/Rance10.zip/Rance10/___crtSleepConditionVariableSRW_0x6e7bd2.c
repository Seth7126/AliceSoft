// 函数: ___crtSleepConditionVariableSRW
// 地址: 0x6e7bd2
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbed4 ^ __security_cookie
j_sub_4033e0()
return esi_1(arg1, arg2, arg3, arg4)
