// 函数: sub_10007f11
// 地址: 0x10007f11
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void* result = data_1002350c
void* ecx_2 = data_10023508 * 0x14 + result

while (true)
    if (result u>= ecx_2)
        return nullptr
    
    if (arg1 - *(result + 0xc) u< 0x100000)
        break
    
    result += 0x14

return result
