// 函数: sub_4025f0
// 地址: 0x4025f0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

void* edi = *(*(*data_797d28 + 0x10))(arg1)
return (*(edi + 0x18))((**arg2)())
