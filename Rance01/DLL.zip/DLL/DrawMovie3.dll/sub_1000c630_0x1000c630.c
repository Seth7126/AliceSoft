// 函数: sub_1000c630
// 地址: 0x1000c630
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

EnterCriticalSection(arg1 + 0x94)
int32_t result
result.b = *(arg1 + 0x6c) != 0
LeaveCriticalSection(arg1 + 0x94)
return result
