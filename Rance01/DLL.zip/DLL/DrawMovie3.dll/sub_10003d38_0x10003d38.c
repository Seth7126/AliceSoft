// 函数: sub_10003d38
// 地址: 0x10003d38
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_10023654 = 0
