// 函数: ?DeleteMod@DBI1@@UAEHPBD@Z
// 地址: 0x49c5e0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return 1
