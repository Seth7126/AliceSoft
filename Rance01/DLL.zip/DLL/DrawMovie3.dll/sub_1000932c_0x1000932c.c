// 函数: sub_1000932c
// 地址: 0x1000932c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t eax_1 = ***(arg1 - 0x14)
*(arg1 - 0x20) = eax_1
int32_t result
result.b = eax_1 == 0xc0000017
return result
