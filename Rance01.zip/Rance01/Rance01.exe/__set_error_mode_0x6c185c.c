// 函数: __set_error_mode
// 地址: 0x6c185c
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 s>= 0)
    if (arg1 s<= 2)
        int32_t result = data_796ef4
        data_796ef4 = arg1
        return result
    
    if (arg1 == 3)
        return data_796ef4

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
