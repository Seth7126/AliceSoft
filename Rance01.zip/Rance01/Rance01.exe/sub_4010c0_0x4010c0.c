// 函数: sub_4010c0
// 地址: 0x4010c0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

char* result = arg1
*(result + 0x14) = 0xf
*(result + 0x10) = 0
*result = 0
sub_401180(arg1, 0xffffffff, arg2, 0)
return result
