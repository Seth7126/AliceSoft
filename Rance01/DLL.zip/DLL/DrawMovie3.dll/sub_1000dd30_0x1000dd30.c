// 函数: sub_1000dd30
// 地址: 0x1000dd30
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 0x8c
return sub_100010b0() __tailcall
