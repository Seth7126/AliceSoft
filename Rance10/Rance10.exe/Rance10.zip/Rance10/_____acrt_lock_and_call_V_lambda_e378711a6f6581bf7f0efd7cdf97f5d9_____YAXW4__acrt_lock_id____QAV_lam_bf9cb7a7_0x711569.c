// 函数: ??$__acrt_lock_and_call@V<lambda_e378711a6f6581bf7f0efd7cdf97f5d9>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_e378711a6f6581bf7f0efd7cdf97f5d9>@@@Z
// 地址: 0x711569
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_c76fdea48760d5f9368b465f31df4405>,class <lambda_e378711a6f6581bf7f0efd7cdf97f5d9>&,class <lambda_e927a58b2a85c081d733e8c6192ae2d2>,void>::operator()<class <lambda_c76fdea48760d5f9368b465f31df4405>,class <lambda_e378711a6f6581bf7f0efd7cdf97f5d9>&,class <lambda_e927a58b2a85c081d733e8c6192ae2d2> >(
    &var_10, arg2)
