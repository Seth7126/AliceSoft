// 函数: ?__CreateTimerQueueTimer@platform@details@Concurrency@@YAHPAPAXPAXP6GX1E@Z1KKK@Z
// 地址: 0x6eaf96
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return CreateTimerQueueTimer(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
