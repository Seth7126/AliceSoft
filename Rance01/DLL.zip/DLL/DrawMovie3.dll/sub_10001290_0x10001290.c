// 函数: sub_10001290
// 地址: 0x10001290
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t var_4 = *arg1
return sub_10001d52()
