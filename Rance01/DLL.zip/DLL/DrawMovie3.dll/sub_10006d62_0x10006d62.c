// 函数: sub_10006d62
// 地址: 0x10006d62
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = sub_10002fe8(terminate)
data_100221d8 = result
return result
