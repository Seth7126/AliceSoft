// 函数: ??$?9UIRestrictedErrorInfo@@@WRL@Microsoft@@YA_NABV?$ComPtr@UIRestrictedErrorInfo@@@01@$$T@Z
// 地址: 0x6d5571
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t* result
result.b = *arg1 != 0
return result
