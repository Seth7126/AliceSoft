// 函数: ?__construct_from_string_literal@bad_typeid@std@@SA?AV12@QBD@Z
// 地址: 0x702e0a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
arg1[1] = arg2
*arg1 = &std::bad_cast::`vftable'{for `std::exception'}
return arg1
