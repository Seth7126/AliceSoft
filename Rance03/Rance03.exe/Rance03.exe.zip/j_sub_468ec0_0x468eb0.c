// 函数: j_sub_468ec0
// 地址: 0x468eb0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_468ec0(arg1, arg2) __tailcall
