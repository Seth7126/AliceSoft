// 函数: ??1type_info@@UAE@XZ
// 地址: 0x69ad7b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

*arg1 = &type_info::`vftable'
return type_info::_Type_info_dtor(arg1)
