// 函数: sub_402800
// 地址: 0x402800
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*(arg1 + 4) -= 1
int32_t result = *(arg1 + 4)

if (result s> 0)
    return result

sub_4026e0(arg1, arg1)
void* var_8_2 = arg1
sub_6b4d5b()
return 0
