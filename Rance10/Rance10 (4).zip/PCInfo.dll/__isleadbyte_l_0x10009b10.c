// 函数: __isleadbyte_l
// 地址: 0x10009b10
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void* var_14
_LocaleUpdate::_LocaleUpdate(&var_14, arg2)
int32_t* var_10
int32_t result = zx.d(*(*var_10 + (zx.d(arg1) << 1))) & 0x8000
char var_8

if (var_8 != 0)
    void* ecx_2 = var_14
    *(ecx_2 + 0x350) &= 0xfffffffd

return result
