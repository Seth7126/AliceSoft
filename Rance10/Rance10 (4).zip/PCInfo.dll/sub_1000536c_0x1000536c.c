// 函数: sub_1000536c
// 地址: 0x1000536c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return __malloc_base() __tailcall
