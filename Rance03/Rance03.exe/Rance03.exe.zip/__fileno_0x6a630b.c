// 函数: __fileno
// 地址: 0x6a630b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 != 0)
    return *(arg1 + 0x10)

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
