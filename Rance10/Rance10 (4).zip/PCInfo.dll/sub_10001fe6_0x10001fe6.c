// 函数: sub_10001fe6
// 地址: 0x10001fe6
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

void var_10
std::overflow_error::overflow_error(&var_10, arg1)
sub_10004084(&var_10, 0x10014384)
noreturn
