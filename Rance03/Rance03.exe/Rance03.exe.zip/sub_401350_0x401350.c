// 函数: sub_401350
// 地址: 0x401350
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f56c, 0x6da0d1, nullptr)
return _atexit(sub_6d1d30)
