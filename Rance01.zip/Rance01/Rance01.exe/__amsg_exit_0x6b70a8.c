// 函数: __amsg_exit
// 地址: 0x6b70a8
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

__FF_MSGBANNER()
sub_6b7b48(arg1)
_quick_exit(0xff)
noreturn
