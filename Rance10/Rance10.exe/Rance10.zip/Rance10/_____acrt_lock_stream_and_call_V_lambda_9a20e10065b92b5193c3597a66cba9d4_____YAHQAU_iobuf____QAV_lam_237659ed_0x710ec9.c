// 函数: ??$__acrt_lock_stream_and_call@V<lambda_9a20e10065b92b5193c3597a66cba9d4>@@@@YAHQAU_iobuf@@$$QAV<lambda_9a20e10065b92b5193c3597a66cba9d4>@@@Z
// 地址: 0x710ec9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_800076c951b434888f4765a74a194fcc>,class <lambda_4e60a939b0d047cfe11ddc22648dfba9>&,class <lambda_6dbb1268764f43b569ce7b67e331d33a>,int32_t>::operator()<class <lambda_800076c951b434888f4765a74a194fcc>,class <lambda_4e60a939b0d047cfe11ddc22648dfba9>&,class <lambda_6dbb1268764f43b569ce7b67e331d33a> >(
    &var_10, arg2)
