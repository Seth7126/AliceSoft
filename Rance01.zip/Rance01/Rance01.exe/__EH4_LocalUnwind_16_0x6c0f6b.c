// 函数: @_EH4_LocalUnwind@16
// 地址: 0x6c0f6b
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return __local_unwind4(arg4, arg1, arg2)
