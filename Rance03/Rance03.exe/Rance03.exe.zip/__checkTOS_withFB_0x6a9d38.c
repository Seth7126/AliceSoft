// 函数: __checkTOS_withFB
// 地址: 0x6a9d38
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax = arg1 & 0x7ff00000

if (eax == 0x7ff00000)
    return arg1

return eax
