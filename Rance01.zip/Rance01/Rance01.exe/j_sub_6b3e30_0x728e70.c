// 函数: j_sub_6b3e30
// 地址: 0x728e70
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6b3e30() __tailcall
