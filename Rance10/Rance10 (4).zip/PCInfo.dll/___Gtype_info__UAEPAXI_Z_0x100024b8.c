// 函数: ??_Gtype_info@@UAEPAXI@Z
// 地址: 0x100024b8
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

*arg1 = &type_info::`vftable'

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
