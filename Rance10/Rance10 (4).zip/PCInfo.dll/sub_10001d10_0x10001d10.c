// 函数: sub_10001d10
// 地址: 0x10001d10
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_4 = 0
char* var_8 = arg3

if (arg4[4] u<= arg2[5] - arg2[4] || arg4[5] - arg4[4] u< arg2[4])
    sub_10001380(arg3, sub_100017c0(arg2, arg4, 0, 0xffffffff))
    return arg3

int32_t* var_18 = arg2
sub_10001380(arg3, sub_10001d70(arg4, arg4))
return arg3
