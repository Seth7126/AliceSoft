// 函数: j_sub_40ae30
// 地址: 0x408380
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_40ae30(arg1) __tailcall
