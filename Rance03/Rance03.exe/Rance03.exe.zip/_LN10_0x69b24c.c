// 函数: $LN10
// 地址: 0x69b24c
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t entry_ebx

if (arg1 == 0)
    __ArrayUnwind(arg3, entry_ebx, arg4, *(arg2 + 0x14))
