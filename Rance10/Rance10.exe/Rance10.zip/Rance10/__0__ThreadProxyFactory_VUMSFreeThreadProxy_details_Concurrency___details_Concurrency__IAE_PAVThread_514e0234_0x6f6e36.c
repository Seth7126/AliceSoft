// 函数: ??0?$ThreadProxyFactory@VUMSFreeThreadProxy@details@Concurrency@@@details@Concurrency@@IAE@PAVThreadProxyFactoryManager@12@@Z
// 地址: 0x6f6e36
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct Concurrency::details::IThreadProxyFactory::Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>::VTable
    ** var_8 = arg1
struct Concurrency::details::IThreadProxyFactory::Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>::VTable
    ** var_8_1 = arg1
*arg1 = &Concurrency::details::ThreadProxyFactory<class Concurrency::details::FreeThreadProxy>::`vftable'{for `Concurrency::details::IThreadProxyFactory'}
void* ListHead = &arg1[2]
arg1[1] = *(arg2 + 8)
int32_t i_1 = 4
int32_t i

do
    InitializeSListHead(ListHead)
    ListHead += 8
    i = i_1
    i_1 -= 1
while (i != 1)
return arg1
