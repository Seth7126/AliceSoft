// 函数: __initp_misc_cfltcvt_tab
// 地址: 0x6a7721
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result

for (int32_t i = 0; i u< 0x28; i += 4)
    result = EncodePointer(*(i + &data_74b070))
    *(i + &data_74b070) = result

return result
