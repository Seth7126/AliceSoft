// 函数: __unwindfunclet$??0ContextBase@details@Concurrency@@QAE@PAVSchedulerBase@12@_N@Z$2
// 地址: 0x6ba62b
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_401fb0(*(arg1 - 0x10) + 0x8c) __tailcall
