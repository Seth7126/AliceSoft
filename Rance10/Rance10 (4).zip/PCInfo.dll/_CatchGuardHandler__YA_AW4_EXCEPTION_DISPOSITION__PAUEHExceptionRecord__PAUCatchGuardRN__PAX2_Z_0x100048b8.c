// 函数: ?CatchGuardHandler@@YA?AW4_EXCEPTION_DISPOSITION@@PAUEHExceptionRecord@@PAUCatchGuardRN@@PAX2@Z
// 地址: 0x100048b8
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

@__security_check_cookie@4(arg2[2] ^ arg2)
return ___InternalCxxFrameHandler(arg1, arg2[4], arg3, nullptr, arg2[3], arg2[5], arg2, 0)
