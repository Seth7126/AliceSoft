// 函数: ??1operation_timed_out@Concurrency@@UAE@XZ
// 地址: 0x62bf80
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &std::exception::`vftable'
return ___std_exception_destroy(&arg1[1])
