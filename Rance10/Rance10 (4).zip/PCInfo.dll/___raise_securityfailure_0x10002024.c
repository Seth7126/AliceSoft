// 函数: ___raise_securityfailure
// 地址: 0x10002024
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

SetUnhandledExceptionFilter(0)
UnhandledExceptionFilter(arg1)
TerminateProcess(GetCurrentProcess(), 0xc0000409)
noreturn
