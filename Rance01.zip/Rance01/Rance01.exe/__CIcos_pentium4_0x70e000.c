// 函数: __CIcos_pentium4
// 地址: 0x70e000
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_70e01e(zx.o(fconvert.d(arg1)))
