// 函数: sub_10002a84
// 地址: 0x10002a84
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* eax_1 = *(__getptd() + 0x98)

while (true)
    if (eax_1 == 0)
        return eax_1 + 1
    
    if (*eax_1 == arg1)
        break
    
    eax_1 = eax_1[1]

return 0
