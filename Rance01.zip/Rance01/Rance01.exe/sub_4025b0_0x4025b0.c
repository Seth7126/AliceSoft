// 函数: sub_4025b0
// 地址: 0x4025b0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return (*(*arg3 + 4))((*(*(*(*data_797d28 + 0x10))(arg1) + 0x14))(arg2))
