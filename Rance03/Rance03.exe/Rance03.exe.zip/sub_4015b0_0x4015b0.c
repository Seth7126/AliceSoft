// 函数: sub_4015b0
// 地址: 0x4015b0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f74c, &(*U",\n\n}")[1]:3, nullptr)
return _atexit(sub_6d24a0)
