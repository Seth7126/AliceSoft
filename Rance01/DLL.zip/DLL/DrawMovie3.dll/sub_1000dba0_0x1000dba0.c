// 函数: sub_1000dba0
// 地址: 0x1000dba0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000dae0(arg1 - 0xe0, *(arg1 + 0x44) - 1, arg2, *(arg1 + 0x50), *(arg1 + 0x54), 
    *(arg1 + 0x48), *(arg1 + 0x4c))
