// 函数: ??$__acrt_lock_and_call@V<lambda_b7fb1a997d3ebc0cc0186c5835178808>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_b7fb1a997d3ebc0cc0186c5835178808>@@@Z
// 地址: 0x10006649
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_c9469061b39d205f0f236529d4a41659>,class <lambda_b7fb1a997d3ebc0cc0186c5835178808>&,class <lambda_14b92c79d699846b5cc916cd4cf280e4>,void>::operator()<class <lambda_c9469061b39d205f0f236529d4a41659>,class <lambda_b7fb1a997d3ebc0cc0186c5835178808>&,class <lambda_14b92c79d699846b5cc916cd4cf280e4> >(
    &var_10, arg2)
