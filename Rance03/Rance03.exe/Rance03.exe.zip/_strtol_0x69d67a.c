// 函数: _strtol
// 地址: 0x69d67a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

void* var_18

if (data_75d30c != 0)
    var_18 = nullptr
else
    var_18 = &data_74aeb8

return strtoxl(var_18, arg1, arg2, arg3, 0)
