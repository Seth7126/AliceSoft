// 函数: __d_inttype
// 地址: 0x1000bb76
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = arg3
int32_t var_14 = arg3
var_14.q = fconvert.d(fconvert.t(arg4))

if ((__fpclass(var_14, arg3.w) & 0x90) != 0)
    return 

int32_t var_14_1 = arg3
var_14_1.q = fconvert.d(fconvert.t(arg4))
long double st0_1 = __frnd(var_14_1)
fconvert.t(arg4) - st0_1
bool p_1 = unimplemented  {test ah, 0x44}

if (p_1)
    return 

long double x87_r7_3 = st0_1 * fconvert.t(0.5)
int32_t var_10_2 = arg3
int32_t var_14_2 = arg3
int32_t var_c
var_c.q = fconvert.d(x87_r7_3)
var_14_2.q = fconvert.d(x87_r7_3)
fconvert.t(var_c.q) - __frnd(var_14_2)
unimplemented  {test ah, 0x44}
