// 函数: ___crtInitializeCriticalSectionEx
// 地址: 0x6e7ae6
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbe60 ^ __security_cookie

if (esi_1 == 0)
    InitializeCriticalSectionAndSpinCount(arg1, arg2)
    return 1

j_sub_4033e0()
return esi_1(arg1, arg2, arg3)
