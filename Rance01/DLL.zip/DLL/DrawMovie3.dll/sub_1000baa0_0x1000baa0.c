// 函数: sub_1000baa0
// 地址: 0x1000baa0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000b210(*(arg1 + 8))
