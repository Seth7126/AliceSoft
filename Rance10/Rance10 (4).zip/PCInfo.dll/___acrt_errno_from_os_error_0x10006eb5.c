// 函数: ___acrt_errno_from_os_error
// 地址: 0x10006eb5
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

for (int32_t i = 0; i u< 0x2d; i += 1)
    if (arg1 == *((i << 3) + &data_10010130))
        return *((i << 3) + &data_10010134)

if (arg1 - 0x13 u> 0x11)
    return (sbb.d(arg1 - 0xbc, arg1 - 0xbc, 0xe u< arg1 - 0xbc) & 0xe) + 8

return 0xd
