// 函数: __initp_eh_hooks
// 地址: 0x69b1dc
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = EncodePointer(terminate)
data_75c900 = result
return result
