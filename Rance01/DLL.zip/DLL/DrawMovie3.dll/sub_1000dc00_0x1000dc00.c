// 函数: sub_1000dc00
// 地址: 0x1000dc00
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (sub_10001000(arg2, 0x1001bc50) != 0)
    if (arg1 == 0)
        return sub_1000e830(nullptr, arg3)
    
    return sub_1000e830(&arg1[0x38], arg3)

if (sub_10001000(arg2, 0x1001bd60) == 0)
    return sub_1000c180(arg1, arg2, arg3)

if (arg1 == 0)
    return sub_1000e830(nullptr, arg3)

return sub_1000e830(&arg1[0x39], arg3)
