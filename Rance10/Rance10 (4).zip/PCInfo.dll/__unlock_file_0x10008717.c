// 函数: __unlock_file
// 地址: 0x10008717
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return LeaveCriticalSection(arg1 + 0x20)
