// 函数: sub_402190
// 地址: 0x402190
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 u> 8)
    int32_t eax_24
    eax_24.b = 0
    return eax_24

switch (arg1)
    case 0
        void* esi = *data_797d28
        int32_t eax_2 = (***arg2)()
        data_797d28
        *arg3 = zx.d((*(esi + 8))(eax_2))
        return 1
    case 1
        *arg3 = zx.d(sub_402560(*arg2, arg2[1]))
        uint32_t eax_7
        eax_7.b = 1
        return eax_7
    case 2
        *arg3 = sub_402590(*arg2)
        int32_t eax_9
        eax_9.b = 1
        return eax_9
    case 3
        sub_4025b0(*arg2, arg2[1], arg2[2])
        int32_t eax_11
        eax_11.b = 1
        return eax_11
    case 4
        *arg3 = sub_4025f0(*arg2, arg2[1])
        int32_t eax_13
        eax_13.b = 1
        return eax_13
    case 5
        *arg3 = sub_4025f0(*arg2, arg2[1])
        int32_t eax_16
        eax_16.b = 1
        return eax_16
    case 6
        *arg3 = sub_4025f0(*arg2, arg2[1])
        int32_t eax_19
        eax_19.b = 1
        return eax_19
    case 7
        *arg3 = sub_402620(*arg2)
        int32_t eax_21
        eax_21.b = 1
        return eax_21
    case 8
        sub_402640(*arg2, arg2[1], arg2[2])
        int32_t eax_23
        eax_23.b = 1
        return eax_23
