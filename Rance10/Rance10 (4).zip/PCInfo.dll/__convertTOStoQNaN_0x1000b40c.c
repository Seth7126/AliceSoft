// 函数: __convertTOStoQNaN
// 地址: 0x1000b40c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return 
