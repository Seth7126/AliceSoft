// 函数: sub_4013f0
// 地址: 0x4013f0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f5fc, 0x6da1ce, nullptr)
return _atexit(sub_6d1f60)
