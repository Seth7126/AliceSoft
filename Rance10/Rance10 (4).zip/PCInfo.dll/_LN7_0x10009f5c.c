// 函数: $LN7
// 地址: 0x10009f5c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_lowio_unlock_fh(**(arg1 + 0x10))
