// 函数: sub_1000b210
// 地址: 0x1000b210
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return LeaveCriticalSection((&data_10023540)[arg1 s>> 5] + ((arg1 & 0x1f) << 6) + 0xc)
