// 函数: ??0length_error@std@@QAE@PBD@Z
// 地址: 0x6d06f8
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::exception::VTable** var_8 = arg1
struct std::logic_error::std::invalid_argument::VTable** result = arg1
struct std::logic_error::std::invalid_argument::VTable** result_1 = result
sub_62be70(arg1, arg2)
*result = &std::invalid_argument::`vftable'{for `std::logic_error'}
return result
