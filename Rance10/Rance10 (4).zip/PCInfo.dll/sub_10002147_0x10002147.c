// 函数: sub_10002147
// 地址: 0x10002147
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t i

do
    int32_t var_8_2 = arg1
    int32_t result = sub_1000536c()
    
    if (result != 0)
        return result
    
    i = __callnewh(arg1)
while (i != 0)

if (arg1 != 0xffffffff)
    sub_1000250e()
    noreturn

sub_1000252b()
noreturn
