// 函数: ??$convert_hexadecimal_string_to_floating_type@M@__crt_strtox@@YA?AW4SLD_STATUS@@ABUfloating_point_string@0@AAM@Z
// 地址: 0x706e40
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_8 = arg3
int32_t var_c = arg3
var_c = arg5
var_8.b = 0
return __crt_strtox::convert_hexadecimal_string_to_floating_type_common(arg4, &var_c)
