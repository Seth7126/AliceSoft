// 函数: __NLG_Notify
// 地址: 0x6bffb5
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

data_78d138 = arg3
data_78d134 = arg1
data_78d13c = arg2
int32_t var_c = arg2
int32_t var_10 = arg3
return arg1
