// 函数: sub_1000cb50
// 地址: 0x1000cb50
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10010eb0(arg1, nullptr, arg2, arg2 + 0x7c, arg3, arg4)
arg1[0x36] = arg2
*arg1 = &CRendererInputPin::`vftable'{for `CBaseInputPin'}
arg1[3] = &CRendererInputPin::`vftable'{for `IPin'}
arg1[4] = &CRendererInputPin::`vftable'{for `IQualityControl'}
arg1[0x26] = &CRendererInputPin::`vftable'{for `IMemInputPin'}
return arg1
