// 函数: __allmul
// 地址: 0x6c0610
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if ((arg4 | arg2) == 0)
    return arg1 * arg3

int32_t result
int32_t edx
edx:result = mulu.dp.d(arg1, arg3)
return result
