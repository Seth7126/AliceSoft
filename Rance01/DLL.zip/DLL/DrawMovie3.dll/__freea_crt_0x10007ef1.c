// 函数: __freea_crt
// 地址: 0x10007ef1
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t* result = arg1

if (result != 0)
    result -= 8
    
    if (*result == 0xdddd)
        result = sub_10003602(result)

return result
