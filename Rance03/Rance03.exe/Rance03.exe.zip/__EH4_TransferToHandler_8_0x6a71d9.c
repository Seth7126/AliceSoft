// 函数: @_EH4_TransferToHandler@8
// 地址: 0x6a71d9
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

__NLG_Notify(arg1, arg2, 1)
jump(arg1)
