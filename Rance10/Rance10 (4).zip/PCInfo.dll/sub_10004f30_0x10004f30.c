// 函数: sub_10004f30
// 地址: 0x10004f30
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t ebp
int32_t var_4 = ebp
int32_t result = RtlUnwind(arg1, 0x10004f48, nullptr, nullptr)
var_4
return result
