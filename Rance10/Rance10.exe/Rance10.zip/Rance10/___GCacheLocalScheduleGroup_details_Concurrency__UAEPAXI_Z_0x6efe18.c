// 函数: ??_GCacheLocalScheduleGroup@details@Concurrency@@UAEPAXI@Z
// 地址: 0x6efe18
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

*arg1 = &Concurrency::ScheduleGroup::`vftable'

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
