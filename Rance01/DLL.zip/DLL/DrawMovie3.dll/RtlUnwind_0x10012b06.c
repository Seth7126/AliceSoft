// 函数: RtlUnwind
// 地址: 0x10012b06
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
