// 函数: ___acrt_uninitialize_ptd
// 地址: 0x10006960
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

BOOL result = data_10016044

if (result != 0xffffffff)
    ___acrt_FlsFree@4(result)
    data_10016044 = 0xffffffff

result.b = 1
return result
