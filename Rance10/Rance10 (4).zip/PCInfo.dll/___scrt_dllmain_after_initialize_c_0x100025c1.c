// 函数: ___scrt_dllmain_after_initialize_c
// 地址: 0x100025c1
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int64_t xcr0

if (___asan_report_present() == 0)
    if (sub_10005af3() != 0)
        int32_t eax_1
        eax_1.b = 0
        return eax_1
    
    j_sub_10005afe()
else
    sub_10002b3b(xcr0)
int32_t eax
eax.b = 1
return eax
