// 函数: ??0invalid_scheduler_policy_key@Concurrency@@QAE@PBD@Z
// 地址: 0x6d0719
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::logic_error::std::length_error::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &std::length_error::`vftable'{for `std::logic_error'}
return result
