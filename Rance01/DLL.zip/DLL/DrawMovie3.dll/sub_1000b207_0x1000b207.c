// 函数: sub_1000b207
// 地址: 0x1000b207
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return __unlock(0xa)
