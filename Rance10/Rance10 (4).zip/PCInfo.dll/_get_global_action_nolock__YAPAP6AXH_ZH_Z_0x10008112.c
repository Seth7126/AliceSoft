// 函数: ?get_global_action_nolock@@YAPAP6AXH@ZH@Z
// 地址: 0x10008112
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 2)
    return 0x1001722c

if (arg1 != 6)
    if (arg1 == 0xf)
        return 0x10017238
    
    if (arg1 == 0x15)
        return 0x10017230
    
    if (arg1 != 0x16)
        return 0

return &data_10017234
