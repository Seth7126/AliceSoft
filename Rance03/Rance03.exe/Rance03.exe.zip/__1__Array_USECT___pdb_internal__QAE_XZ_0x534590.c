// 函数: ??1?$Array@USECT@@@pdb_internal@@QAE@XZ
// 地址: 0x534590
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t result = *arg1

if (result != 0)
    result = j__free(result)

return result
