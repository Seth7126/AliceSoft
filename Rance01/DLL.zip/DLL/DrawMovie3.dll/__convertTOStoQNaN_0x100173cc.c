// 函数: __convertTOStoQNaN
// 地址: 0x100173cc
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 
