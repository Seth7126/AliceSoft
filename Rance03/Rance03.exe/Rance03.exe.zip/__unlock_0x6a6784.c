// 函数: __unlock
// 地址: 0x6a6784
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return LeaveCriticalSection(*((arg1 << 3) + &data_74aee0))
