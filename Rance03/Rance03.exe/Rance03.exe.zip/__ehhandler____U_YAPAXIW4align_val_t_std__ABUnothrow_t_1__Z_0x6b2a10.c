// 函数: __ehhandler$??_U@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x6b2a10
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_69a5bc(*(arg1 - 0x1c) ^ (arg1 + 0xc))
return sub_69e38e(0x7272c4) __tailcall
