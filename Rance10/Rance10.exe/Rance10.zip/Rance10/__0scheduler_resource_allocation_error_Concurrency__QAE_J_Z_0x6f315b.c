// 函数: ??0scheduler_resource_allocation_error@Concurrency@@QAE@J@Z
// 地址: 0x6f315b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
arg1[3] = arg2
*arg1 = &Concurrency::scheduler_resource_allocation_error::`vftable'{for `std::exception'}
return arg1
