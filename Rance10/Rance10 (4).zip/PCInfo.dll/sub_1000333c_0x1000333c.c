// 函数: sub_1000333c
// 地址: 0x1000333c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

*arg1 = &std::exception::`vftable'
___std_exception_destroy(&arg1[1])

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
