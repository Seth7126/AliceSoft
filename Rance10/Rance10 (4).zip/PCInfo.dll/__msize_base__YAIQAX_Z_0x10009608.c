// 函数: ?_msize_base@@YAIQAX@Z
// 地址: 0x10009608
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 != 0)
    return HeapSize(data_10017024, HEAP_NONE, arg1)

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
