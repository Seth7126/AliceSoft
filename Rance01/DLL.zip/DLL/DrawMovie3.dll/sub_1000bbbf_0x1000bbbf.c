// 函数: sub_1000bbbf
// 地址: 0x1000bbbf
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

uint32_t result

if (data_10022358 != 0)
    result = sub_1000baaa(arg1, nullptr)
else
    result = arg1
    
    if (result - 0x41 u<= 0x19)
        return result + 0x20

return result
