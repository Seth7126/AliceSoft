// 函数: $LN17
// 地址: 0x10004532
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (*(arg1 + 0x10) != 0)
    __unlock(8)
