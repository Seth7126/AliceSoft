// 函数: sub_10004538
// 地址: 0x10004538
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t result = ___vcrt_getptd_noexit()

if (result == 0)
    noreturn _abort() __tailcall

return result
