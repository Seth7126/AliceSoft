// 函数: ??4exception@std@@QAEAAV01@ABV01@@Z
// 地址: 0x69e4ba
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 != arg2)
    std::exception::_Tidy(arg1)
    
    if (*(arg2 + 8) == 0)
        *(arg1 + 4) = *(arg2 + 4)
    else
        sub_69e512(arg1, *(arg2 + 4))

return arg1
