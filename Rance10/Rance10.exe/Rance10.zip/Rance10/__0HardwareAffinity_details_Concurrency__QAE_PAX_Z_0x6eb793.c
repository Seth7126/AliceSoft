// 函数: ??0HardwareAffinity@details@Concurrency@@QAE@PAX@Z
// 地址: 0x6eb793
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

uint32_t* result = arg1
int32_t* result_1 = result
*result_1 = 0
void* edi = &result_1[1]
*edi = 0
*(edi + 4) = 0
int32_t edx
sub_6eb18e(0, edx, arg1, arg2, result)
return result
