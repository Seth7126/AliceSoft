// 函数: sub_10009e7c
// 地址: 0x10009e7c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_1000b684()

if (data_100220b8 != 0)
    sub_1000b45b()

return sub_10003602(data_100224e4)
