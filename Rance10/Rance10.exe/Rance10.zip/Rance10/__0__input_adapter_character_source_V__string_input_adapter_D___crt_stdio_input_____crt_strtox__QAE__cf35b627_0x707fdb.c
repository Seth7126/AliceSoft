// 函数: ??0?$input_adapter_character_source@V?$string_input_adapter@D@__crt_stdio_input@@@__crt_strtox@@QAE@QAV?$string_input_adapter@D@__crt_stdio_input@@_KQA_N@Z
// 地址: 0x707fdb
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[4] = 0
arg1[5] = 0
*arg1 = arg2
arg1[2] = arg3
arg1[3] = arg4
arg1[6] = arg5

if (arg5 != 0)
    *arg5 = 1

return arg1
