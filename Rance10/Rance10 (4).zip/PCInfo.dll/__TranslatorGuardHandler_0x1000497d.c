// 函数: __TranslatorGuardHandler
// 地址: 0x1000497d
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = arg3
@__security_check_cookie@4(*(arg5 + 8) ^ arg5)

if ((arg4->ExceptionFlags & 0x66) != 0)
    *(arg5 + 0x24) = 1
    return 1

___InternalCxxFrameHandler(arg4, *(arg5 + 0x10), arg6, nullptr, *(arg5 + 0xc), *(arg5 + 0x14), 
    *(arg5 + 0x18), 1)

if (*(arg5 + 0x24) == 0)
    sub_10004863(arg5, arg4)

int32_t var_10_2 = 0
sub_100046dc(0x123, &var_8, 0, 0, 0, 0)
*(arg5 + 0x1c)
*(arg5 + 0x20)
jump(var_8)
