// 函数: ??$__acrt_lock_stream_and_call@V<lambda_d82aded7e80d0a2836af81596bef263e>@@@@YAHQAU_iobuf@@$$QAV<lambda_d82aded7e80d0a2836af81596bef263e>@@@Z
// 地址: 0x710ea1
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_995298e7d72eb4c2aab26c0585b3abe5>,class <lambda_275893d493268fdec8709772e3fcec0e>&,class <lambda_293819299cbf9a7022e18b56a874bb5c>,int32_t>::operator()<class <lambda_995298e7d72eb4c2aab26c0585b3abe5>,class <lambda_275893d493268fdec8709772e3fcec0e>&,class <lambda_293819299cbf9a7022e18b56a874bb5c> >(
    &var_10, arg2)
