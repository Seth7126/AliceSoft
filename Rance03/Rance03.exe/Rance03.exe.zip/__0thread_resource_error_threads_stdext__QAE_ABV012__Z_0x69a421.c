// 函数: ??0thread_resource_error@threads@stdext@@QAE@ABV012@@Z
// 地址: 0x69a421
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

struct std::exception::std::bad_alloc::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::bad_alloc::`vftable'{for `std::exception'}
return result
