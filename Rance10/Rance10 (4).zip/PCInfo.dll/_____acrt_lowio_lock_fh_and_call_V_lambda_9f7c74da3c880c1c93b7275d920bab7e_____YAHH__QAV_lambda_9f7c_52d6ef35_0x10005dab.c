// 函数: ??$__acrt_lowio_lock_fh_and_call@V<lambda_9f7c74da3c880c1c93b7275d920bab7e>@@@@YAHH$$QAV<lambda_9f7c74da3c880c1c93b7275d920bab7e>@@@Z
// 地址: 0x10005dab
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_995298e7d72eb4c2aab26c0585b3abe5>,class <lambda_275893d493268fdec8709772e3fcec0e>&,class <lambda_293819299cbf9a7022e18b56a874bb5c>,int32_t>::operator()<class <lambda_995298e7d72eb4c2aab26c0585b3abe5>,class <lambda_275893d493268fdec8709772e3fcec0e>&,class <lambda_293819299cbf9a7022e18b56a874bb5c> >(
    &var_10, arg2)
