// 函数: __NLG_Notify1
// 地址: 0x1000a618
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t var_8 = arg3
data_10020d28 = arg3
data_10020d24 = arg1
data_10020d2c = arg4
int32_t var_c = arg4
int32_t var_10 = arg3
return arg1
