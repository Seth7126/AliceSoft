// 函数: sub_402c20
// 地址: 0x402c20
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

void** edi = arg1
void** esi = edi

if (*(edi + 0x15) != 0)
    return 

do
    sub_402c20(esi[2])
    esi = *esi
    void** var_10_2 = edi
    sub_6b4d5b()
    edi = esi
while (*(esi + 0x15) == 0)
