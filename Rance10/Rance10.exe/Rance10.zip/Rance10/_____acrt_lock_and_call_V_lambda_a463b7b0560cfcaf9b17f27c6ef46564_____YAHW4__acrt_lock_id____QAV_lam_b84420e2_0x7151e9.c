// 函数: ??$__acrt_lock_and_call@V<lambda_a463b7b0560cfcaf9b17f27c6ef46564>@@@@YAHW4__acrt_lock_id@@$$QAV<lambda_a463b7b0560cfcaf9b17f27c6ef46564>@@@Z
// 地址: 0x7151e9
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_9227be29367c048ad7fd93a717dcb1a1>,class <lambda_a463b7b0560cfcaf9b17f27c6ef46564>&,class <lambda_ccea11b5727ccf69be64f5f5d9a08d9f>,int32_t>::operator()<class <lambda_9227be29367c048ad7fd93a717dcb1a1>,class <lambda_a463b7b0560cfcaf9b17f27c6ef46564>&,class <lambda_ccea11b5727ccf69be64f5f5d9a08d9f> >(
    &var_10, arg2)
