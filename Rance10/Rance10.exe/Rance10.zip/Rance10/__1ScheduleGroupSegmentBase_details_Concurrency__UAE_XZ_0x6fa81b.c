// 函数: ??1ScheduleGroupSegmentBase@details@Concurrency@@UAE@XZ
// 地址: 0x6fa81b
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t eax_1 = arg1[3] & 0xfffffff
*arg1 = &Concurrency::details::ScheduleGroupSegmentBase::`vftable'

if (eax_1 == 3)
    Concurrency::details::SchedulerBase::ClearQuickCacheSlotIf(arg1[0x40]->__purecall, arg1[9], 
        arg1)

Concurrency::details::ListArray<struct Concurrency::details::ListArrayInlineLink<class Concurrency::details::WorkQueue> >::~ListArray<struct Concurrency::details::ListArrayInlineLink<class Concurrency::details::WorkQueue> >(
    &arg1[0x2a])
Concurrency::details::ListArray<class Concurrency::details::WorkQueue>::~ListArray<class Concurrency::details::WorkQueue>(
    &arg1[0x16])
sub_6fa7b5(&arg1[0xd])
return _free(arg1[8])
