// 函数: __ismbblead
// 地址: 0x6c4e01
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6c4dae(nullptr, arg1, 0, 4)
