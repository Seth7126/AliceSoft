// 函数: sub_401110
// 地址: 0x401110
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1[5] u>= 0x10)
    int32_t var_8_1 = *arg1
    sub_6b4d5b()

arg1[5] = 0xf
arg1[4] = 0
*arg1 = 0
