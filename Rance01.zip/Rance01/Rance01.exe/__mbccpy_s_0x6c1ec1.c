// 函数: __mbccpy_s
// 地址: 0x6c1ec1
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t var_8 = 0
return sub_6c1d6c(arg1, arg2, arg3, arg4)
