// 函数: __unwindfunclet$??0?$_Greedy_node@W4agent_status@Concurrency@@@Concurrency@@QAE@PAV?$ISource@W4agent_status@Concurrency@@@1@IPAV?$ITarget@I@1@ABV?$function@$$A6A_NABW4agent_status@Concurrency@@@Z@std@@@Z$2
// 地址: 0x6b2b69
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_414c20(*(arg1 - 0x10) + 0x1a4) __tailcall
