// 函数: __getc_nolock
// 地址: 0x6a003f
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t temp0 = arg1[1]
arg1[1] -= 1

if (temp0 - 1 s< 0)
    return sub_6a7222(arg1)

char* eax = *arg1
uint32_t result = zx.d(*eax)
*arg1 = &eax[1]
return result
