// 函数: jump_table_5f0bcc
// 地址: 0x5f0bcc
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*0x9a005f0b
*0x9a005f0b
*0x9a005f0f
*arg1 += arg1.b
*arg3 += arg1.b
*arg3 = &arg1[*arg3]
arg1.b += *arg2
arg3.b += arg1:1.b
breakpoint
