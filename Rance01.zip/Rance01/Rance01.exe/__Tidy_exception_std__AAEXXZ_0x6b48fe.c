// 函数: ?_Tidy@exception@std@@AAEXXZ
// 地址: 0x6b48fe
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (*(arg1 + 8) != 0)
    __free_base(*(arg1 + 4))

*(arg1 + 4) = 0
*(arg1 + 8) = 0
