// 函数: j_sub_424950
// 地址: 0x424900
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_424950(arg1, arg2) __tailcall
