// 函数: sub_1000cfa0
// 地址: 0x1000cfa0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*(arg1 + 0x24) = 0
jump(*(**(arg1 + 0xd8) + 0x78))
