// 函数: sub_10002619
// 地址: 0x10002619
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

___acrt_thread_detach()
___vcrt_thread_detach()
uint32_t result
result.b = 1
return result
