// 函数: __ehhandler$?_FullAliasWait@_TaskCollection@details@Concurrency@@AAEXPAV123@@Z
// 地址: 0x6b7511
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_69a5bc(*(arg1 - 0x24) ^ (arg1 + 0xc))
return sub_69e38e(0x72bc68) __tailcall
