// 函数: ??$__crt_time_elapsed_leap_years@J@@YAJJ@Z
// 地址: 0x70c80a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t edi
int32_t var_c = edi
int32_t eax_8
int32_t edx_2
edx_2:eax_8 = sx.q(arg1 - 1)
return ((eax_8 + (edx_2 & 3)) s>> 2) - 0x11 + divs.dp.d(sx.q(arg1 + 0x12b), 0x190)
    - divs.dp.d(sx.q(arg1 - 1), 0x64)
