// 函数: __unwindfunclet$?_Move@?$_Func_impl@U?$_Callable_obj@V<lambda_399686a4a5619bf4b18c998976ba8b81>@@$0A@@std@@V?$allocator@V?$_Func_class@XU_Nil@std@@U12@U12@U12@U12@U12@U12@@std@@@2@XU_Nil@2@U42@U42@U42@U42@U42@U42@@std@@UAEPAV?$_Func_base@XU_Nil@std@@U12@U12@U12@U12@U12@U12@@2@PAX@Z$0
// 地址: 0x6b5ab0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_4 = *(arg1 + 8)
int32_t result = *(arg1 - 0x18)
int32_t result_1 = result
return result
