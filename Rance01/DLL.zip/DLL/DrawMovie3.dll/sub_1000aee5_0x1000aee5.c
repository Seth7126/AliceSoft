// 函数: sub_1000aee5
// 地址: 0x1000aee5
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

void var_14
int32_t* eax
int32_t edx
eax, edx = sub_10004910(&var_14, arg1)
int32_t var_18_1 = arg9
int32_t result = sub_1000ab40(eax, edx, &var_14, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
