// 函数: ___vcrt_freeptd
// 地址: 0x69fc24
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

uint32_t result = data_74a564

if (result == 0xffffffff)
    return result

void* esi_1 = arg1

if (esi_1 == 0)
    esi_1 = sub_69f745(result)
    result = data_74a564

sub_69f764(result, 0)
return sub_69faef(esi_1)
