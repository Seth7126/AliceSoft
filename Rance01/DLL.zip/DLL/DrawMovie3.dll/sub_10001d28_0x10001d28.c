// 函数: sub_10001d28
// 地址: 0x10001d28
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

uint32_t var_4 = data_1002207c
HANDLE eax
int32_t edx
eax, edx = sub_10003063(var_4)
uint32_t ecx = var_4

if (eax != 0)
    eax, edx, ecx = eax()

sub_10002e04(eax, edx, ecx, 0x19)
sub_10002de3(0, 1)
noreturn sub_10002ccc() __tailcall
