// 函数: sub_401000
// 地址: 0x401000
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

*arg1 = &std::bad_alloc::`vftable'{for `std::exception'}
return sub_6b4978(arg1) __tailcall
