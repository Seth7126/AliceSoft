// 函数: __callnewh
// 地址: 0x69f6cd
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t eax = DecodePointer(data_75c970)

if (eax != 0 && eax(arg1) != 0)
    return 1

return 0
