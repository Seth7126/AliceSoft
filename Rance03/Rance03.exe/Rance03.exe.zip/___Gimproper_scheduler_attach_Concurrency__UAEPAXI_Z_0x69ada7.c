// 函数: ??_Gimproper_scheduler_attach@Concurrency@@UAEPAXI@Z
// 地址: 0x69ada7
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

type_info::~type_info(arg1)

if ((arg2 & 1) != 0)
    j__free(arg1)

return arg1
