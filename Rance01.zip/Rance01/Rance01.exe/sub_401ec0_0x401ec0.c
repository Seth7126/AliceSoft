// 函数: sub_401ec0
// 地址: 0x401ec0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t* var_4 = arg1
*(arg2 + 0x10) = 0
*(arg2 + 0x14) = 0xf
*arg2 = 0
sub_401180(arg2, arg4, arg1, arg3)
return arg2
