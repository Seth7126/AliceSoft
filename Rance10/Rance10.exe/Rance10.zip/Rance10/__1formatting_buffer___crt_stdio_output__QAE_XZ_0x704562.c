// 函数: ??1formatting_buffer@__crt_stdio_output@@QAE@XZ
// 地址: 0x704562
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result = __free_base(*(arg1 + 0x404))
*(arg1 + 0x404) = 0
return result
