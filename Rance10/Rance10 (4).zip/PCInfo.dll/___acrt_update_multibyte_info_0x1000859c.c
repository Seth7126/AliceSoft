// 函数: ___acrt_update_multibyte_info
// 地址: 0x1000859c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t* result = *arg2

if (result != data_10016570)
    result = data_100166f0
    
    if ((*(arg1 + 0x350) & result) == 0)
        result = ___acrt_update_thread_multibyte_data()
        *arg2 = result

return result
