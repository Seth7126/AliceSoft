// 函数: sub_1000c180
// 地址: 0x1000c180
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (sub_10001000(arg2, 0x1001bc90) == 0 && sub_10001000(arg2, 0x1001bd40) == 0)
    return sub_1000e950(arg1, arg2, arg3)

return (*(*arg1 + 0x24))(arg2, arg3)
