// 函数: sub_404fc0
// 地址: 0x404fc0
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int128_t* result = arg1[1]
int128_t* edi = *arg1

if (edi != result)
    void* esi_2 = 0
    result = sub_6b49d0(edi, result, esi_2)
    arg1[1] = esi_2 + edi

return result
