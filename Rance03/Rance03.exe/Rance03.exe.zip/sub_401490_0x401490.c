// 函数: sub_401490
// 地址: 0x401490
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f644, 0x6da247, nullptr)
return _atexit(sub_6d2140)
