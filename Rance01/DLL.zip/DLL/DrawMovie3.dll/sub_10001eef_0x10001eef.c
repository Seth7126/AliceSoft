// 函数: sub_10001eef
// 地址: 0x10001eef
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = &std::exception::`vftable'
int32_t ecx_1 = *arg2
arg1[2] = 0
arg1[1] = ecx_1
return arg1
