// 函数: ??0exception@std@@QAE@ABV01@@Z
// 地址: 0x6b49aa
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

arg1[1] = 0
*arg1 = &std::exception::`vftable'
arg1[2].b = 0
sub_6b4943(arg1, arg2)
return arg1
