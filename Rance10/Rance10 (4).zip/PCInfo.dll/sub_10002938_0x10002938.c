// 函数: sub_10002938
// 地址: 0x10002938
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return &data_10016bc0
