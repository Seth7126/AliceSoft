// 函数: ??0?$_MallocaArrayHolder@PAVevent@Concurrency@@@details@Concurrency@@QAE@XZ
// 地址: 0x6f310d
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

arg1[1] = 0
arg1[2] = 0
*arg1 = &Concurrency::invalid_scheduler_policy_thread_specification::`vftable'{for `std::exception'}
return arg1
