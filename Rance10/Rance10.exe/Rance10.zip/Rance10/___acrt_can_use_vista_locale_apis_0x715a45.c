// 函数: ___acrt_can_use_vista_locale_apis
// 地址: 0x715a45
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t eax_3 = try_get_FlsFree()
int32_t eax = neg.d(eax_3)
return neg.d(sbb.d(eax, eax, eax_3 != 0))
