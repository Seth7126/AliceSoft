// 函数: j_sub_5b68f0
// 地址: 0x5bd3d0
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_5b68f0(arg1) __tailcall
