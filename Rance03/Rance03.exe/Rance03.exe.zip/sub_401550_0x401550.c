// 函数: sub_401550
// 地址: 0x401550
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_402110(&data_74f6d4, 0x6da25b, nullptr)
return _atexit(sub_6d2380)
