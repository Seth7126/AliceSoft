// 函数: __FF_MSGBANNER
// 地址: 0x6b7cf7
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

uint32_t result

if (__set_error_mode(3) == 1)
    sub_6b7b48(0xfc)
    result = sub_6b7b48(0xff)
else
    result = __set_error_mode(3)
    
    if (result == 0 && data_78c470 == 1)
        sub_6b7b48(0xfc)
        result = sub_6b7b48(0xff)

return result
