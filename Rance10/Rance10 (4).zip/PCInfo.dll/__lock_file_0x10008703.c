// 函数: __lock_file
// 地址: 0x10008703
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return EnterCriticalSection(arg1 + 0x20)
