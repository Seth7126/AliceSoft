// 函数: __ftbuf
// 地址: 0x6a6799
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

if (arg1 == 0 || (arg2[3] & 0x1000) == 0)
    return 

__flush(arg2)
arg2[3] &= 0xffffeeff
arg2[6] = 0
*arg2 = 0
arg2[2] = 0
