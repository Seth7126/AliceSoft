// 函数: ___vcrt_initialize_winapi_thunks
// 地址: 0x10004e98
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_8 = 0x20
void* result = &data_10016c2c
int32_t i = 0
int32_t __security_cookie_1 = __security_cookie

do
    i += 1
    *result = __security_cookie_1
    result += 4
while (i != (sbb.d(&data_10016c50, &data_10016c50, false) & 0xfffffff7) + 9)

return result
