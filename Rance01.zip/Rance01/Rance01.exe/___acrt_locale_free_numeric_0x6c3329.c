// 函数: ___acrt_locale_free_numeric
// 地址: 0x6c3329
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

if (arg1 == 0)
    return 

int32_t eax_1 = *arg1

if (eax_1 != data_78d218)
    __free_base(eax_1)

int32_t eax_2 = arg1[1]

if (eax_2 != data_78d21c)
    __free_base(eax_2)

int32_t eax_3 = arg1[2]

if (eax_3 != data_78d220)
    __free_base(eax_3)

int32_t eax = arg1[0xc]

if (eax != data_78d248)
    __free_base(eax)

int32_t esi_1 = arg1[0xd]

if (esi_1 != data_78d24c)
    __free_base(esi_1)
