// 函数: ??0_Locimp@locale@std@@AAE@_N@Z
// 地址: 0x6d440f
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::locale::facet::std::locale::_Locimp::VTable** var_8 = arg1
struct std::locale::facet::std::locale::_Locimp::VTable** var_8_1 = arg1
arg1[1] = 1
*arg1 = &std::locale::_Locimp::`vftable'{for `std::locale::facet'}
arg1[2] = 0
arg1[3] = 0
arg1[4] = 0
arg1[5].b = arg2
arg1[6] = 0
arg1[7].b = 0
sub_630d40(&arg1[6], U"*")
return arg1
