// 函数: __unwindfunclet$??0?$source_block@V?$multi_link_registry@V?$ITarget@W4agent_status@Concurrency@@@Concurrency@@@Concurrency@@V?$ordered_message_processor@W4agent_status@Concurrency@@@2@@Concurrency@@QAE@XZ$3
// 地址: 0x6cd55a
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

return sub_60a700(*(arg1 - 0x10) + 0xb8) __tailcall
