// 函数: ___acrt_initialize_command_line
// 地址: 0x10007c6c
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10017018 = GetCommandLineA()
data_1001701c = GetCommandLineW()
PWSTR result
result.b = 1
return result
