// 函数: sub_10001e2e
// 地址: 0x10001e2e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t edi
int32_t var_c = edi

if (arg4 != 0)
    if (arg1 == 0 || arg3 == 0)
        *__errno() = 0x16
        sub_100020e4(0, 0, 0, 0, 0)
        return 0x16
    
    if (arg2 u< arg4)
        *__errno() = 0x22
        sub_100020e4(0, 0, 0, 0, 0)
        return 0x22
    
    sub_100038e0(arg1, arg3, arg4)

return 0
