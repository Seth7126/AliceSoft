// 函数: ??0regex_error@std@@QAE@ABV01@@Z
// 地址: 0x6d07ac
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

struct std::runtime_error::std::regex_error::VTable** result = arg1
sub_62beb0(arg1, arg2)
*result = &std::regex_error::`vftable'{for `std::runtime_error'}
result[3] = *(arg2 + 0xc)
return result
