// 函数: ??4SchedulerPolicy@Concurrency@@QAEAAV01@ABV01@@Z
// 地址: 0x6f5003
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

sub_700660(*arg1, *arg2, 0x28)
return arg1
