// 函数: sub_10001c5a
// 地址: 0x10001c5a
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

*arg1 = &std::out_of_range::`vftable'{for `std::logic_error'}
return sub_10001200(arg1) __tailcall
