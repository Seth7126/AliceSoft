// 函数: sub_1000668c
// 地址: 0x1000668c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 1
