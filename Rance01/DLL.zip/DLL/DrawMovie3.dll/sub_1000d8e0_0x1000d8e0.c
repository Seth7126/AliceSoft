// 函数: sub_1000d8e0
// 地址: 0x1000d8e0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

int32_t result = sub_1000c560(arg1, arg2)

if (result != 0)
    return 1

arg1[0x48] += 1
return result
