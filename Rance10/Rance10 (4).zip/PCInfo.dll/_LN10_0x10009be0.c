// 函数: $LN10
// 地址: 0x10009be0
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

return ___acrt_unlock(8)
