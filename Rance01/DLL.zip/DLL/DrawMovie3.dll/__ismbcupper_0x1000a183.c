// 函数: __ismbcupper
// 地址: 0x1000a183
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000a14b(arg1, nullptr)
