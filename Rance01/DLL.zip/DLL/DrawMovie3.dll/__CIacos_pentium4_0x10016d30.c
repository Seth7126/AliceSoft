// 函数: __CIacos_pentium4
// 地址: 0x10016d30
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

double var_10 = fconvert.d(arg1)
return start(zx.o(var_10), var_10)
