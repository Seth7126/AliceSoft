// 函数: ??0_Init_locks@std@@QAE@XZ
// 地址: 0x6d0bd5
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

bool cond:0 = data_7e1000 != 0xffffffff
data_7e1000
data_7e1000 += 1

if (not(cond:0))
    for (void* i = &data_7fb9e0; i s< 0x7fbaa0; i += 0x18)
        __Mtxinit(i)

return arg1
