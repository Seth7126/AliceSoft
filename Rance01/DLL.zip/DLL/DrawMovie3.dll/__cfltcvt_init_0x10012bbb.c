// 函数: __cfltcvt_init
// 地址: 0x10012bbb
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_10020a68 = __raise_exc
data_10020a6c = __mbsnextc
data_10020a70 = __mbsnbcmp
data_10020a74 = __ismbcl2
data_10020a78 = sub_10012e4d
data_10020a7c = __raise_exc
data_10020a80 = __cfltcvt_l
data_10020a84 = sub_10012e69
data_10020a88 = sub_10012dcb
data_10020a8c = sub_10012d58
return __raise_exc
