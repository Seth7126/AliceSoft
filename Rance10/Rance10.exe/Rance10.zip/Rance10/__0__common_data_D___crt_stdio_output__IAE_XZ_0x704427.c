// 函数: ??0?$common_data@D@__crt_stdio_output@@IAE@XZ
// 地址: 0x704427
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

void* var_8 = arg1
void* var_8_1 = arg1
__builtin_memset(arg1, 0, 0x2c)
*(arg1 + 0x30) = 0
*(arg1 + 0x38) = 0
*(arg1 + 0x3c) = 0
*(arg1 + 0x440) = 0
*(arg1 + 0x444) = 0
return arg1
