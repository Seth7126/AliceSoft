// 函数: sub_10009d0e
// 地址: 0x10009d0e
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return sub_1000b210(*(arg1 + 8))
