// 函数: sub_1000a81d
// 地址: 0x1000a81d
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (arg1 == 0)
    return 

void* eax_1 = *(arg1 + 0xc)

if (eax_1 != data_10020e04)
    sub_10003602(eax_1)

void* eax_2 = *(arg1 + 0x10)

if (eax_2 != data_10020e08)
    sub_10003602(eax_2)

void* eax_3 = *(arg1 + 0x14)

if (eax_3 != data_10020e0c)
    sub_10003602(eax_3)

void* eax_4 = *(arg1 + 0x18)

if (eax_4 != data_10020e10)
    sub_10003602(eax_4)

void* eax_5 = *(arg1 + 0x1c)

if (eax_5 != data_10020e14)
    sub_10003602(eax_5)

struct _EXCEPTION_REGISTRATION_RECORD** eax = *(arg1 + 0x20)

if (eax != data_10020e18)
    sub_10003602(eax)

void* esi_1 = *(arg1 + 0x24)

if (esi_1 != data_10020e1c)
    sub_10003602(esi_1)
