// 函数: sub_403060
// 地址: 0x403060
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t result = *(arg1 + 0x6c) + 1
*(arg1 + 0x6c) = result
return result
