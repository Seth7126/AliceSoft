// 函数: ___crtGetSystemTimePreciseAsFileTime
// 地址: 0x6e7a7a
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t esi_1 = data_7fbeb0 ^ __security_cookie

if (esi_1 == 0)
    return GetSystemTimeAsFileTime(arg1)

j_sub_4033e0()
return esi_1(arg1)
