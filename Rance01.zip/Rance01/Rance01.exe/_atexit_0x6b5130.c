// 函数: _atexit
// 地址: 0x6b5130
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

int32_t eax = sub_6b50f4(arg1)
int32_t eax_1 = neg.d(eax)
return neg.d(sbb.d(eax_1, eax_1, eax != 0)) - 1
