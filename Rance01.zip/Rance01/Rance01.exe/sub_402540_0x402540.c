// 函数: sub_402540
// 地址: 0x402540
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

void* esi = *data_797d28
int32_t eax_1 = (**arg1)()
data_797d28
return (*(esi + 8))(eax_1)
