// 函数: ___acrt_locale_free_lc_time_if_unreferenced
// 地址: 0x1000899e
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 != 0 && arg1 != &data_10010638 && arg1[0x2c] == 0)
    ___acrt_locale_free_time(arg1)
    __free_base(arg1)
