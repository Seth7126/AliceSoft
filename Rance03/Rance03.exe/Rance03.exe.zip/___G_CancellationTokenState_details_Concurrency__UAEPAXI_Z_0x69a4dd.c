// 函数: ??_G_CancellationTokenState@details@Concurrency@@UAEPAXI@Z
// 地址: 0x69a4dd
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

sub_69e4af(arg1)

if ((arg2 & 1) != 0)
    j__free(arg1)

return arg1
