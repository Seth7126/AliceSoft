// 函数: sub_1000c470
// 地址: 0x1000c470
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

return 0
