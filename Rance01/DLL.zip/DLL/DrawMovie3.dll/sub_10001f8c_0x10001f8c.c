// 函数: sub_10001f8c
// 地址: 0x10001f8c
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

sub_10001f69(arg1)

if ((arg2 & 1) != 0)
    struct std::exception::VTable** var_c_1 = arg1
    sub_10001d52()

return arg1
