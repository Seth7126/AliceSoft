// 函数: __NLG_Call
// 地址: 0x10005064
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t eax
return eax()
