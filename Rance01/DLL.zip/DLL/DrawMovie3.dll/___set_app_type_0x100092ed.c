// 函数: ___set_app_type
// 地址: 0x100092ed
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_100223dc = arg1
return arg1
