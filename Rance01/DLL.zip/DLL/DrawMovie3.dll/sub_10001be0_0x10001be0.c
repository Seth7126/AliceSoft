// 函数: sub_10001be0
// 地址: 0x10001be0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

arg1 -= 0xd4
return sub_1000c010() __tailcall
