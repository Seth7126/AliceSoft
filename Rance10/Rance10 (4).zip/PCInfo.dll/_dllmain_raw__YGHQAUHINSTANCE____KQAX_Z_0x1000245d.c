// 函数: ?dllmain_raw@@YGHQAUHINSTANCE__@@KQAX@Z
// 地址: 0x1000245d
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t ebp
int32_t var_4 = ebp
int32_t esi
int32_t var_8 = esi
int32_t* esp = &var_8
*esp
esp[1]
return 1
