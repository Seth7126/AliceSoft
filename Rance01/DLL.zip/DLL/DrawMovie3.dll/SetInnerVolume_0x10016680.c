// 函数: SetInnerVolume
// 地址: 0x10016680
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

data_100214c0 = arg1
return arg1
