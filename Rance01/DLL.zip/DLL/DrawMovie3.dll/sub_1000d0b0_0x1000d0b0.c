// 函数: sub_1000d0b0
// 地址: 0x1000d0b0
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

(*(*arg1 + 0xbc))()
return 0
