// 函数: ___acrt_unlock
// 地址: 0x70d7c1
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

return LeaveCriticalSection(arg1 * 0x18 + &data_7fc480)
