// 函数: ___common_sll
// 地址: 0x722810
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

if (arg3 u>= 0x40)
    return 0

if (arg3 u>= 0x20)
    return 0

return arg1 << arg3
