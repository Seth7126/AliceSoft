// 函数: __NLG_Notify
// 地址: 0x10005045
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

data_10016038 = arg3
data_10016034 = arg1
data_1001603c = arg2
int32_t var_c = arg2
int32_t var_10 = arg3
return arg1
