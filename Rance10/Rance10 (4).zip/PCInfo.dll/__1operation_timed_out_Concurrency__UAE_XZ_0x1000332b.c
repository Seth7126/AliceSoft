// 函数: ??1operation_timed_out@Concurrency@@UAE@XZ
// 地址: 0x1000332b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

*arg1 = &std::exception::`vftable'
return ___std_exception_destroy(&arg1[1])
