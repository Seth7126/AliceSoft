// 函数: ___vcrt_uninitialize
// 地址: 0x100042e5
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg1 == 0)
    ___vcrt_uninitialize_ptd()
    ___vcrt_uninitialize_locks()
    ___vcrt_uninitialize_winapi_thunks(0)

int32_t result
result.b = 1
return result
