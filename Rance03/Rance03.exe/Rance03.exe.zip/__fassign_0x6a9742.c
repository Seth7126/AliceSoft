// 函数: __fassign
// 地址: 0x6a9742
// 来自: E:/torrent/AliceSoft/ランス03/Rance03.exe.bndb

int32_t var_8 = 0
int32_t eax
int32_t ecx
int32_t edx
return __fassign_l(eax, edx, ecx, arg1, arg2, arg3)
