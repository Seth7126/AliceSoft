// 函数: __c_exit
// 地址: 0x6b7099
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

return sub_6b6f1e(0, 1, 1)
