// 函数: ??1NumaInformation@SchedulerBase@details@Concurrency@@QAE@XZ
// 地址: 0x6efc4c
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

_free(*(arg1 + 0xc))
return _free(*(arg1 + 4))
