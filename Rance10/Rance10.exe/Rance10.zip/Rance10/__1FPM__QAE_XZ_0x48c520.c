// 函数: ??1FPM@@QAE@XZ
// 地址: 0x48c520
// 来自: E:\torrent\AliceSoft\ランス１０\Rance10.exe

int32_t result = *(arg1 + 0x10)

if (result != 0)
    result = _free(result)

return result
