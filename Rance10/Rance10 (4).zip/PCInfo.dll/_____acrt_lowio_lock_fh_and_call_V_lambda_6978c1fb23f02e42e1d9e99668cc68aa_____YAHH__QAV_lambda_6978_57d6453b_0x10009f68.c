// 函数: ??$__acrt_lowio_lock_fh_and_call@V<lambda_6978c1fb23f02e42e1d9e99668cc68aa>@@@@YAHH$$QAV<lambda_6978c1fb23f02e42e1d9e99668cc68aa>@@@Z
// 地址: 0x10009f68
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_61cee617f5178ae960314fd4d05640a0>,class <lambda_6978c1fb23f02e42e1d9e99668cc68aa>&,class <lambda_9cd88cf8ad10232537feb2133f08c833>,int32_t>::operator()<class <lambda_61cee617f5178ae960314fd4d05640a0>,class <lambda_6978c1fb23f02e42e1d9e99668cc68aa>&,class <lambda_9cd88cf8ad10232537feb2133f08c833> >(
    &var_10, arg2)
