// 函数: _uninitialize_environment
// 地址: 0x1000613b
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

___dcrt_uninitialize_environments_nolock()
int32_t result
result.b = 1
return result
