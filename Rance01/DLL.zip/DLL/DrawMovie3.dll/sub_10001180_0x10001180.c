// 函数: sub_10001180
// 地址: 0x10001180
// 来自: E:\torrent\AliceSoft\ランス01\DLL\DrawMovie3.dll

if (*(arg1 + 0x24) u< 0x10)
    return arg1 + 0x10

return *(arg1 + 0x10)
