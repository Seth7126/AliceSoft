// 函数: sub_403070
// 地址: 0x403070
// 来自: E:\torrent\AliceSoft\ランス01\Rance01.exe

arg1[0x1b] -= 1
int32_t result = arg1[0x1b]

if (result s> 0)
    return result

(*(*arg1 + 0x2c))(1)
return 0
