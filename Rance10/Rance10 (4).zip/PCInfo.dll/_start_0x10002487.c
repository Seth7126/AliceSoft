// 函数: _start
// 地址: 0x10002487
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

if (arg2 == 1)
    ___security_init_cookie()

return dllmain_dispatch(arg1, arg2, arg3)
