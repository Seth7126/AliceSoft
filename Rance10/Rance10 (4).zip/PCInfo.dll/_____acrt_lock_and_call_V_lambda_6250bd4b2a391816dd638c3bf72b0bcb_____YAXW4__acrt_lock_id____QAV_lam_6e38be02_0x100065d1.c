// 函数: ??$__acrt_lock_and_call@V<lambda_6250bd4b2a391816dd638c3bf72b0bcb>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_6250bd4b2a391816dd638c3bf72b0bcb>@@@Z
// 地址: 0x100065d1
// 来自: E:\torrent\AliceSoft\ランス１０\PCInfo.dll

int32_t var_c = arg1
int32_t var_10 = arg1
int32_t* var_14 = &var_c
return __crt_seh_guarded_call<class <lambda_51b6e8b1eb166f2a3faf91f424b38130>,class <lambda_6250bd4b2a391816dd638c3bf72b0bcb>&,class <lambda_0b5a4a3e68152e1d9b943535f5f47bed>,void>::operator()<class <lambda_51b6e8b1eb166f2a3faf91f424b38130>,class <lambda_6250bd4b2a391816dd638c3bf72b0bcb>&,class <lambda_0b5a4a3e68152e1d9b943535f5f47bed> >(
    &var_10, arg2)
